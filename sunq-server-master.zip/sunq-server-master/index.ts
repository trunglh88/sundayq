import {ApplicationConfig} from '@loopback/core';
import {Application} from './application';
import {Log} from './utils';

export {Application};

export async function main(options: ApplicationConfig = {}) {

options.rest = {
    cors:
    {
      origin: '*',
      methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
      preflightContinue: false,
      optionsSuccessStatus: 204,
      maxAge: 86400000,
      credentials: true,
    },
    port: 3200

  };

  const app = new Application(options);
  await app.boot();
  await app.start();

  const url = app.restServer.url;
  Log.i('Server', `Running at ${url}`);

  return app;
}
