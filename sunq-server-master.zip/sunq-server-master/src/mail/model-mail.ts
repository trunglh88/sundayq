import {model, Model, property} from '@loopback/repository';

@model()
export class VerifyAccount extends Model {
  @property()
  receiverEmail: string;

  @property()
  receiverName: string;

  @property()
  token: string;

  constructor(data?: Partial<VerifyAccount>) {
    super(data);
    this.receiverEmail = data?.receiverEmail ?? '';
    this.receiverName = data?.receiverName ?? '';
    this.token = data?.token ?? '';
  }
}

@model()
export class ResetPassword extends Model {
  @property()
  receiverEmail: string;

  @property()
  receiverName: string;

  @property()
  password: string;

  constructor(data?: Partial<ResetPassword>) {
    super(data);
    this.receiverEmail = data?.receiverEmail ?? '';
    this.receiverName = data?.receiverName ?? '';
    this.password = data?.password ?? '';
  }
}
