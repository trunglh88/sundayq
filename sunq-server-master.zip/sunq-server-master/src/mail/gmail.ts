import {GmailService} from '../services';
import {ResetPassword, VerifyAccount} from './model-mail';

export namespace Gmail {
  export const verifyAccount = (body: VerifyAccount) => {
    const content = {
      to: body.receiverEmail,
      from: 'Noreply <noreply.sundayq@gmail.com>', // from email address, eg: 'DISPLAY_NAME <from@gmail.com>'
      subject: `=?utf-8?B?${Buffer.from('Đăng ký tài khoản thành viên.').toString('base64')}?=`,
      content: `<html>

      <head>
          <title>Demo title</title>
      </head>

      <body>
          <p>Chào bạn <strong>${body.receiverName}</strong></p>
          <div style="height: 3;"></div>
          <p>Bạn vừa gửi yêu cầu đăng ký làm thành viên của SunQ.</p>
          <p>Vui lòng nhấn vào link dưới đây để xác nhận bạn đã đăng ký thành công:</p>
          <p><a href="http://sundayq.com/q-online/register/verify?token=${body.token}"><i>http://sundayq.com/q-online/register/verif...</i></a></p>
          <p></p>
          <div style="height: 15;"></div>
          <p><strong>Freeq support Team</strong></p>
      </body>

      </html>`,
    };
    GmailService.sendMail(content);
  };

  export const resetPassword = (body: ResetPassword) => {
    const content = {
      to: body.receiverEmail,
      from: 'Noreply <noreply.sundayq@gmail.com>', // from email address, eg: 'DISPLAY_NAME <from@gmail.com>'
      subject: `=?utf-8?B?${Buffer.from('Làm mới mật khẩu.').toString('base64')}?=`,
      content: `<html>

      <head>
          <title>Demo title</title>
      </head>

      <body>
    <p>Chào bạn <strong>${body.receiverName}</strong></p>
    <div style="height: 3;"></div>
    <p>Bạn vừa gửi yêu cầu làm mới mật khẩu.</p>
    <p>Chúng tôi xin gửi lại cho bạn mật khẩu mới là <strong>${body.password}</strong></>
    <p>Vui lòng sử dụng mật khẩu này cho những lần đăng nhập tiếp theo/</p>
     <p></p>
    <div style="height: 15;"></div>
    <p><strong>Freeq support Team</strong></p>
</body>

      </html>`,
    };
    GmailService.sendMail(content);
  };
}
