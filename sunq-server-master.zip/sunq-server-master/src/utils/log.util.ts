/* eslint-disable @typescript-eslint/no-explicit-any */
import path = require('path');
import util = require('util');
import {AnyObject} from '@loopback/repository';
import {createLogger, format, Logform, transports} from 'winston';
import DailyRotateFile = require('winston-daily-rotate-file');

const formFormat = format.printf(({level, message, timestamp}) => {
  return `${timestamp.slice(0, -2)} ${level} ${message}`;
});

const timestampFormat = format.timestamp({format: 'MM-DD HH:mm:ss.SSSZZ'});

const regexFormat = '%[sdifjoOc]';
const objectFormat = '%o';

const formatMessage = (info: Logform.TransformableInfo, opts?: AnyObject) => {
  opts = {colors: false, compact: true, ...opts};
  const splat = info[Symbol.for('splat') as any] || info.splat;

  if (process.env.COMPACT_ENV) opts.compact = false;

  if (splat && splat.length > 0) {
    info.message = (typeof info.message === 'string' && info.message) || '';
    if (splat[0] && splat[0].message) info.message = info.message.replace(splat[0].message, '');
    const match = info.message.match(new RegExp(regexFormat, 'g'));
    let idx = match?.length ?? 0;
    while (idx < splat.length && idx++) {
      info.message += info.message ? ` ${objectFormat}` : objectFormat;
    }
    info.message = util.formatWithOptions(
      {
        colors: opts.colors,
        compact: opts.compact,
        depth: null,
        showHidden: false,
        sorted: true,
        breakLength: opts.compact ? Infinity : 80,
      },
      info.message,
      ...splat,
    );
  }
  return info;
};

const splatFormat = format(formatMessage);

const errorTransport = new DailyRotateFile({
  level: 'error',
  dirname: path.join(__dirname, '../../private/log'),
  filename: 'error-%DATE%.log',
  datePattern: 'MM-DD',
  maxFiles: '14d',
  format: format.combine(timestampFormat, splatFormat(), formFormat),
});

const infoTransport = new DailyRotateFile({
  level: 'info',
  dirname: path.join(__dirname, '../../private/log'),
  filename: 'info-%DATE%.log',
  datePattern: 'MM-DD',
  maxFiles: '14d',
  format: format.combine(timestampFormat, splatFormat(), formFormat),
});

const debugTransport = new transports.Console({
  level: 'debug',
  format: format.combine(timestampFormat, format.colorize(), splatFormat({colors: true}), formFormat),
});

const logger = createLogger();

const IS_PRODUCTION = process.env.NODE_ENV === 'release';
if (IS_PRODUCTION) {
  logger.add(errorTransport);
  logger.add(infoTransport);
} else {
  logger.add(debugTransport);
}
if (process.env.LOG_DEBUG === 'true') logger.add(debugTransport);

export namespace Log {
  export const i = (tag: string, message: any, ...meta: any[]) => {
    if (typeof message === 'object') {
      logger.info(`${tag}: ${objectFormat}`, ...[message, ...meta]);
    } else {
      logger.info(`${tag}: ${message}`, ...meta);
    }
  };
  export const e = (tag: string, message: any, ...meta: any[]) => {
    if (typeof message === 'object') {
      logger.error(`${tag}: ${objectFormat}`, ...[message, ...meta]);
    } else {
      logger.error(`${tag}: ${message}`, ...meta);
    }
  };

  export const v = (tag: string, message: any, ...meta: any[]) => {
    if (typeof message === 'object') {
      logger.verbose(`${tag}: ${objectFormat}`, ...[message, ...meta]);
    } else {
      logger.verbose(`${tag}: ${message}`, ...meta);
    }
  };

  export const d = (tag: string, message: any, ...meta: any[]) => {
    if (typeof message === 'object') {
      logger.debug(`${tag}: ${objectFormat}`, ...[message, ...meta]);
    } else {
      logger.debug(`${tag}: ${message}`, ...meta);
    }
  };
}
