import {Constructor} from '@loopback/core';
import {AnyObject, Entity, ModelDefinition, ModelMetadataHelper, resolveType} from '@loopback/repository';
import {isArrayType} from '@loopback/rest';

const ignore = [String, Number, Boolean, Date, Object, Array] as Function[];

export function objectToEntity<T extends object>(
  srcObject: Entity | AnyObject,
  entity: Function & {prototype: T} & Constructor<T>,
  options?: AnyObject,
): T {
  const model: T = new entity();
  if (srcObject === undefined) return model;
  const modelDef = ModelMetadataHelper.getModelMetadata(entity);
  if (modelDef == null || Object.keys(modelDef).length === 0) {
    return model;
  }
  const meta = modelDef as ModelDefinition;

  for (const p in meta.properties) {
    if ((srcObject as AnyObject)[p] === undefined || (srcObject as AnyObject)[p] === null) {
      continue;
    }
    (model as AnyObject)[p] = (srcObject as AnyObject)[p];

    const metaProperty = Object.assign({}, meta.properties[p]);
    const resolvedType = resolveType(metaProperty.type) as string | Function;
    const referenceType = isArrayType(resolvedType)
      ? // shimks: ugly type casting; this should be replaced by logic to throw
        // error if itemType/type is not a string or a function
        resolveType(metaProperty.itemType as string | Function)
      : resolvedType;

    if (typeof referenceType !== 'function' || ignore.includes(referenceType)) {
      continue;
    }

    if (isArrayType(resolvedType)) {
      (model as AnyObject)[p] = (model as AnyObject)[p].map((item: AnyObject) => {
        return objectToEntity(item, referenceType as Function & {prototype: T} & Constructor<T>, options);
      });
      continue;
    }

    (model as AnyObject)[p] = objectToEntity(
      (model as AnyObject)[p] as AnyObject,
      referenceType as Function & {prototype: T} & Constructor<T>,
      options,
    );
  }

  return model;
}

export function objectsToEntities<T extends object>(
  srcObjects: Entity[] | AnyObject[],
  entity: Function & {prototype: T} & Constructor<T>,
  options?: AnyObject,
) {
  return (srcObjects as Entity[]).map(
    (srcObject): T => {
      return objectToEntity(srcObject, entity, options);
    },
  );
}
