import {AnyObject} from '@loopback/repository';
import {
  getJsonSchema,
  JsonSchemaOptions,
  OperationObject,
  ReferenceObject,
  RequestBodyObject,
  SecuritySchemeObject,
} from '@loopback/rest';
import {Constants} from '../constants';

export namespace OpenApiSpec {
  export const OPERATOR_SECURITY_SPEC = [{jwt: []}];
  export const SECURITY_SCHEME_SPEC: {[SecurityScheme: string]: SecuritySchemeObject | ReferenceObject} = {
    jwt: {type: 'http', scheme: 'bearer', bearerFormat: 'JWT'},
  };
}

export function spec<T extends object>(
  mCtor: Function & {prototype: T},
  options?: JsonSchemaOptions<T> & {array?: boolean; auth?: boolean},
  description?: string,
): OperationObject {
  const auth = !options || options.auth === undefined || options.auth;
  return {
    security: auth ? OpenApiSpec.OPERATOR_SECURITY_SPEC : undefined,
    responses: {
      '200': {
        description: `${description ? description + '</br>' : ''}{code: number, message: string, data: ${mCtor.name}}`,
        content: {
          'application/json': {
            schema: options?.array
              ? {
                  type: 'array',
                  items: {
                    'x-ts-type': mCtor,
                  },
                }
              : {'x-ts-type': mCtor},
          },
        },
      },
    },
  };
}

export namespace Spec {
  export const upload = (fieldName: string): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[fieldName] = {
      description: `Put multiple files with the same fieldname ${fieldName} to upload many files`,
      type: 'string',
      format: 'binary',
    };
    // properties['fileName'] = {
    //   description: `Put fileName at here`,
    //   type: 'string',
    // };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const uploadSingleFile = (fieldName: string): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[fieldName] = {
      description: `Put multiple files with the same fieldname ${fieldName} to upload many files`,
      type: 'string',
      format: 'binary',
    };
    properties['title'] = {
      description: `Put title at here`,
      type: 'string',
    };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const uploadVideo = (): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[Constants.FILE_TYPE.VIDEO] = {
      description: `Put multiple files with the same fieldname video to upload many files`,
      type: 'string',
      format: 'binary',
    };
    // properties[Constants.FILE_TYPE.IMAGE] = {
    //   description: `Put multiple files with the same fieldname video to upload many files`,
    //   type: 'string',
    //   format: 'binary',
    // };
    // properties['title'] = {
    //   description: `Put title at here`,
    //   type: 'string',
    // };
    // properties['description'] = {
    //   description: `Put description at here`,
    //   type: 'string',
    // };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const uploadImage = (): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[Constants.FILE_TYPE.IMAGE] = {
      description: `Put multiple files with the same fieldname image to upload many files`,
      type: 'string',
      format: 'binary',
    };

    properties['title'] = {
      description: `Put title at here`,
      type: 'string',
    };
    properties['description'] = {
      description: `Put description at here`,
      type: 'string',
    };

    properties['shortDescription'] = {
      description: `Put short description at here`,
      type: 'string',
    };
    // properties['fileName'] = {
    //   description: `Put fileName at here`,
    //   type: 'string',
    // };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const createKit = (): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[Constants.FILE_TYPE.IMAGE] = {
      description: `Put multiple files with the same fieldname image to upload many files`,
      type: 'string',
      format: 'binary',
    };

    properties['title'] = {
      description: `Put title at here`,
      type: 'string',
    };
    properties['description'] = {
      description: `Put description at here`,
      type: 'string',
    };
    properties['price'] = {
      description: `Put price at here`,
      type: 'number',
    };

    properties['shortDescription'] = {
      description: `Put short description at here`,
      type: 'number',
    };
    // properties['fileName'] = {
    //   description: `Put fileName at here`,
    //   type: 'string',
    // };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const createAgePlan = (): RequestBodyObject => {
    const properties: AnyObject = {};
    properties[Constants.FILE_TYPE.IMAGE] = {
      description: `Put file with the same fieldname image to upload many files`,
      type: 'string',
      format: 'binary',
    };

    properties['title'] = {
      description: `Put title at here`,
      type: 'string',
    };
    properties['description'] = {
      description: `Put description at here`,
      type: 'string',
    };

    properties['shortDescription'] = {
      description: `Put short description at here`,
      type: 'number',
    };
    // properties['fileName'] = {
    //   description: `Put fileName at here`,
    //   type: 'string',
    // };
    return {
      description: 'Request body for multipart/form-data based file upload',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: properties,
          },
        },
      },
    };
  };

  export const description = (idescription?: string, auth?: boolean) => {
    return {
      security: auth === undefined || auth ? OpenApiSpec.OPERATOR_SECURITY_SPEC : undefined,
      responses: {
        '200': {
          description: idescription ?? '',
        },
      },
    };
  };
}

export const res: (<T extends object>(mCtor: Function & {prototype: T}) => string) & AnyObject = function<
  T extends object
>(mCtor: Function & {prototype: T}) {
  if (!res.values) {
    res.values = new Set();
    res.getValues = () => {
      return Array.from(res.values as Set<Function & {prototype: T}>).map((item: Function & {prototype: T}) => {
        return {name: item.name, description: getJsonSchema(item).description};
      });
    };
  }
  res.values.add(mCtor);
  return mCtor.name;
};
