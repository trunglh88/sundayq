import {Constants} from '../constants';

export namespace RegexForm {
  export const PHONE_NUMBER_MOBILE_VN = '[0-9]{8,}';
  export const ACCOUNT_TYPE = `(${Object.values(Constants.ACCOUNT_TYPE).join('|')})`;
  export const SHORT_ID = '[^@]{3,}';
}
