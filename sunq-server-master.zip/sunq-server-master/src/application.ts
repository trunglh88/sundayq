import {AuthenticationComponent} from '@loopback/authentication';
import {AuthorizationComponent} from '@loopback/authorization';
import {BootMixin} from '@loopback/boot';
import {ApplicationConfig, BindingKey, createBindingFromClass} from '@loopback/core';
import {RepositoryMixin, SchemaMigrationOptions} from '@loopback/repository';
import {RestApplication, RestBindings } from '@loopback/rest';
import {RestExplorerBindings, RestExplorerComponent} from '@loopback/rest-explorer';
import {ServiceMixin} from '@loopback/service-proxy';
import path from 'path';
import {JWTAuthenticationStrategy, JWTQueryAuthenticationStrategy} from './authentications';
import {Configs} from './constants';
import {
  AccountServiceBindings,
  AppBindings,
  PasswordHasherBindings,
  RefreshtokenServiceBindings,
  TokenServiceBindings,
  TokenServiceConstants,
} from './keys';
import {TicketPrice} from './models';
import {AccountRepository, RoleGroupRepository, TicketPriceRepository} from './repositories';
import {MySequence} from './sequence';
import {JWTService} from './services';
import {AccountService} from './services/account.service';
import {GoogleOAuth2} from './services/gmail.service';
import {MyRefreshtokenService} from './services/refreshtoken.service';
import {BcryptHasher, objectToEntity, OpenApiSpec} from './utils';

export interface PackageInfo {
  name: string;
  version: string;
  description: string;
}
export const PackageKey = BindingKey.create<PackageInfo>('application.package');
const pkg: PackageInfo = require('../package.json');

export class Application extends BootMixin(ServiceMixin(RepositoryMixin(RestApplication))) {
  constructor(options: ApplicationConfig = {}) {
    super(options);

    this.setUpBindings();

    this.api({
      openapi: '3.0.0',
      info: {title: pkg.name, version: pkg.version},
      paths: {},
      components: {securitySchemes: OpenApiSpec.SECURITY_SCHEME_SPEC},
      servers: [{url: '/'}],
    });

    // Bind authentication component related elements
    this.component(AuthenticationComponent);
    this.component(AuthorizationComponent);

    // authentication
    this.add(createBindingFromClass(JWTAuthenticationStrategy));
    this.add(createBindingFromClass(JWTQueryAuthenticationStrategy));

    // Set up the custom sequence
    this.sequence(MySequence);

    // Set up default home page
    this.static('/', path.join(__dirname, '../public'));

    // Customize @loopback/rest-explorer configuration here
    this.configure(RestExplorerBindings.COMPONENT).to({
      path: '/explorer',
    });
    this.component(RestExplorerComponent);

    this.projectRoot = __dirname;
    // Customize @loopback/boot Booter Conventions here
    this.bootOptions = {
      controllers: {
        // Customize ControllerBooter Conventions here
        dirs: ['controllers'],
        extensions: ['.controller.js'],
        nested: true,
      },
    };
    this.bind(RestBindings.REQUEST_BODY_PARSER_OPTIONS).to({
      limit: '1000MB',
    });
  }

  setUpBindings(): void {
    this.bind(AppBindings.APP).to(this);

    // Bind package.json to the application context
    this.bind(PackageKey).to(pkg);

    this.bind(TokenServiceBindings.TOKEN_SECRET).to(TokenServiceConstants.TOKEN_SECRET_VALUE);

    this.bind(TokenServiceBindings.TOKEN_EXPIRES_IN).to(TokenServiceConstants.TOKEN_EXPIRES_IN_VALUE);

    this.bind(TokenServiceBindings.TOKEN_SERVICE).toClass(JWTService);
    this.bind(RefreshtokenServiceBindings.REFRESHTOKEN_SERVICE).toClass(MyRefreshtokenService);

    // // Bind bcrypt hash services
    this.bind(PasswordHasherBindings.ROUNDS).to(10);
    this.bind(PasswordHasherBindings.PASSWORD_HASHER).toClass(BcryptHasher);

    this.bind(AccountServiceBindings.ACCOUNT_SERVICE).toClass(AccountService);
  }

  // Unfortunately, TypeScript does not allow overriding methods inherited
  // from mapped types. https://github.com/microsoft/TypeScript/issues/38496
  // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
  // @ts-ignore
  async start(): Promise<void> {
    if (this.options.databaseSeeding !== false) {
      await this.migrateSchema();
    }
    GoogleOAuth2.init();
    return super.start();
  }

  async migrateSchema(options?: SchemaMigrationOptions): Promise<void> {
    await super.migrateSchema(options);

    const accountRepo = await this.getRepository(AccountRepository);
    const roleGroupRepo = await this.getRepository(RoleGroupRepository);
    const tiketPriceRepo = await this.getRepository(TicketPriceRepository);

    await Promise.all(
      Configs.DefaultAdmins.map(async (defaultAdmin) => {
        let roleGroup = await roleGroupRepo.findOne({where: {name: defaultAdmin.roleGroupName}});
        if (!roleGroup) {
          roleGroup = await roleGroupRepo.create({name: defaultAdmin.roleGroupName});
        }
        if ((await accountRepo.count({email: defaultAdmin.email})).count === 0) {
          await accountRepo.createAccount(defaultAdmin);
        }
        const account = await accountRepo.findOne({where: {email: defaultAdmin.email}});
        if (account) {
          account.roleGroupId = roleGroup.id;
          await accountRepo.update(account);
        }
      }),
    );

    let tiketPrices = await tiketPriceRepo.find({order: ['viewIndex ASC']});
    if (tiketPrices.length === 0) {
      tiketPrices = await tiketPriceRepo.createAll(
        Configs.TicketPrices.map((item) => objectToEntity(item, TicketPrice)),
      );
    }
    tiketPrices.sort((a, b) => a.viewIndex - b.viewIndex);

    this.bind(AppBindings.TICKET_PRICES).to(tiketPrices);
  }
}
