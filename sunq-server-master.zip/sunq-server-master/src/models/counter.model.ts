import {Entity, model, property} from '@loopback/repository';

@model()
export class Counter extends Entity {
  @property({id: true})
  id: string;

  @property({required: true})
  modelName: string;

  @property({required: true})
  seq: number;

  constructor(data?: Partial<Counter>) {
    super(data);
  }
}

export interface CounterRelations {
  // describe navigational properties here
}

export type CounterWithRelations = Event & CounterRelations;
