import {hasMany, model, property} from '@loopback/repository';
import {Answer} from '../constants';
import {STEAM_CATEGORIES} from './../constants';
import {Timestamp} from './commons/timestamp.model';
import {LessonQuestion} from './lesson-question.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Question extends Timestamp {
  @property({id: true})
  id: string;

  // @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  @property({require: true})
  content: string;

  @property({require: true})
  a: string;

  @property({require: true})
  b: string;

  @property({require: true})
  c: string;

  @property({require: true})
  d: string;

  @property({require: true})
  answer: Answer;

  @property()
  classId: string;

  @property()
  ageId: string;

  @property()
  category: STEAM_CATEGORIES

  @property()
  interpretation: string;

  @hasMany(() => LessonQuestion, {name: 'lessonQuestions', keyFrom: 'id', keyTo: 'questionId'})
  lessonQuestions: LessonQuestion[];

  constructor(data?: Partial<Question>) {
    super(data);
  }
}

export interface QuestionRelations {
  // describe navigational properties here
}

export type QuestionWithRelations = Question & QuestionRelations;
