import {hasMany, model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';
import {Order} from './order.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Kit extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true})
  title: string;

  @property()
  description: string;

  @property({required: true})
  price: number;

  @property()
  shortDescription: string;

  @property.array(String)
  thumbnails: string[];

  @property.array(String)
  thumbnailUrls: string[];

  @hasMany(() => Lesson, {name: 'lessons', keyFrom: 'id', keyTo: 'kidId'})
  lessons: Lesson[];

  @hasMany(() => Order, {name: 'orders', keyFrom: 'id', keyTo: 'kidId'})
  orders: Order[];

  constructor(data?: Partial<Kit>) {
    super(data);
  }
}

export interface KitRelations {
  // describe navigational properties here
}

export type KitWithRelations = Kit & KitRelations;
