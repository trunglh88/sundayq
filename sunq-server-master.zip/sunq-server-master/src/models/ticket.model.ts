import {model, property} from '@loopback/repository';
import {RegexForm} from '../utils';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Ticket extends Timestamp {
  @property({id: true})
  id: string;

  @property({jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property({required: true})
  message: string;

  @property({default: false})
  isReplied: boolean;

  @property({default: false})
  isPaid: boolean;

  @property()
  adminNote: string;

  // @property()
  // price: number;

  // @property()
  // expiresAt: Date;

  // @property()
  // ticketId: string;

  @property()
  serviceId: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Ticket>) {
    super(data);
  }
}

export interface TicketRelations {
  // describe navigational properties here
}

export type TicketWithRelations = Ticket & TicketRelations;

