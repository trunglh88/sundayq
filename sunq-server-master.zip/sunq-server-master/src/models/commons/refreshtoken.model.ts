import {model, property} from '@loopback/repository';
import {Timestamp} from './timestamp.model';

@model()
export class Refreshtoken extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true})
  ttl: number;

  @property({required: true})
  userId: string;

  constructor(data?: Partial<Refreshtoken>) {
    super(data);
  }
}

export interface RefreshtokenRelations {
  // describe navigational properties here
}

export type RefreshtokenWithRelations = Refreshtoken & RefreshtokenRelations;
