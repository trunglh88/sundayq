import {Model, model, property} from '@loopback/repository';

@model()
export class GeoPoint extends Model {
  @property({jsonSchema: {minimum: -180, maximum: 180}})
  lat: number;

  @property({jsonSchema: {minimum: -180, maximum: 180}})
  lng: number;

  constructor(data?: Partial<GeoPoint>) {
    super(data);
  }
}

@model()
export class Contact extends Model {
  @property()
  phone: string;

  @property()
  facebookUrl: string;

  @property()
  website: string;

  constructor(data?: Partial<Contact>) {
    super(data);
  }
}

@model()
export class Address extends Model {
  @property()
  name: string;

  @property()
  location: GeoPoint;

  constructor(data?: Partial<Address>) {
    super(data);
  }
}
