import {Entity, model, property} from '@loopback/repository';

@model()
export class Timestamp extends Entity {
  @property()
  createAt: Date;

  @property()
  updateAt: Date;

  constructor(data?: Partial<Timestamp>) {
    super(data);
  }
}
