import {belongsTo, hasMany, model, Model, property} from '@loopback/repository';
import {Constants, Scope} from '../../constants';
import {Timestamp} from './timestamp.model';

@model()
export class Role extends Model {
  @property({required: true})
  resource: string;

  @property.array(String, {required: true, jsonSchema: {enum: Object.values(Scope)}})
  scopes: Scope[];
}

@model() //{description: 'Manage user role'}
export class RoleGroup extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true, index: {unique: true, name: 'uniqueName', key: 1}})
  name: string;

  @property.array(Role, {default: []})
  roles: Role[];

  @hasMany(() => Account, {name: 'accounts', keyFrom: 'id', keyTo: 'roleGroupId'})
  accounts: Account[];

  constructor(data?: Partial<RoleGroup>) {
    super(data);
  }
}

export interface RoleGroupRelations {
  // describe navigational properties here
}

export type RoleGroupWithRelations = RoleGroup & RoleGroupRelations;

/* ================================================================================================================= */
@model()
export class Account extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true, index: {unique: true, name: 'uniqueEmail', key: 1}})
  email: string;

  @property()
  phone?: string;

  @property({required: true})
  password: string;

  @property({required: true, default: 'member', jsonSchema: {enum: Object.values(Constants.ACCOUNT_TYPE)}})
  accountType: Constants.ACCOUNT_TYPE;

  @property({required: true, default: 'pending', jsonSchema: {enum: Object.values(Constants.ACCOUNT_STATE)}})
  state: Constants.ACCOUNT_STATE;

  @belongsTo(() => RoleGroup, {name: 'roleGroup', keyFrom: 'roleGroupId', keyTo: 'id'})
  roleGroupId: string;

  constructor(data?: Partial<Account>) {
    super(data);
  }
}

export interface AccountRelations {
  // describe navigational properties here
}

export type AccountWithRelations = Account & AccountRelations;
