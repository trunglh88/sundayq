import {hasMany, hasOne, model, property} from '@loopback/repository';
import {Account} from './account.model';
import {Refreshtoken} from './refreshtoken.model';
import {Timestamp} from './timestamp.model';

@model()
export class BaseUser extends Timestamp {
  @property({id: true})
  id: string;

  @hasOne(() => Account, {keyTo: 'id'})
  account: Account;

  @hasMany(() => Refreshtoken, {keyTo: 'userId'})
  refreshtokens: Refreshtoken[];

  @property({default: ''})
  imgUrl: string;

  @property({default: ''})
  name: string;

  @property({required: true, index: {unique: true, name: 'uniqueEmail', key: 1}})
  email: string;

  @property()
  phone?: string;

  constructor(data?: Partial<BaseUser>) {
    super(data);
  }
}
