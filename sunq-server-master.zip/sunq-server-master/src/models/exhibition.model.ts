import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Exhibition extends Timestamp {
  @property({id: true})
  id: string;

  @property({default: 999999999})
  viewIndex: number;

  @property({default: -1})
  minTargetAge: number;

  @property({default: -1})
  maxTargetAge: number;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<Exhibition>) {
    super(data);
  }
}

export interface ExhibitionRelations {
  // describe navigational properties here
}

export type ExhibitionWithRelations = Exhibition & ExhibitionRelations;
