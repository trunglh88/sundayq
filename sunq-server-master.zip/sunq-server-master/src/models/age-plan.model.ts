import {belongsTo, model, property} from '@loopback/repository';
import {Age} from './age.model';
import {Timestamp} from './commons/timestamp.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class AgePlan extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true})
  title: string;

  @property({required: true})
  month: number;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  thumbnail: string;

  @property()
  thumbnailUrl: string;

  @belongsTo(() => Age, {name: 'age', keyFrom: 'ageId'})
  ageId: string;

  constructor(data?: Partial<AgePlan>) {
    super(data);
  }
}

export interface AgePlanRelations {
  // describe navigational properties here
}

export type AgePlanWithRelations = AgePlan & AgePlanRelations;
