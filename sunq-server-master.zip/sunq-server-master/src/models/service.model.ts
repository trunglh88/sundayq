import {hasMany, model, property} from '@loopback/repository';
import {Age} from './age.model';
import {Category} from './category.model';
import {Class} from './class.model';
import {Timestamp} from './commons/timestamp.model';
import {ServiceMember} from './service-member.model';
import {ServiceResource} from './service-resource.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Service extends Timestamp {
  @property({id: true})
  id: string;

  @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  name: string;

  @property()
  price: number;

  @property()
  description: string;

  @property()
  thumbnailUrl: string;

  @property({require: true})
  code: number;

  @property({default: 0})
  discount: number;

  @hasMany(() => ServiceMember, {name: 'serviceMembers', keyFrom: 'id', keyTo: 'serviceId'})
  serviceMembers: ServiceMember[];

  @hasMany(() => ServiceResource, {name: 'serviceResources', keyFrom: 'id', keyTo: 'serviceId'})
  serviceResources: ServiceResource[];

  @hasMany(() => Age, {name: 'ages', keyFrom: 'id', keyTo: 'serviceId'})
  ages: Age[];

  @hasMany(() => Class, {name: 'classes', keyFrom: 'id', keyTo: 'serviceId'})
  classes: Class[];

  @hasMany(() => Category, {name: 'categories', keyFrom: 'id', keyTo: 'serviceId'})
  categories: Category[];

  constructor(data?: Partial<Service>) {
    super(data);
  }
}

export interface ServiceRelations {
  // describe navigational properties here
}

export type ServiceWithRelations = Service & ServiceRelations;
