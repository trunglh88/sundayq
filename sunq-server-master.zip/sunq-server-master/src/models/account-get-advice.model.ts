import {belongsTo, model, property} from '@loopback/repository';
import {RegexForm} from '../utils';
import {Timestamp} from './commons/timestamp.model';
import {Course} from './course.model';

@model()
export class AccountGetAdvice extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true, jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({required: true, jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property()
  note: string;

  @belongsTo(() => Course, {name: 'course', keyFrom: 'courseId'})
  courseId: string;

  @property()
  isGotAdvice: boolean;

  @property()
  adminNote: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<AccountGetAdvice>) {
    super(data);
  }
}

export interface AccountGetAdviceRelations {
  // describe navigational properties here
}

export type AccountGetAdviceWithRelations = AccountGetAdvice & AccountGetAdviceRelations;
