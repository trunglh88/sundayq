import {belongsTo, model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';
import {Member} from './member.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class LessonMember extends Timestamp {
  @property({id: true})
  id: string;

  @belongsTo(() => Lesson, {name: 'lesson', keyFrom: 'lessonId', keyTo: 'id'})
  lessonId: string;

  @belongsTo(() => Member, {name: 'member', keyFrom: 'memberId', keyTo: 'id'})
  memberId: string;

  constructor(data?: Partial<LessonMember>) {
    super(data);
  }
}

export interface LessonMemberRelations {
  // describe navigational properties here
}

export type LessonMemberWithRelations = LessonMember & LessonMemberRelations;
