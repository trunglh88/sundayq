import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Event extends Timestamp {
  @property({id: true})
  id: string;

  @property({default: 999999999})
  viewIndex: number;

  @property()
  startAt: Date;

  @property()
  finishAt: Date;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  @property()
  serviceId: string;

  constructor(data?: Partial<Event>) {
    super(data);
  }
}

export interface EventRelations {
  // describe navigational properties here
}

export type EventWithRelations = Event & EventRelations;
