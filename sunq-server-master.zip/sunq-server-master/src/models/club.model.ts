import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Club extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  viewIndex: number;

  @property()
  title: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<Club>) {
    super(data);
  }
}

export interface ClubRelations {
  // describe navigational properties here
}

export type ClubWithRelations = Club & ClubRelations;
