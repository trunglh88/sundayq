import {belongsTo, model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';
import {Question} from './question.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class LessonQuestion extends Timestamp {
  @property({id: true})
  id: string;

  @belongsTo(() => Lesson, {name: 'lesson', keyFrom: 'lessonId'})
  lessonId: string;

  @belongsTo(() => Question, {name: 'question', keyFrom: 'questionId'})
  questionId: string;

  constructor(data?: Partial<LessonQuestion>) {
    super(data);
  }
}

export interface LessonQuestionRelations {
  // describe navigational properties here
}

export type LessonQuestionWithRelations = LessonQuestion & LessonQuestionRelations;
