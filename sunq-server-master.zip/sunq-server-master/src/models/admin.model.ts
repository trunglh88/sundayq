import {model} from '@loopback/repository';
import {BaseUser} from './commons/base-user.model';

@model()
export class Admin extends BaseUser {
  constructor(data?: Partial<Admin>) {
    super(data);
  }
}

export interface AdminRelations {
  // describe navigational properties here
}

export type AdminWithRelations = Admin & AdminRelations;
