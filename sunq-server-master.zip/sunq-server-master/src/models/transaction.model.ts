import {belongsTo, model, property} from '@loopback/repository';
import {TransactionStatus, TransactionType} from '../constants';
import {Account} from './commons/account.model';
import {Timestamp} from './commons/timestamp.model';
import {Order} from './order.model';
import {ServiceMember} from './service-member.model';

@model()
export class Transaction extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  amount: number;

  @property()
  txnRef: number;

  @property()
  orderInfo: string;

  @property()
  locale: string;

  @property()
  thumbnailUrl: string;

  @property()
  transactionType: TransactionType;

  @property()
  responseCode: string;

  @property()
  status: TransactionStatus;

  @belongsTo(() => Order, {name: 'order', keyFrom: 'orderId', keyTo: 'id'})
  orderId: string;

  @belongsTo(() => ServiceMember, {name: 'serviceMember', keyFrom: 'serviceMemberId', keyTo: 'id'})
  serviceMemberId: string;

  @belongsTo(() => Account, {name: 'sender', keyFrom: 'senderId', keyTo: 'id'})
  senderId: string;

  constructor(data?: Partial<Transaction>) {
    super(data);
  }
}

export interface TransactionRelations {
  // describe navigational properties here
}

export type TransactionWithRelations = Transaction & TransactionRelations;
