import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Log extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  api: string;

  @property()
  description: string;

  @property.array(Object)
  params: object[];

  constructor(data?: Partial<Log>) {
    super(data);
  }
}

export interface LogRelations {
  // describe navigational properties here
}

export type LogWithRelations = Log & LogRelations;
