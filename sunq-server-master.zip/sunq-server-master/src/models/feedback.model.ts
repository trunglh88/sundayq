import {model, property} from '@loopback/repository';
import {RegexForm} from '../utils';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Feedback extends Timestamp {
  @property({id: true})
  id: string;

  @property({jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property({required: true})
  message: string;

  @property()
  serviceId: string;

  @property({default: false})
  isReplied: boolean;

  @property()
  adminNote: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Feedback>) {
    super(data);
  }
}

export interface FeedbackRelations {
  // describe navigational properties here
}

export type FeedbackWithRelations = Feedback & FeedbackRelations;
