import {hasMany, model} from '@loopback/repository';
import {BaseUser} from './commons/base-user.model';
import {ServiceMember} from './service-member.model';

@model()
export class Member extends BaseUser {
  @hasMany(() => ServiceMember, {name: 'serviceMembers', keyFrom: 'id', keyTo: 'memberId'})
  serviceMembers: ServiceMember[];

  constructor(data?: Partial<Member>) {
    super(data);
  }
}

export interface MemberRelations {
  // describe navigational properties here
}

export type MemberWithRelations = Member & MemberRelations;
