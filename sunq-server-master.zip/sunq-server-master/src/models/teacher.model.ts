import {model, property} from '@loopback/repository';
import {BaseUser} from './commons/base-user.model';

@model()
export class Teacher extends BaseUser {
  @property({required: true, index: {unique: true, name: 'uniqueShortId', key: 2}})
  shortId: string;

  @property()
  university: string;

  @property()
  degree: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  specialist: string;

  @property()
  practiceAt: Date;

  constructor(data?: Partial<Teacher>) {
    super(data);
  }
}

export interface TeacherRelations {
  // describe navigational properties here
}

export type TeacherWithRelations = Teacher & TeacherRelations;
