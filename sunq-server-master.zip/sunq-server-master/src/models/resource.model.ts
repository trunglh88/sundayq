import {hasMany, model, property} from '@loopback/repository';
import {Constants} from '../constants';
import {Timestamp} from './commons/timestamp.model';
import {LessonResource} from './lesson-resource.model';
import {ServiceResource} from './service-resource.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Resource extends Timestamp {
  @property({id: true})
  id: string;

  // @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  @property({require: false})
  title: string;

  @property({require: false})
  fileName: string;

  @property({require: false})
  fileUrl: string;

  @property({require: false})
  description: string;

  @property({require: false})
  shortDescription: string;

  @property({require: false})
  thumbnail: string;

  @property({require: false})
  thumbnailUrl: string;

  @property({require: true})
  fileType: Constants.FILE_TYPE;

  @property({require: true, default: Constants.UPLOAD_STATUS.CREATE})
  status: Constants.UPLOAD_STATUS;

  @hasMany(() => LessonResource, {name: 'lessonResources', keyFrom: 'id', keyTo: 'resourceId'})
  lessonResources: LessonResource[];

  @hasMany(() => LessonResource, {name: 'serviceResources', keyFrom: 'id', keyTo: 'resourceId'})
  serviceResources: ServiceResource[];

  constructor(data?: Partial<Resource>) {
    super(data);
  }
}

export interface ResourceRelations {
  // describe navigational properties here
}

export type ResourceWithRelations = Resource & ResourceRelations;
