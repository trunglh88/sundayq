import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {Kit} from '.';
import {Constants} from '../constants';
import {RegexForm} from '../utils';
import {Timestamp} from './commons/timestamp.model';
import {Transaction} from './transaction.model';

@model()
export class Order extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true, jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property({required: true, default: Constants.ORDER_STATUS.PENDING})
  status: Constants.ORDER_STATUS;

  @belongsTo(() => Kit, {name: 'kit', keyFrom: 'kitId'})
  kitId: string;

  @hasMany(() => Transaction, {name: 'transactions', keyFrom: 'id', keyTo: 'orderId'})
  transactions: Transaction[];

  constructor(data?: Partial<Order>) {
    super(data);
  }
}

export interface OrderRelations {
  // describe navigational properties here
}

export type OrderWithRelations = Order & OrderRelations;
