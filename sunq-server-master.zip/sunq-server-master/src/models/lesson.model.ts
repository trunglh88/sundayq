import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {Teacher} from '.';
import {STEAM_CATEGORIES} from '../constants';
import {Age} from './age.model';
import {Class} from './class.model';
import {Timestamp} from './commons/timestamp.model';
import {Kit} from './kit.model';
import {LessonMember} from './lesson-member.model';
import {LessonQuestion} from './lesson-question.model';
import {LessonResource} from './lesson-resource.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Lesson extends Timestamp {
  @property({id: true})
  id: string;

  // @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  @property({require: false})
  title: string;

  @property({require: true})
  month: number;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  thumbnailUrl: string;

  @property()
  category: STEAM_CATEGORIES;

  @property({require: true, default: false})
  isSampleLesson: boolean;

  @belongsTo(() => Age, {name: 'age', keyFrom: 'ageId'})
  ageId: string;

  @belongsTo(() => Class, {name: 'class', keyFrom: 'classId'})
  classId: string;

  @belongsTo(() => Kit, {name: 'kit', keyFrom: 'kitId'})
  kitId: string;

  @hasMany(() => LessonResource, {name: 'lessonResources', keyFrom: 'id', keyTo: 'lessonId'})
  lessonResources: LessonResource[];

  @hasMany(() => LessonMember, {name: 'lessonMembers', keyFrom: 'id', keyTo: 'lessonId'})
  lessonMembers: LessonMember[];

  @hasMany(() => LessonQuestion, {name: 'lessonQuestions', keyFrom: 'id', keyTo: 'lessonId'})
  lessonQuestions: LessonQuestion[];

  @belongsTo(() => Teacher, {name: 'teacher', keyFrom: 'teacherId'})
  teacherId: string;

  constructor(data?: Partial<Lesson>) {
    super(data);
  }
}

export interface LessonRelations {
  // describe navigational properties here
}

export type LessonWithRelations = Lesson & LessonRelations;
