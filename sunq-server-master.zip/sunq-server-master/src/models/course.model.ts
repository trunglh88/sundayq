import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {AccountGetAdvice} from './account-get-advice.model';
import {Timestamp} from './commons/timestamp.model';
import {CoursePlan} from './course-plan.model';
import {Teacher} from './teacher.model';

@model()
export class Course extends Timestamp {
  @property({id: true})
  id: string;

  @property({default: 999999999})
  viewIndex: number;

  @property({default: -1})
  minTargetAge: number;

  @property({default: -1})
  maxTargetAge: number;

  @property({required: true})
  courseType: string;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  @property.array(String)
  otherImgUrls: string[];

  @hasMany(() => CourseOwner, {name: 'owners', keyFrom: 'id', keyTo: 'courseId'})
  owners: CourseOwner[];

  @hasMany(() => CoursePlan, {name: 'coursePlans', keyFrom: 'id', keyTo: 'courseId'})
  coursePlans: CoursePlan[];

  @hasMany(() => AccountGetAdvice, {name: 'accountGetAdvices', keyFrom: 'id', keyTo: 'courseId'})
  accountGetAdvices: AccountGetAdvice[];

  constructor(data?: Partial<Course>) {
    super(data);
  }
}

export interface CourseRelations {
  // describe navigational properties here
}

export type CourseWithRelations = Course & CourseRelations;

/* ================================================================================================================= */
@model()
export class CourseOwner extends Timestamp {
  @property({id: true})
  id: string;

  @belongsTo(() => Course, {name: 'course', keyFrom: 'courseId', keyTo: 'id'})
  courseId: string;

  @belongsTo(() => Teacher, {name: 'teacher', keyFrom: 'teacherId', keyTo: 'id'})
  teacherId: string;

  constructor(data?: Partial<CourseOwner>) {
    super(data);
  }
}

export interface CourseOwnerRelations {
  // describe navigational properties here
}

export type CourseOwnerWithRelations = CourseOwner & CourseOwnerRelations;
