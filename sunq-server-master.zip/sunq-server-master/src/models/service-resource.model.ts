import {belongsTo, model, property} from '@loopback/repository';
import {Resource} from '.';
import {Timestamp} from './commons/timestamp.model';
import {Service} from './service.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class ServiceResource extends Timestamp {
  @property({id: true})
  id: string;

  @belongsTo(() => Service, {name: 'service', keyFrom: 'serviceId'})
  serviceId: string;

  @belongsTo(() => Resource, {name: 'resource', keyFrom: 'resourceId'})
  resourceId: string;

  constructor(data?: Partial<ServiceResource>) {
    super(data);
  }
}

export interface ServiceResourceRelations {
  // describe navigational properties here
}

export type ServiceResourceWithRelations = ServiceResource & ServiceResourceRelations;
