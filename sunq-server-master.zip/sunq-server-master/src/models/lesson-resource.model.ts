import {belongsTo, model, property} from '@loopback/repository';
import {Resource} from '.';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class LessonResource extends Timestamp {
  @property({id: true})
  id: string;

  @belongsTo(() => Lesson, {name: 'lesson', keyFrom: 'lessonId'})
  lessonId: string;

  @belongsTo(() => Resource, {name: 'resource', keyFrom: 'resourceId'})
  resourceId: string;

  constructor(data?: Partial<LessonResource>) {
    super(data);
  }
}

export interface LessonResourceRelations {
  // describe navigational properties here
}

export type LessonResourceWithRelations = LessonResource & LessonResourceRelations;
