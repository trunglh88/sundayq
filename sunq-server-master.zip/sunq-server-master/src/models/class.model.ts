import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';
import {Service} from './service.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Class extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true})
  type: number;

  @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  description: string;

  @belongsTo(() => Service, {name: 'service', keyFrom: 'serviceId'})
  serviceId: string;

  @hasMany(() => Lesson, {name: 'lessons', keyFrom: 'id', keyTo: 'classId'})
  lessons: Lesson[];

  constructor(data?: Partial<Class>) {
    super(data);
  }
}

export interface ClassRelations {
  // describe navigational properties here
}

export type ClassWithRelations = Class & ClassRelations;
