import {belongsTo, model, property, hasMany} from '@loopback/repository';
import {Constants} from '../constants';
import {Timestamp} from './commons/timestamp.model';
import {Member} from './member.model';
import {Service} from './service.model';
import {Transaction} from './transaction.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class ServiceMember extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  startTime: Date;

  @property()
  endTime: Date;

  @property()
  status: Constants.SERVICE_STATUS;

  @belongsTo(() => Service, {name: 'service', keyFrom: 'serviceId', keyTo: 'id'})
  serviceId: string;

  @belongsTo(() => Member, {name: 'member', keyFrom: 'memberId', keyTo: 'id'})
  memberId: string;

  @hasMany(() => Transaction, {name: 'transactions', keyFrom: 'id', keyTo: 'orderId'})
  transactions: Transaction[];

  constructor(data?: Partial<ServiceMember>) {
    super(data);
  }
}

export interface ServiceMemberRelations {
  // describe navigational properties here
}

export type ServiceMemberWithRelations = ServiceMember & ServiceMemberRelations;
