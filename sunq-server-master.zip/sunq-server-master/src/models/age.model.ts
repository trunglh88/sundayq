import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {AgePlan} from './age-plan.model';
import {Category} from './category.model';
import {Timestamp} from './commons/timestamp.model';
import {Lesson} from './lesson.model';
import {Service} from './service.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class Age extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true})
  type: number;

  @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  description: string;

  @belongsTo(() => Service, {name: 'service', keyFrom: 'serviceId'})
  serviceId: string;

  @belongsTo(() => Category, {name: 'category', keyFrom: 'categoryId'})
  categoryId: string;

  @hasMany(() => Lesson, {name: 'lessons', keyFrom: 'id', keyTo: 'ageId'})
  lessons: Lesson[];

  @hasMany(() => AgePlan, {name: 'agePlans', keyFrom: 'id', keyTo: 'ageId'})
  agePlans: AgePlan[];

  constructor(data?: Partial<Age>) {
    super(data);
  }
}

export interface AgeRelations {
  // describe navigational properties here
}

export type AgeWithRelations = Age & AgeRelations;
