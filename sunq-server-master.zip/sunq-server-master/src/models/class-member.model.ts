import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {Class} from './class.model';
import {Timestamp} from './commons/timestamp.model';
import {Member} from './member.model';
import {Transaction} from './transaction.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class ClassMember extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  startTime: Date;

  @property()
  endTime: Date;

  @property()
  studyMonth: any;

  @property()
  startOfMonth: any;

  @belongsTo(() => Class, {name: 'class', keyFrom: 'classId', keyTo: 'id'})
  classId: string;

  @belongsTo(() => Member, {name: 'member', keyFrom: 'memberId', keyTo: 'id'})
  memberId: string;

  @hasMany(() => Transaction, {name: 'transactions', keyFrom: 'id', keyTo: 'orderId'})
  transactions: Transaction[];

  constructor(data?: Partial<ClassMember>) {
    super(data);
  }
}

export interface ClassMemberRelations {
  // describe navigational properties here
}

export type ClassMemberWithRelations = ClassMember & ClassMemberRelations;
