import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {Age} from './age.model';
import {Timestamp} from './commons/timestamp.model';
import {Service} from './service.model';

@model()
export class Category extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  name: string;

  @property()
  type: number;

  @property()
  description: string;

  @belongsTo(() => Service, {name: 'service', keyFrom: 'serviceId'})
  serviceId: string;

  @hasMany(() => Age, {name: 'ages', keyFrom: 'id', keyTo: 'categoryId'})
  ages: Age[];

  constructor(data?: Partial<Category>) {
    super(data);
  }
}

export interface CategoryRelations {
  // describe navigational properties here
}

export type CategoryWithRelations = Category & CategoryRelations;
