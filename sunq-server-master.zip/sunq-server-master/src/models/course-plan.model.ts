import {belongsTo, model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';
import {Course} from './course.model';
import {Teacher} from './teacher.model';

@model()
export class CoursePlan extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  dayIndex: number;

  @property({required: true})
  title: string;

  @property()
  description: string;

  @property()
  time: string;

  @belongsTo(() => Teacher, {name: 'teacher', keyFrom: 'teacherId'})
  teacherId: string;

  @belongsTo(() => Teacher, {name: 'supporter', keyFrom: 'supporterId'})
  supporterId: string;

  @belongsTo(() => Course, {name: 'course', keyFrom: 'courseId', keyTo: 'id'})
  courseId: string;

  constructor(data?: Partial<CoursePlan>) {
    super(data);
  }
}

export interface CoursePlanRelations {
  // describe navigational properties here
}

export type CoursePlanWithRelations = CoursePlan & CoursePlanRelations;
