import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model()
export class Otp extends Timestamp {
  @property({id: true})
  id: string;

  @property({required: true, index: {unique: true, name: 'uniqueEmail', key: 1}})
  email: string;

  @property({required: true})
  code: string;

  constructor(data?: Partial<Otp>) {
    super(data);
  }
}

export interface OtpRelations {
  // describe navigational properties here
}

export type OtpWithRelations = Otp & OtpRelations;
