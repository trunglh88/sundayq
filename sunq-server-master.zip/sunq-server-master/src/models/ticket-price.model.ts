import {model, property} from '@loopback/repository';
import {Timestamp} from './commons/timestamp.model';

@model({settings: {hiddenProperties: ['createAt', 'updateAt']}})
export class TicketPrice extends Timestamp {
  @property({id: true})
  id: string;

  @property()
  viewIndex: number;

  @property()
  target: string;

  @property()
  price: number;

  @property()
  perUnit: string;

  constructor(data?: Partial<TicketPrice>) {
    super(data);
  }
}

export interface TicketPriceRelations {
  // describe navigational properties here
}

export type TicketPriceWithRelations = TicketPrice & TicketPriceRelations;
