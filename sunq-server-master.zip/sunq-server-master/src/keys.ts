import {TokenService, UserService} from '@loopback/authentication';
import {BindingKey} from '@loopback/context';
import {ApplicationWithRepositories} from '@loopback/repository';
import {Scope} from './constants';
import {Credentials} from './model-forms';
import {Account, RoleGroup, TicketPrice} from './models';
import {RefreshtokenService} from './services/refreshtoken.service';
import {PasswordHasher} from './utils/hash-password.util';

export namespace AppBindings {
  export const APP = BindingKey.create<ApplicationWithRepositories>('application.instance');
  export const TICKET_PRICES = BindingKey.create<TicketPrice[]>('application.ticketprices');
}

export namespace RoleBindings {
  export const ROLEGROUP = BindingKey.create<RoleGroup>('rolebinding.rolegroup');
  export const RESOURCE = BindingKey.create<string>('rolebinding.resource');
  export const SCOPE = BindingKey.create<Scope[]>('rolebinding.scope');
}

export namespace RequestBindings {
  export const IP = BindingKey.create<string>('request.info.ip');
}

export namespace TokenServiceConstants {
  export const TOKEN_SECRET_VALUE = 'TMsoDJXp3hPK77Bc8R';
  export const TOKEN_EXPIRES_IN_VALUE = (30 * 24 * 60 * 60).toString();
}

export namespace TokenServiceBindings {
  export const TOKEN_SECRET = BindingKey.create<string>('authentication.jwt.secret');
  export const TOKEN_EXPIRES_IN = BindingKey.create<string>('authentication.jwt.expires.in.seconds');
  export const TOKEN_SERVICE = BindingKey.create<TokenService>('services.authentication.jwt.tokenservice');
}

export namespace PasswordHasherBindings {
  export const PASSWORD_HASHER = BindingKey.create<PasswordHasher>('services.hasher');
  export const ROUNDS = BindingKey.create<number>('services.hasher.round');
}

export namespace AccountServiceBindings {
  export const ACCOUNT_SERVICE = BindingKey.create<UserService<Account, Credentials>>('services.account.service');
}

export namespace RefreshtokenServiceBindings {
  export const REFRESHTOKEN_ETERNAL_ALLOWED = BindingKey.create<boolean>('services.refreshtoken.eternal_allowed');
  export const REFRESHTOKEN_EXPIRES_IN = BindingKey.create<number>('services.refreshtoken.expires_in');
  export const REFRESHTOKEN_SERVICE = BindingKey.create<RefreshtokenService>('services.refreshtoken.service');
}
