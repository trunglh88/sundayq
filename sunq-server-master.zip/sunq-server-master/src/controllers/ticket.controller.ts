import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {AnyObject, repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {EmptyResponse, TicketRequestBody, UpdateTicketRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {Ticket} from '../models';
import {TicketRepository} from '../repositories';
import {res, spec} from '../utils';

export class TicketController {
  constructor(@repository(TicketRepository) private ticketRepo: TicketRepository) {}

  @get('/tickets', spec(Ticket, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Ticket),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAll(
    @param.query.string('email') email?: string,
    @param.query.string('phone') phone?: string,
    @param.query.string('service') service?: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const where: AnyObject = {};
    if (email) where.email = email;
    if (phone) where.phone = phone;
    if (service) where.serviceId = service;
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const order = ['createAt DESC'];
    const tickets = await this.ticketRepo.find({
      where: where,
      skip: skip,
      limit: limit,
      order: order,
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.ticketRepo.count(where)).count,
      data: tickets,
    });
  }

  @get('/ticket/{tkid}', spec(Ticket))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Ticket),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getByID(@param.path.string('tkid') tkid: string) {
    if (!(await this.ticketRepo.exists(tkid))) {
      throw new AppResponse({code: 404});
    }
    return new AppResponse({data: await this.ticketRepo.findById(tkid)});
  }

  @post('/ticket/{service}', spec(Ticket, {auth: false}))
  async create(
    @param.path.string('service', {description: 'q-visit', schema: {pattern: '(q-visit)'}})
    service: string,
    @requestBody() body: TicketRequestBody,
  ) {
    body.serviceId = service;
    const ticket = await this.ticketRepo.create(body);
    return new AppResponse({data: ticket});
  }

  @put('/ticket/{tkid}', spec(Ticket))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Ticket),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('tkid') tkid: string, @requestBody() body: UpdateTicketRequestBody) {
    if (!(await this.ticketRepo.exists(tkid))) {
      throw new AppResponse({code: 404});
    }
    await this.ticketRepo.updateById(tkid, body);
    const ticket = await this.ticketRepo.findById(tkid);
    return new AppResponse({data: ticket});
  }

  @del('/ticket/{tkid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Ticket),
    scopes: [Scope.DELETE],
    voters: [basicAuthor],
  })
  async delById(@param.path.string('tkid') tkid: string) {
    if (!(await this.ticketRepo.exists(tkid))) {
      throw new AppResponse();
    }
    await this.ticketRepo.deleteById(tkid);
    return new AppResponse();
  }
}

