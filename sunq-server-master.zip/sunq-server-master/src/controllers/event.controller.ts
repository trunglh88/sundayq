import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {AnyObject, repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {EmptyResponse, EventRequestBody, UpdateEventRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {Event} from '../models';
import {EventRepository} from '../repositories';
import {res, spec} from '../utils';

export class EventController {
  constructor(@repository(EventRepository) private eventRepo: EventRepository) {}

  @get('/events', spec(Event, {array: true, auth: false}))
  async getAll(
    @param.query.string('title') title?: string,
    @param.query.dateTime('startAt') startAt?: Date,
    @param.query.dateTime('finishAt') finishAt?: Date,
    @param.query.string('service') service?: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const where: AnyObject = {};
    if (title) where.title = {like: title};
    if (startAt) where.startAt = {gte: startAt};
    if (finishAt) where.finishAt = {lte: finishAt};
    if (service) where.serviceId = service;
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const order = ['viewIndex ASC', 'startAt DESC', 'createAt DESC'];
    const events = await this.eventRepo.find({
      where: where,
      skip: skip,
      limit: limit,
      order: order,
      fields: {description: false},
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.eventRepo.count(where)).count,
      data: events,
    });
  }

  @get('/event/{eid}', spec(Event, {auth: false}))
  async getByID(@param.path.string('eid') eid: string) {
    if (!(await this.eventRepo.exists(eid))) {
      throw new AppResponse({code: 404});
    }
    return new AppResponse({data: await this.eventRepo.findById(eid)});
  }

  @post('/event/{service}', spec(Event))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Event),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(
    @param.path.string('service', {description: 'q-visit', schema: {pattern: '(q-visit)'}})
    service: string,
    @requestBody() body: EventRequestBody,
  ) {
    body.serviceId = service;
    const event = await this.eventRepo.create(body);
    return new AppResponse({data: event});
  }

  @put('/event/{eid}', spec(Event))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Event),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('eid') eid: string, @requestBody() body: UpdateEventRequestBody) {
    if (!(await this.eventRepo.exists(eid))) {
      throw new AppResponse({code: 404});
    }
    await this.eventRepo.updateById(eid, body);
    const event = await this.eventRepo.findById(eid);
    return new AppResponse({data: event});
  }

  @del('/event/{eid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Event),
    scopes: [Scope.DELETE],
    voters: [basicAuthor],
  })
  async delById(@param.path.string('eid') eid: string) {
    if (!(await this.eventRepo.exists(eid))) {
      throw new AppResponse();
    }
    await this.eventRepo.deleteById(eid);
    return new AppResponse();
  }
}
