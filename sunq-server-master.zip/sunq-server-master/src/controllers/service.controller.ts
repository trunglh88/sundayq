import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {AnyObject, repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {ServiceRequestBody, UpdateServiceRequestBody} from '../model-forms/requests/service.request';
import {ServiceResponse, ServicesResponse} from '../model-forms/responses/service.response';
import {Account} from '../models';
import {CounterRepository} from '../repositories/counter.repository';
import {ServiceResourceRepository} from '../repositories/service-resource.repository';
import {ServiceRepository} from '../repositories/service.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

export class ServiceController {
  constructor(@repository(ServiceRepository) public serviceRepo: ServiceRepository,
    @repository(ServiceResourceRepository) public serviceResourceRepo: ServiceResourceRepository,
    @repository(CounterRepository) public counterRepo: CounterRepository,) { }

  @post('/services', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createService(@requestBody() body: ServiceRequestBody) {
    try {
      const resources = body.resources;
      const bodyObject = JSON.parse(JSON.stringify(body));
      delete bodyObject.resources;
      bodyObject.code = await this.counterRepo.nextCounter('service');
      const service = await this.serviceRepo.create(bodyObject);
      if (resources) {
        Promise.all(resources.map((resourceId) => this.serviceResourceRepo.create({resourceId, serviceId: service.id})));
      }

      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }

  @put('/service/{sid}/{serviceCode}', spec(EmptyResponse))
  async updateServiceCode(@param.path.string('sid') serviceId: string, @param.path.number('serviceCode') serviceCode: number,) {
    let service = await this.serviceRepo.findById(serviceId);
    service = JSON.parse(JSON.stringify(service));
    service.code = serviceCode;
    this.serviceRepo.updateById(serviceId, service);
    return "success";
  }

  @put('/service/{sid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editService(@param.path.string('sid') serviceId: string, @requestBody() body: UpdateServiceRequestBody) {
    if (!(await this.serviceRepo.exists(serviceId))) {
      throw new AppResponse({code: 404, message: 'Service not found.'});
    }
    try {
      const service = await this.serviceRepo.findById(serviceId);
      if (!service) {
        throw new AppResponse({code: 404, message: MessageService.getMessage(Message.SERVICE_NOT_FOUND)});
      }
      const oldResources =
        (await this.serviceRepo.serviceResources(serviceId).find({fields: {resourceId: true}})).map(
          (serviceResource) => serviceResource.resourceId,
        ) || [];

      const resources = body.resources || [];
      // const bodyObject = JSON.parse(JSON.stringify(body));
      delete (body as AnyObject).resources;
      await this.serviceRepo.updateById(service.id, body);
      await Promise.all(
        resources
          .filter((resourceId) => oldResources.indexOf(resourceId) < 0)
          .map((resourceId) => this.serviceResourceRepo.create({resourceId, serviceId})),
      );
      await Promise.all(
        oldResources
          .filter((resourceId) => resources.indexOf(resourceId) < 0)
          .map((resourceId) => this.serviceResourceRepo.deleteAll({resourceId, serviceId})),
      );

      // await this.serviceRepo.updateById(serviceId, body);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }

  @del('/service/{serviceId}')
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delService(@param.path.string('serviceId') serviceId: string) {
    if (!(await this.serviceRepo.findById(serviceId))) {
      return new AppResponse();
    }
    await this.serviceRepo.deleteById(serviceId);
    return new AppResponse();
  }

  @get('/services', spec(ServicesResponse, {}, 'Service list'))
  // @authenticate('jwt')
  async getServices(): Promise<object> {
    let services = await this.serviceRepo.find({include: [{relation: 'serviceResources', scope: {include: [{relation: 'resource'}]}}]});

    if (services) {
      services = JSON.parse(JSON.stringify(services));
      services = services.map(service => {
        if (service.serviceResources) {
          let serviceResources = JSON.parse(JSON.stringify(service.serviceResources));

          if (serviceResources.length > 0) {

            serviceResources = serviceResources.map((lessonResource: {resource: any}) => lessonResource.resource);

            delete service.serviceResources;
            Object.assign(service, {video: serviceResources[0]});
          }
        }
        return service;
      })

      //   lesson. = lessonResources;
      //   console.log(JSON.stringify(lesson));
    }
    return new AppResponse({data: {services: services}});
  }

  @get('/service/{serviceId}', spec(ServiceResponse))
  @authenticate('jwt')
  async getService(@param.path.string('serviceId') serviceId: string): Promise<object> {
    const service = await this.serviceRepo.findById(serviceId);

    return new AppResponse({data: service});
  }
}
