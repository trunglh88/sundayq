import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {Inclusion, repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {CourseInfoResponse, CreateCourseRequestBody, EmptyResponse, UpdateCourseRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {Course, CoursePlan} from '../models';
import {CourseOwnerRepository, CourseRepository} from '../repositories/course.repository';
import {CoursePlanRepository} from '../repositories/courseplan.repository';
import {objectsToEntities, objectToEntity, res, spec} from '../utils';

export class CourseController {
  constructor(
    @repository(CourseRepository) private courseRepo: CourseRepository,
    @repository(CourseOwnerRepository) private courseOwnerRepo: CourseOwnerRepository,
    @repository(CoursePlanRepository) private coursePlanRepo: CoursePlanRepository,
  ) {}

  @get('/courses', spec(Course, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Course),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAll(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const include = [{relation: 'owners', scope: {include: [{relation: 'teacher'}]}}];
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const courses = await this.courseRepo.find({
      include: include,
      skip: skip,
      limit: limit,
      fields: {description: false},
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.courseRepo.count()).count,
      data: courses,
    });
  }

  @get('/course/{cid}', spec(Course))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Course),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getByID(@param.path.string('cid') cid: string) {
    if (!(await this.courseRepo.exists(cid))) {
      throw new AppResponse({code: 404});
    }
    const include: Inclusion[] = [
      {relation: 'owners', scope: {include: [{relation: 'teacher'}]}},
      {
        relation: 'coursePlans',
        scope: {include: [{relation: 'teacher'}, {relation: 'supporter'}], order: ['dayIndex: ASC']},
      },
      {relation: 'accountGetAdvices'},
    ];
    return new AppResponse({data: await this.courseRepo.findById(cid, {include: include})});
  }

  @get('/course/top', spec(CourseInfoResponse, {auth: false, array: true}))
  async getTop(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const order = ['viewIndex ASC', 'createAt DESC'];
    const courses = await this.courseRepo.find({
      skip: skip,
      limit: limit,
      order: order,
      fields: {description: false},
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.courseRepo.count()).count,
      data: objectsToEntities(courses, CourseInfoResponse),
    });
  }

  @get('/course/suggestion/{cid}', spec(CourseInfoResponse, {auth: false, array: true}))
  async getSuggestion(@param.path.string('cid') uid: string) {
    const courses = await this.courseRepo.find({limit: 12, order: ['viewIndex ASC', 'createAt DESC']});
    return new AppResponse({data: objectsToEntities(courses, CourseInfoResponse)});
  }

  @get('/course/info/{cid}', spec(CourseInfoResponse, {auth: false}))
  async getById(@param.path.string('cid') uid: string) {
    if (!(await this.courseRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    const include: Inclusion[] = [
      {relation: 'owners', scope: {include: [{relation: 'teacher'}]}},
      {
        relation: 'coursePlans',
        scope: {include: [{relation: 'teacher'}, {relation: 'supporter'}], order: ['dayIndex: ASC']},
      },
    ];
    const course = await this.courseRepo.findById(uid, {include: include});
    return new AppResponse({data: objectToEntity(course, CourseInfoResponse)});
  }

  @post('/course', spec(Course))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Course),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(@requestBody() body: CreateCourseRequestBody) {
    const owners = body.ownerIds ?? [];
    const coursePlans = body.coursePlans ?? [];
    let course = objectToEntity(body, Course);

    course = await this.courseRepo.create(course);
    if (owners.length > 0) {
      await Promise.all(
        owners.map(async (ownerId) => {
          await this.courseRepo.owners(course.id).create({teacherId: ownerId});
        }),
      );
    }
    if (coursePlans.length > 0) {
      await this.coursePlanRepo.createAll(
        coursePlans.map((plan) => {
          const coursePlan = objectToEntity(plan, CoursePlan);
          coursePlan.courseId = course.id;
          return coursePlan;
        }),
      );
    }

    course = await this.courseRepo.findById(course.id);
    return new AppResponse({data: course});
  }

  @put('/course/{cid}', spec(Course))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Course),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('cid') cid: string, @requestBody() body: UpdateCourseRequestBody) {
    if (!(await this.courseRepo.exists(cid))) {
      throw new AppResponse({code: 404});
    }
    let owners = body.ownerIds;
    let coursePlans = body.coursePlans;
    delete body.coursePlans;

    await this.courseRepo.updateById(cid, body);

    if (owners !== null && owners !== undefined) {
      await this.courseOwnerRepo.deleteAll({courseId: cid});
    } else {
      owners = [];
    }
    if (coursePlans !== null && coursePlans !== undefined) {
      await this.coursePlanRepo.deleteAll({courseId: cid});
    } else {
      coursePlans = [];
    }

    if (owners.length > 0) {
      await this.courseOwnerRepo.createAll(
        owners.map((ownerId) => {
          return {courseId: cid, teacherId: ownerId};
        }),
      );
    }
    if (coursePlans.length > 0) {
      await this.coursePlanRepo.createAll(
        coursePlans.map((plan) => {
          const coursePlan = objectToEntity(plan, CoursePlan);
          coursePlan.courseId = cid;
          return coursePlan;
        }),
      );
    }
    const course = await this.courseRepo.findById(cid);
    return new AppResponse({data: course});
  }

  @del('/course/{cid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Course),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delById(@param.path.string('cid') cid: string) {
    if (!(await this.courseRepo.exists(cid))) {
      throw new AppResponse();
    }

    await this.courseOwnerRepo.deleteAll({courseId: cid});
    await this.coursePlanRepo.deleteAll({courseId: cid});
    await this.courseRepo.deleteById(cid);

    return new AppResponse();
  }
}
