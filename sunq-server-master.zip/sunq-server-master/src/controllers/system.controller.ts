import {authenticate, TokenService} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/context';
import {repository} from '@loopback/repository';
import {del, get, param, post, put, Request, requestBody, RestBindings} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppBindings, RequestBindings, TokenServiceBindings} from '../keys';
import {
  AppResponse,
  EmptyResponse,
  FeedbackRequestBody,
  SystemInfoResponse,
  UpdateFeedbackRequestBody,
} from '../model-forms';
import {Feedback, TicketPrice} from '../models';
import {CourseRepository, FeedbackRepository} from '../repositories';
import {GoogleOAuth2} from '../services/gmail.service';
import {objectToEntity, res, spec} from '../utils';

export class SystemController {
  constructor(
    @inject(RestBindings.Http.REQUEST) private req: Request,
    @inject(AppBindings.TICKET_PRICES) private ticketPrices: TicketPrice[],
    @repository(CourseRepository) private courseRepo: CourseRepository,
    @repository(FeedbackRepository) private feedbackRepo: FeedbackRepository,
  ) {}

  @get('/system/ping', spec(EmptyResponse, {auth: false}, 'Ping reponse'))
  ping(@inject(RequestBindings.IP) ip: string) {
    return new AppResponse({
      message: 'Good',
      data: {
        ip: ip,
        url: this.req.url,
        date: new Date(),
        headers: Object.assign({}, this.req.headers),
      },
    });
  }

  @get('/system/ckediter/token', spec(EmptyResponse, {auth: false}))
  async tokenCkediter(
    @param.query.string('token') token: string,
    @inject(TokenServiceBindings.TOKEN_SERVICE) tokenService: TokenService,
  ) {
    if (!token) throw new AppResponse({code: 401, message: 'Token invalid.'});
    await tokenService.verifyToken(token);
    return new AppResponse({data: {token: token}});
  }

  @get('/system/info', spec(SystemInfoResponse, {partial: 'deep', auth: false}))
  async getInfo() {
    const info = {
      timeOpen: 'Từ 8h sáng đến 21h tối',
      address: {
        name: '57 Huỳnh Thúc Kháng, Tòa nhà Sunshine Rivershine (tầng 3), đường Võ Chí Công, Quận Tây Hồ, Hà Nội',
        location: {lat: 0, lng: 0},
      },
      contact: {phone: '039 455 5457', facebookUrl: 'fb.com/SunQ', website: 'sundayq.com'},
      ticketPrices: this.ticketPrices,
      topCourses: await this.courseRepo.find({limit: 12, order: ['viewIndex ASC']}),
    };
    return new AppResponse({data: objectToEntity(info, SystemInfoResponse)});
  }

  @get('/system/googleauth/{client_secret}', spec(EmptyResponse))
  async googleauthCallback(
    @param.path.string('client_secret') clientSecret: string,
    @param.query.string('code') code: string,
  ) {
    if (!clientSecret || !code) throw new AppResponse({code: 400});
    const cedentials = GoogleOAuth2.getGoogleCedentials();
    if (cedentials?.web.client_secret !== clientSecret) throw new AppResponse({code: 403});
    const result = await GoogleOAuth2.getToken(code);
    if (!result) throw new AppResponse({code: 410});
    return new AppResponse();
  }

  @post('/system/feedback/{service}', spec(Feedback, {auth: false}))
  async postFeedback(
    @param.path.string('service', {description: 'q-visit', schema: {pattern: '(q-visit)'}})
    service: string,
    @requestBody() body: FeedbackRequestBody,
  ) {
    body.serviceId = service;
    const feedback = await this.feedbackRepo.create(body);
    return new AppResponse({data: feedback});
  }

  @get('/system/feedbacks', spec(Feedback, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Feedback),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getFeedback(
    @param.query.string('service') service?: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const where = service ? {serviceId: service} : {};
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const order = ['createAt DESC'];
    const feedbacks = await this.feedbackRepo.find({
      where: where,
      skip: skip,
      limit: limit,
      order: order,
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.feedbackRepo.count(where)).count,
      data: feedbacks,
    });
  }

  @get('/system/feedback/{fid}', spec(Feedback))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Feedback),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getFeedbackById(@param.path.string('fid') fid: string) {
    if (!(await this.feedbackRepo.exists(fid))) {
      return new AppResponse({code: 404, message: 'Feedback not found.'});
    }
    const feedback = await this.feedbackRepo.findById(fid);
    return new AppResponse({data: feedback});
  }

  @put('/system/feedback/{fid}', spec(Feedback))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Feedback),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async replyFeedback(@param.path.string('fid') fid: string, @requestBody() body: UpdateFeedbackRequestBody) {
    if (!(await this.feedbackRepo.exists(fid))) {
      return new AppResponse({code: 404, message: 'Feedback not found.'});
    }
    await this.feedbackRepo.updateById(fid, body);
    const feedback = await this.feedbackRepo.findById(fid);
    return new AppResponse({data: feedback});
  }

  @del('/system/feedback/{fid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Feedback),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delAdviceById(@param.path.string('fid') fid: string) {
    if (!(await this.feedbackRepo.exists(fid))) {
      return new AppResponse();
    }
    await this.feedbackRepo.deleteById(fid);
    return new AppResponse();
  }
}
