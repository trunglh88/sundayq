import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {get, param, post, requestBody, RestBindings} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {Request, Response} from 'express-serve-static-core';
import {Constants, Payment, TransactionStatus, TransactionType} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {TransactionPayOnlineRequestBody, TransferMoneyRequestBody, VerifyTransactionRequestBody} from '../model-forms/requests/transaction.request';
import {CreatePaymentBody} from '../model-transactions/transaction';
import {AccountRepository, ServiceMemberRepository} from '../repositories';
import {CounterRepository} from '../repositories/counter.repository';
import {OrderRepository} from '../repositories/order.repository';
import {TransactionRepository} from '../repositories/transaction.repository';
import {Message, MessageService} from '../services/message.service';
import {TransactionService} from '../services/transaction.service';
import {spec} from '../utils';
const sha256 = require('sha256');

export class TransactionController {
  constructor(
    @repository(CounterRepository) public counterRepo: CounterRepository,
    @repository(AccountRepository) public accountRepo: AccountRepository,
    @repository(OrderRepository) public orderRepo: OrderRepository,
    @repository(ServiceMemberRepository) public serviceMemberRepo: ServiceMemberRepository,
    @repository(TransactionRepository) public transactionRepo: TransactionRepository,
  ) { }

  @post('/transaction/create_payment_url/{merchandiseType}', spec(EmptyResponse))
  @authenticate('jwt')
  async sendPaymentUrl(
    // @inject(RestBindings.Http.REQUEST) req: Request,
    @requestBody() body: TransactionPayOnlineRequestBody,
    @param.path.string('merchandiseType', {description: 'kit|service', schema: {pattern: '(kit|service)'}})
    merchandiseType: string,
    @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
  ) {
    let orderInfo = '';
    let amount = 0;
    const data: any = {};
    if (!(await this.accountRepo.exists(currentUserProfile.id))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
    }
    data.senderId = currentUserProfile.id;
    if (merchandiseType === Payment.MERCHANDISE.KIT) {
      let order: any = await this.orderRepo.findById(body.merchandiseId, {include: [{relation: 'kit'}]});
      if (!order) throw new AppResponse({code: 404, message: MessageService.getMessage(Message.KID_NOT_FOUND)});
      order = JSON.parse(JSON.stringify(order));
      console.log('order : ', JSON.stringify(order));
      orderInfo = `Nap tien mua ${order.kit.title} voi gia ${this.formatVnd(order.kit.price)} VND`;
      amount = order.kit.price;
      data.amount = amount;
      data.orderInfo = orderInfo;
      data.orderId = order.id;
    } else if (merchandiseType === Payment.MERCHANDISE.SERVICE) {
      let serviceMember: any = await this.serviceMemberRepo.findById(body.merchandiseId, {
        include: [{relation: 'service'}],
      });
      if (!serviceMember) throw new AppResponse({code: 404, message: 'Service member not found'});
      serviceMember = JSON.parse(JSON.stringify(serviceMember));
      console.log('serviceMember : ', JSON.stringify(serviceMember));

      amount = serviceMember.service.price - (serviceMember.service.discount || 0);

      orderInfo = `Nap tien dang ky dich vu ${serviceMember.service.name} voi gia ${this.formatVnd(amount)} VND`;

      data.amount = amount;
      data.orderInfo = orderInfo;
      data.serviceMemberId = serviceMember.id;
    } else {
      throw new AppResponse({code: 404, message: 'Unknow'});
    }
    const ipAddr = '::1'; //req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || '';

    console.log('ipAddr : ', ipAddr);
    // var

    const txnRef = await this.counterRepo.nextCounter('transaction');

    const vnpUrl = TransactionService.createPaymentUrl(
      new CreatePaymentBody(ipAddr, txnRef, amount, orderInfo, body.locale),
    );

    // console.log('vnpUrl: ', vnpUrl);

    data.transactionType = TransactionType.PAY_ONLINE;
    data.status = TransactionStatus.CREATE;
    data.txnRef = txnRef;
    await this.transactionRepo.create(data);
    //Neu muon dung Redirect thi dong dong ben duoi
    // res.status(200).json({code: '00', data: vnpUrl});
    //Neu muon dung Redirect thi mo dong ben duoi va dong dong ben tren
    //res.redirect(vnpUrl)
    return new AppResponse({data: {code: '00', data: vnpUrl}});
  }

  @get('/transaction/vnpay_return', spec(EmptyResponse))
  async getResultVnPay(
    @inject(RestBindings.Http.REQUEST) req: Request,
    @inject(RestBindings.Http.RESPONSE) res: Response,
  ) {
    let vnp_Params = req.query;
    let returnParams = {};
    console.log('vnp_Params : ', vnp_Params);
    const transaction: any = await this.transactionRepo.findOne({
      where: {txnRef: Number(vnp_Params['vnp_TxnRef'])},
      include: [{relation: 'order'}, {relation: 'serviceMember'}],
    });

    if (TransactionService.isPaymentSuccess(req)) {
      if (transaction.order) {
        await this.orderRepo.updateById(transaction.order.id, {status: Constants.ORDER_STATUS.PAID});
      } else if (transaction.serviceMember) {
        const currentDateTime = new Date();
        const date = currentDateTime.getDate();
        const month = currentDateTime.getMonth();
        const year = currentDateTime.getFullYear();
        const hour = currentDateTime.getHours();
        const minute = currentDateTime.getMinutes();
        const second = currentDateTime.getSeconds();
        const millisecond = currentDateTime.getMilliseconds();

        const startTime = currentDateTime;

        const endTime = new Date(); // need to update in the future
        endTime.setDate(date);
        endTime.setMonth(month);
        endTime.setFullYear(year + 1);
        endTime.setHours(hour);
        endTime.setMinutes(minute);
        endTime.setSeconds(second);
        endTime.setMilliseconds(millisecond);
        await this.serviceMemberRepo.updateById(transaction.serviceMember.id, {
          startTime: startTime,
          endTime: endTime,
          status: Constants.SERVICE_STATUS.ACTIVE,
        });
        // await this.serviceMemberRepo.updateById(transaction.serviceMember.id, {
        //   status: Constants.SERVICE_STATUS.ACTIVE,
        // });
      }
      await this.transactionRepo.updateById(transaction.id, {status: TransactionStatus.DONE});
      // res.redirect('https://www.google.com/');

      let {vnp_TransactionStatus, vnp_TransactionNo, vnp_OrderInfo, vnp_BankCode, vnp_Amount} = vnp_Params;
      vnp_Amount = '' + Number(vnp_Amount) / 100;
      returnParams = {vnp_TransactionStatus, vnp_TransactionNo, vnp_OrderInfo, vnp_BankCode, vnp_Amount};
    } else {
      await this.transactionRepo.updateById(transaction.id, {status: TransactionStatus.REJECT});

      // res.redirect('https://www.facebook.com/');

      let {vnp_TransactionStatus, vnp_OrderInfo, vnp_BankCode, vnp_Amount} = vnp_Params;
      vnp_Amount = '' + Number(vnp_Amount) / 100;
      returnParams = {vnp_TransactionStatus, vnp_OrderInfo, vnp_BankCode, vnp_Amount};
    }

    var querystring = require('qs');

    res.redirect(`http://sundayq.com/q-online/payment/callback?` + querystring.stringify(returnParams, {encode: true}));
  }

  @post('/transaction/transferMoney/{merchandiseType}', spec(EmptyResponse))
  @authenticate('jwt')
  async transferMoney(
    @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    @param.path.string('merchandiseType', {description: 'kit|service', schema: {pattern: '(kit|service)'}})
    merchandiseType: string,
    @requestBody() body: TransferMoneyRequestBody,
  ) {
    if (!(await this.accountRepo.exists(currentUserProfile.id))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
    }
    const data: any = {};
    let orderInfo = '';
    let amount = 0;
    if (merchandiseType === Payment.MERCHANDISE.KIT) {
      let order: any = await this.orderRepo.findById(body.merchandiseId, {include: [{relation: 'kit'}]});
      if (!order) throw new AppResponse({code: 404, message: MessageService.getMessage(Message.KID_NOT_FOUND)});
      order = JSON.parse(JSON.stringify(order));
      console.log('order : ', JSON.stringify(order));
      orderInfo = `Nap tien mua ${order.kit.title} voi gia ${this.formatVnd(order.kit.price)} VND`;
      amount = order.kit.price;
      data.amount = amount;
      data.orderInfo = orderInfo;
      data.orderId = order.id;
    } else if (merchandiseType === Payment.MERCHANDISE.SERVICE) {
      let serviceMember: any = await this.serviceMemberRepo.findById(body.merchandiseId, {
        include: [{relation: 'service'}],
      });
      if (!serviceMember) throw new AppResponse({code: 404, message: 'Service member not found'});
      serviceMember = JSON.parse(JSON.stringify(serviceMember));
      console.log('serviceMember : ', JSON.stringify(serviceMember));
      amount = serviceMember.service.price - (serviceMember.service.discount || 0);

      orderInfo = `Nap tien dang ky dich vu ${serviceMember.service.name} voi gia ${this.formatVnd(amount)} VND`;

      data.amount = amount;
      data.orderInfo = orderInfo;
      data.serviceMemberId = serviceMember.id;
      data.senderId = currentUserProfile.id;
    } else {
      throw new AppResponse({code: 404, message: 'Unknow'});
    }
    data.transactionType = TransactionType.TRANSFER_MONEY;
    data.thumbnailUrl = body.thumbnailUrl;
    data.status = TransactionStatus.CREATE;
    await this.transactionRepo.create(data);
    return new AppResponse();
  }

  @post('/transaction/verify/transferMoney/{transactionId}', spec(EmptyResponse))
  async verifyTransferMoney(@param.path.string('transactionId') transactionId: string,
    @requestBody() body: VerifyTransactionRequestBody,) {
    if (!(await this.transactionRepo.exists(transactionId))) {
      throw new AppResponse({code: 404, message: 'Transaction not found'});
    }
    const transaction: any = await this.transactionRepo.findById(transactionId, {
      include: [{relation: 'order'}, {relation: 'serviceMember'}],
    });
    if (body.isSuccess) {

      if (transaction.order) {
        await this.orderRepo.updateById(transaction.order.id, {status: Constants.ORDER_STATUS.PAID});
      } else if (transaction.serviceMember) {
        const currentDateTime = new Date();
        const date = currentDateTime.getDate();
        const month = currentDateTime.getMonth();
        const year = currentDateTime.getFullYear();
        const hour = currentDateTime.getHours();
        const minute = currentDateTime.getMinutes();
        const second = currentDateTime.getSeconds();
        const millisecond = currentDateTime.getMilliseconds();

        const startTime = currentDateTime;

        const endTime = new Date(); // need to update in the future
        endTime.setDate(date);
        endTime.setMonth(month);
        endTime.setFullYear(year + 1);
        endTime.setHours(hour);
        endTime.setMinutes(minute);
        endTime.setSeconds(second);
        endTime.setMilliseconds(millisecond);
        await this.serviceMemberRepo.updateById(transaction.serviceMember.id, {
          startTime: startTime,
          endTime: endTime,
          status: Constants.SERVICE_STATUS.ACTIVE,
        });
        //await this.serviceMemberRepo.updateById(transaction.serviceMember.id, {status: Constants.SERVICE_STATUS.ACTIVE});
      }
      await this.transactionRepo.updateById(transaction.id, {status: TransactionStatus.DONE});
    } else {
      await this.transactionRepo.updateById(transaction.id, {status: TransactionStatus.REJECT});
    }
    return new AppResponse();
  }

  formatVnd = (number: number) => {
    return Boolean(number) ? number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') : 0;
  };
}
