import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, Request, requestBody, Response, RestBindings} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope} from '../constants';
import {AppResponse, EmptyResponse, UrlResponse, UrlsResponse, VideoResponse, VideosResponse} from '../model-forms';
import {ResourceRequest} from '../model-forms/requests/resource.request';
import {VideoRequestBody} from '../model-forms/requests/video.request';
import {Resource} from '../models';
import {ResourceRepository} from '../repositories';
import {FileService, UploadService} from '../services';
import {Message, MessageService} from '../services/message.service';
import {res, Spec, spec} from '../utils';

// import UploadService from '../services/upload.service';

import path = require('path');

const TAG = 'ResourceController';

export class ResourceController {
  constructor(@repository(ResourceRepository) private resourceRepo: ResourceRepository) { }

  @post('/resource/ckediter/image', spec(UrlsResponse, {auth: false}, 'Image urls'))
  @authenticate('jwt-query')
  async uploadCkediterImage(
    @requestBody(Spec.upload('file')) req: Request,
    @inject(RestBindings.Http.RESPONSE) res: Response,
    @param.query.string('token') token: string, // to show in explorer api
    @param.query.string('responseType') responseType: string, // to show in explorer api
  ): Promise<object> {
    const tempFiles = await UploadService.uploadFiles(req, res, 'file', Constants.FILE_TYPE.IMAGE);
    if (!tempFiles) throw new HttpErrors.UnprocessableEntity('Missing field.');
    const urls = [];
    while (tempFiles.length) {
      const file = tempFiles.pop();
      if (file) {
        FileService.moveFile(file.filepath, path.join(FileService.ROOT_DIR, Constants.FILE_TYPE.IMAGE), file.filename);
        urls.push(`resource/${Constants.FILE_TYPE.IMAGE}/${file.filename}`);
      }
    }
    return {urls: urls};
  }

  @post('/resource/{filetype}', spec(UrlsResponse, {}, 'file urls'))
  @authenticate('jwt')
  async uploadSingleFile(
    @requestBody(Spec.uploadSingleFile('file')) req: Request,
    @inject(RestBindings.Http.RESPONSE) res: Response,
    @param.path.string('filetype', {
      description: 'image|audio|document|powerpoint',
      schema: {pattern: '(image|audio|document|powerpoint)'},
    })
    filetype: Constants.FILE_TYPE,
  ): Promise<object> {
    const tempFile = await UploadService.uploadFile(req, res, 'file', filetype);
    if (!tempFile) throw new HttpErrors.UnprocessableEntity('Missing field.');

    if (tempFile) {
      FileService.moveFile(tempFile.filepath, path.join(FileService.ROOT_DIR, filetype), tempFile.filename);
      let body = {};
      const {title} = req.body;
      Object.assign(body, {fileType: filetype, title, fileName: tempFile.filename});
    }
    return {url: `resource/${filetype}/${tempFile.filename}`};
  }

  @post('/resource/{resourceId}', spec(EmptyResponse, {}))
  @authenticate('jwt')
  async editFile(
    @requestBody() body: ResourceRequest,
    @param.path.string('resourceId') resourceId: string,
  ): Promise<object> {
    this.resourceRepo.updateById(resourceId, body);
    return new AppResponse();
  }

  @get('/resource/{filetype}/{filename}', Spec.description('Return file', false))
  async getFile(
    @param.path.string('filename') filename: string,
    @inject(RestBindings.Http.RESPONSE) response: Response,
    @param.path.string('filetype', {
      description: 'image|audio|document|powerpoint',
      schema: {pattern: '(image|audio|document|powerpoint)'},
    })
    filetype: Constants.FILE_TYPE,
  ) {
    const file = FileService.isExists(path.join(FileService.ROOT_DIR, filetype), filename);
    if (!file) throw new HttpErrors.NotFound('Resource not exits.');
    response.sendFile(file);
    return response;
  }

  @get('/resource/download/{filetype}/{filename}', Spec.description('Return file'))
  @authenticate('jwt')
  async getImages(
    @param.path.string('filename') filename: string,
    @inject(RestBindings.Http.RESPONSE) response: Response,
    @param.path.string('filetype', {
      description: 'image|audio|document|powerpoint',
      schema: {pattern: '(image|audio|document|powerpoint)'},
    })
    filetype: Constants.FILE_TYPE,
  ) {
    const file = FileService.isExists(path.join(FileService.ROOT_DIR, filetype), filename);
    if (!file) throw new HttpErrors.NotFound('Resource not exits.');
    response.download(file);
    return response;
  }

  //=========================================Video=====================================
  @post('/resource/video', spec(Resource, {}, 'Video'))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Resource),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async uploadVideo(@requestBody() body: VideoRequestBody): Promise<object> {
    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrl) {
      let strs = data.thumbnailUrl.split('/');
      let size = strs.length;
      data.thumbnail = strs[size - 1];
    }
    data.fileType = Constants.FILE_TYPE.VIDEO;

    const video = await this.resourceRepo.create(data);
    return new AppResponse({data: {video}});
  }

  @put('/resource/video/upload/{videoid}', spec(UrlResponse, {}, 'Video url'))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Resource),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async putVideo(
    @requestBody(Spec.uploadVideo()) req: Request,
    @param.path.string('videoid') videoid: string,
    @inject(RestBindings.Http.RESPONSE) res: Response,
  ): Promise<object> {
    req.setTimeout(15 * 60 * 1000);
    let url: string = '';

    console.log('videoid', videoid);

    this.resourceRepo.updateById(videoid, {status: Constants.UPLOAD_STATUS.UPLOADING});
    const resource = await this.resourceRepo.findById(videoid, {
      fields: {thumbnail: true, thumbnailUrl: true, fileName: true},
    });
    let thumbnail: string = resource.thumbnail || '';
    let thumbnailUrl: string = resource.thumbnailUrl || '';
    let fileName: string = resource.fileName || '';
    let oldFolder = '//';
    let oldThumbnail = '';
    if (thumbnail) {
      oldThumbnail = thumbnail;
      oldFolder = thumbnail.split('.')[0];
    }
    console.log('thumbnailUrl : ', thumbnailUrl);
    const videoFile = await UploadService.uploadFile(req, res, 'video', Constants.FILE_TYPE.VIDEO);
    if (!videoFile) throw new HttpErrors.UnprocessableEntity('Missing field.');

    if (videoFile) {
      console.log('filePath : ' + JSON.stringify(videoFile));
      await FileService.processVideo(videoFile.filepath, FileService.VIDEO_DIR, videoFile.filename);
      url = `resource/video/${videoFile.filename}`;
      this.resourceRepo.updateById(videoid, {fileName: videoFile.filename, fileUrl: url});
      const imageFileIgnoreTag = videoFile.filename.split('.')[0];
      const thumbnailVideoFileName = `${imageFileIgnoreTag}.png`;
      if (
        thumbnail &&
        fileName &&
        thumbnail.split('.')[0] !== fileName.split('.')[0] &&
        FileService.isExists(FileService.IMAGE_DIR, thumbnail)
      ) {
        //remove thumbnai
        FileService.removeFile(path.join(FileService.IMAGE_DIR, thumbnailVideoFileName));
      } else {
        thumbnail = thumbnailVideoFileName;
        thumbnailUrl = `/resource/image/${thumbnailVideoFileName}`;
      }
      this.resourceRepo.updateById(videoid, {thumbnail, thumbnailUrl, status: Constants.UPLOAD_STATUS.COMPLETE});
      if (oldThumbnail && oldThumbnail.split('.')[0] === fileName.split('.')[0]) {
        //delete thumbnail
        FileService.removeFile(path.join(FileService.IMAGE_DIR, oldThumbnail));
        //delete video
        FileService.removeFolder(path.join(FileService.VIDEO_DIR, oldFolder));
      }
    }

    return new AppResponse({data: {url}});
  }

  @get('/resource/videos', spec(VideosResponse, {}, 'Video list'))
  @authenticate('jwt')
  async getVideos(
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ): Promise<object> {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const videos = await this.resourceRepo.find({
      where: {fileType: Constants.FILE_TYPE.VIDEO},
      skip: skip,
      limit: limit,
    });

    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.resourceRepo.count({fileType: Constants.FILE_TYPE.VIDEO})).count,
      data: videos,
    });
  }

  @get('/resource/video/info/{videoId}', spec(VideoResponse, {}, 'Video'))
  @authenticate('jwt')
  async getVideo(@param.path.string('videoId') videoId: string): Promise<object> {
    const video = await this.resourceRepo.findOne({where: {id: videoId, fileType: Constants.FILE_TYPE.VIDEO}});

    return new AppResponse({data: {video: video}});
  }

  @put('/resource/video/{videoid}', spec(VideoResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Resource),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editInfoVideo(@param.path.string('videoid') videoid: string, @requestBody() body: VideoRequestBody) {
    if (!(await this.resourceRepo.exists(videoid))) {
      return new AppResponse({code: 404, message: 'Video not found.'});
    }
    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrl) {
      let strs = data.thumbnailUrl.split('/');
      let size = strs.length;
      data.thumbnail = strs[size - 1];
    }
    await this.resourceRepo.updateById(videoid, data);
    const video = await this.resourceRepo.findById(videoid);
    return new AppResponse({data: {video}});
  }

  @del('/resource/removevideo/{videoId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Resource),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async removeVideo(@param.path.string('videoId') videoId: string): Promise<object> {
    const video = await this.resourceRepo.findById(videoId);
    if (!video) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.RESOURCE_NOT_FOUND)});
    }
    if (video.fileName) {
      const fileName = video.fileName.split('.')[0];
      if (FileService.isExists(FileService.VIDEO_DIR, fileName)) {
        await FileService.removeFolder(path.join(FileService.VIDEO_DIR, fileName));
      }
    }
    await this.resourceRepo.deleteById(videoId);

    return new AppResponse();
  }

  //file MP4
  @get('/resource/video/{videoFile}')
  // @authenticate('jwt')
  async viewVideo(
    @param.path.string('videoFile') videoFile: string,
    @inject(RestBindings.Http.RESPONSE) response: Response,
    @param.query.number('quality') quality: {Q360: 360; Q480: 480; Q720: 720},
  ) {
    //check tag
    let [videoFileIgnoreTag, videoFileTag] = videoFile.split('.');
    let dirPath: string = '';
    let video: string = '';
    if (UploadService.checkType(`.${videoFileTag}`, Constants.FILE_TYPE.VIDEO)) {
      const q = quality || 720;
      dirPath = path.join(FileService.VIDEO_DIR, `${videoFileIgnoreTag}/${videoFileIgnoreTag}_${q}`);
      video = `${videoFileIgnoreTag}_${q}.m3u8`;
    } else {
      const q = videoFile.split('_')[1].substring(0, 3);
      videoFileIgnoreTag = videoFile.split('_')[0];
      dirPath = path.join(FileService.VIDEO_DIR, `${videoFileIgnoreTag}/${videoFileIgnoreTag}_${q}`);
      video = videoFile;
    }
    console.log('dirPath', dirPath);
    console.log('video', video);

    const file = FileService.isExists(dirPath, video);
    if (!file) throw new HttpErrors.NotFound('Resource not exits.');
    response.sendFile(file);
    return response;
  }
}
