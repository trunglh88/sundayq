import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {QuestionRequestBody} from '../model-forms/requests/question.request';
import {QuestionsResponse} from '../model-forms/responses/question.response';
import {RoleGroup} from '../models';
import {Question} from '../models/question.model';
import {AgeRepository} from '../repositories/age.repository';
import {ClassRepository} from '../repositories/class.repository';
import {QuestionRepository} from '../repositories/question.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';
import {STEAM_CATEGORIES} from './../constants';

export class QuestionController {
  constructor(@repository(QuestionRepository) private questionRepo: QuestionRepository,
    @repository(ClassRepository) private classRepo: ClassRepository,
    @repository(AgeRepository) private ageRepo: AgeRepository,
  ) { }

  @post('/question', spec(Question, {}, 'Question'))
  async createQuestion(@requestBody() body: QuestionRequestBody,
    @param.query.string("classId") classId?: string,
    @param.query.string("category") category?: STEAM_CATEGORIES,
    @param.query.string("ageId") ageId?: string): Promise<object> {
    console.log("question : ", requestBody)
    body = JSON.parse(JSON.stringify(body));
    if (classId && await this.classRepo.exists(classId)) {
      Object.assign(body, {classId});
    }
    if (category) {
      Object.assign(body, {category});
    }
    if (ageId && await this.ageRepo.exists(ageId)) {
      Object.assign(body, {ageId});
    }
    const question = await this.questionRepo.create(body);
    return new AppResponse({data: question});
  }

  @del('/question/{questionId}')
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async deleteQuestion(@param.path.string("questionId") questionId: string): Promise<object> {
    await this.questionRepo.deleteById(questionId);
    return new AppResponse();
  }

  @get('/questions', spec(QuestionsResponse, {}, 'Question list'))
  async getQuestions(
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
    @param.query.string("classId") classId?: string,
    @param.query.string("category") category?: STEAM_CATEGORIES,
    @param.query.string("ageId") ageId?: string
  ): Promise<object> {
    let where = {};
    if (classId && await this.classRepo.exists(classId)) {
      Object.assign(where, {classId});
    }
    if (category) {
      Object.assign(where, {category});
    }
    if (ageId && await this.ageRepo.exists(ageId)) {
      Object.assign(where, {ageId});
    }
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    limit = limit === undefined ? 9999999999 : limit;
    const questions = await this.questionRepo.find({
      where,
      skip: skip,
      limit: limit,
    });
    const total = (await this.questionRepo.count(where)).count;
    return new AppResponse({data: questions, total: total, page: page !== undefined ? page : 0});
  }

  @get('/question/{questionId}', spec(Question, {}, 'Question'))
  async getQuestion(@param.path.string('questionId') questionId: string): Promise<object> {
    const question = await this.questionRepo.findById(questionId);
    return new AppResponse({data: question});
  }

  @put('/question/{questionId}', spec(EmptyResponse, {}, 'EmptyResponse'))
  async editQuestion(
    @param.path.string('questionId') questionId: string,
    @requestBody() body: QuestionRequestBody,
  ): Promise<object> {
    const question = await this.questionRepo.findById(questionId);
    if (!question) {
      return new AppResponse({code: 404, message: MessageService.getMessage(Message.QUESTION_NOT_FOUND)});
    }
    await this.questionRepo.updateById(questionId, body);
    return new AppResponse();
  }
}

