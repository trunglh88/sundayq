import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, CheckRoleRequestBody, EmptyResponse, ResourseResponse, RoleGroupRequestBody} from '../model-forms';
import {RoleGroup} from '../models';
import {AccountRepository, RoleGroupRepository} from '../repositories';
import {res, spec} from '../utils';

export class RoleGroupController {
  constructor(
    @repository(RoleGroupRepository) private roleGroupRepo: RoleGroupRepository,
    @repository(AccountRepository) private accountRepo: AccountRepository,
  ) {}

  @get('/rolegroups', spec(RoleGroup, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getRoleGroups(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.roleGroupRepo.count()).count,
      data: await this.roleGroupRepo.find({skip: skip, limit: limit}),
    });
  }

  @get('/rolegroup/{rgid}', spec(RoleGroup, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getRoleGroupById(@param.path.string('rgid') rgid: string) {
    if (!(await this.roleGroupRepo.exists(rgid))) {
      throw new AppResponse({code: 404});
    }
    return new AppResponse({data: await this.roleGroupRepo.findById(rgid)});
  }

  @post('/rolegroup/checkrole', spec(EmptyResponse))
  @authenticate('jwt')
  async checkrole(@inject(SecurityBindings.USER) user: UserProfile, @requestBody() body: CheckRoleRequestBody) {
    const roleGroup = await this.accountRepo.roleGroup(user.id);
    if (!roleGroup) throw new AppResponse({code: 406});
    if (roleGroup.name === 'root') return new AppResponse();
    if (!roleGroup.roles) throw new AppResponse({code: 406});
    const resourceRoles = roleGroup.roles.filter((role) => {
      return role.resource === body.resource;
    });
    if (resourceRoles.length === 0) throw new AppResponse({code: 406});
    const scopes: Scope[] = [];
    resourceRoles.forEach((role) => {
      scopes.push(...role.scopes);
    });
    if (!scopes.includes(body.scope as Scope)) throw new AppResponse({code: 406});
    return new AppResponse();
  }

  @post('/rolegroup', spec(RoleGroup))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(@requestBody() body: RoleGroupRequestBody) {
    try {
      const roleGroup = await this.roleGroupRepo.create(body);
      return new AppResponse({data: roleGroup});
    } catch (error) {
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }

  @put('/rolegroup/{rgid}', spec(RoleGroup))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('rgid') rgid: string, @requestBody() body: RoleGroupRequestBody) {
    const roleGroup = await this.roleGroupRepo.findById(rgid);
    if (!roleGroup) throw new AppResponse({code: 404, message: 'Role group not found.'});
    if (roleGroup.name === 'root') throw new AppResponse({code: 400, message: 'Role root can not modify.'});

    try {
      await this.roleGroupRepo.updateById(rgid, body);
      return new AppResponse({data: await this.roleGroupRepo.findById(rgid)});
    } catch (error) {
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }

  @del('/rolegroup/{rgid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delById(@param.path.string('rgid') rgid: string) {
    if (!(await this.roleGroupRepo.exists(rgid))) {
      throw new AppResponse();
    }
    await this.roleGroupRepo.deleteById(rgid);
    return new AppResponse();
  }

  @get('/rolegroup/resources', spec(ResourseResponse, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(RoleGroup),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getResources() {
    return new AppResponse({data: res.getValues()});
  }
}
