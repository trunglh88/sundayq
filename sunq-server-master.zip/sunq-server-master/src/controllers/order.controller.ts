import {repository} from '@loopback/repository';
import {get, param, post, put, requestBody} from '@loopback/rest';
import {Constants} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {OrderRequestBody} from '../model-forms/requests/order.request';
import {OrderResponse} from '../model-forms/responses/order.response';
import {KitRepository} from '../repositories';
import {OrderRepository} from '../repositories/order.repository';
import {spec} from '../utils';

export class OrderController {
  constructor(
    @repository(OrderRepository) private orderRepo: OrderRepository,
    @repository(KitRepository) private kitRepo: KitRepository,
  ) { }

  @post('/order/{kidId}', spec(EmptyResponse))
  async createOrder(@requestBody() body: OrderRequestBody, @param.path.string('kidId') kidId: string): Promise<object> {
    const data = JSON.parse(JSON.stringify(body));
    data.status = Constants.ORDER_STATUS.PENDING;
    const order = await this.kitRepo.orders(kidId).create(data);
    return new AppResponse({data: {order}});
  }

  @get('/order/{orderId}', spec(OrderResponse))
  async getOrder(@param.path.string('orderId') orderId: string): Promise<object> {
    const order = await this.orderRepo.findById(orderId, {include: [{relation: 'kit'}, {relation: 'transactions'}]});
    return new AppResponse({data: {order}});
  }

  @get('/orders')
  async getOrders(
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ): Promise<object> {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;

    const pendingOrders =
      (await this.orderRepo.find({
        where: {status: Constants.ORDER_STATUS.PENDING},
        order: ['updateAt DESC'],
      })) || [];

    const paidOrders =
      (await this.orderRepo.find({
        where: {status: Constants.ORDER_STATUS.PAID},
        order: ['updateAt DESC'],
      })) || [];

    const completeOrders =
      (await this.orderRepo.find({
        where: {status: Constants.ORDER_STATUS.COMPLETE},
        order: ['updateAt DESC'],
      })) || [];
    const orders = [...pendingOrders, ...paidOrders, ...completeOrders];
    // const order = await this.orderRepo.findById(orderId, {include: [{relation: 'kit'}]});
    console.log("orders : ", orders);
    return new AppResponse(
      new AppResponse({
        page: page !== undefined ? page : 0,
        total: orders.length,
        data: orders.splice(skip, limit !== undefined ? skip + limit : undefined),
      }),
    );
  }

  @put('/order/complete/{orderId}', spec(EmptyResponse))
  async completeOrder(@param.path.string('orderId') orderId: string): Promise<object> {
    if (!(await this.orderRepo.exists(orderId))) {
      throw new AppResponse({code: 404, message: 'Order not found'});
    }
    await this.orderRepo.updateById(orderId, {status: Constants.ORDER_STATUS.COMPLETE});
    return new AppResponse();
  }

  @get('/orders/status/{status}')
  async getOrderByStatus(
    @param.path.string('status', {description: 'pending|paid|complete', schema: {pattern: '(pending|paid|complete)'}})
    status: Constants.ORDER_STATUS,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ): Promise<object> {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;

    const orders = await this.orderRepo.find({
      where: {status: status},
      order: ['updateAt DESC'],
      skip: skip,
      limit: limit,
    });
    // const orders = await this.orderRepo.find();
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.orderRepo.count({status: status})).count,
      data: orders,
    });
  }
}
