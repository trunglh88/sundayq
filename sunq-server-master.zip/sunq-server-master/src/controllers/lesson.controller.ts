import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {AnyObject, repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {SecurityBindings, securityId, UserProfile} from '@loopback/security';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope, STEAM_CATEGORIES} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {LessonRequestBody, UpdateLessonRequestBody} from '../model-forms/requests/lesson.request';
import {AgesResponse} from '../model-forms/responses/age.response';
import {LessonsResponse} from '../model-forms/responses/lesson.response';
import {Lesson} from '../models/lesson.model';
import {KitRepository, ResourceRepository} from '../repositories';
import {AgeRepository} from '../repositories/age.repository';
import {ClassMemberRepository} from '../repositories/class-member.repository';
import {ClassRepository} from '../repositories/class.repository';
import {LessonMemberRepository} from '../repositories/lesson-member.repository';
import {LessonQuestionRepository} from '../repositories/lesson-question.repository';
import {LessonResourceRepository} from '../repositories/lesson-resource.repository';
import {LessonRepository} from '../repositories/lesson.repository';
import {QuestionRepository} from '../repositories/question.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

export class LessonController {
  constructor(
    @repository(AgeRepository) public ageRepo: AgeRepository,
    @repository(ClassRepository) public classRepo: ClassRepository,
    @repository(LessonRepository) public lessonRepo: LessonRepository,
    @repository(LessonMemberRepository) public lessonMemberRepo: LessonMemberRepository,
    @repository(KitRepository) public kitRepo: KitRepository,
    @repository(ClassMemberRepository) public classMemberRepo: ClassMemberRepository,
    @repository(ResourceRepository) public resourceRepo: ResourceRepository,
    @repository(QuestionRepository) public questionRepo: QuestionRepository,
    @repository(LessonResourceRepository) public lessonResourceRepo: LessonResourceRepository,
    @repository(LessonQuestionRepository) public lessonQuestionRepo: LessonQuestionRepository,
  ) { }

  @post('/lesson/{parentName}/{parentId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Lesson),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createLesson(
    @requestBody() body: LessonRequestBody,
    @param.path.string('parentName', {description: 'age|class', schema: {pattern: '(age|class)'}}) parentName: string,
    @param.path.string('parentId') parentId: string,
  ) {
    try {
      if (body.kitId && !this.kitRepo.exists(body.kitId)) {
        throw new AppResponse({code: 404, message: MessageService.getMessage(Message.KID_NOT_FOUND)});
      }
      const resources = body.resources;
      const questionIds = body.questionIds;
      const bodyObject = JSON.parse(JSON.stringify(body));
      delete bodyObject.resources;
      delete bodyObject.questionIds;
      let lesson: any = {};
      if (parentName === 'age') {
        if (!this.ageRepo.exists(parentId)) {
          throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
        }
        lesson = await this.ageRepo.lessons(parentId).create(bodyObject);
      } else {
        if (!this.classRepo.exists(parentId)) {
          throw new AppResponse({code: 404, message: MessageService.getMessage(Message.CLASS_NOT_FOUND)});
        }
        lesson = await this.classRepo.lessons(parentId).create(bodyObject);
      }

      if (resources) {
        Promise.all(resources.map((resourceId) => this.lessonResourceRepo.create({resourceId, lessonId: lesson.id})));
      }

      if (questionIds) {
        Promise.all(questionIds.map((questionId) => this.lessonQuestionRepo.create({questionId, lessonId: lesson.id})));
      }
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict(MessageService.getMessage(Message.NAME_IS_TAKEN));
      }
      throw error;
    }
  }

  @del('/lesson/{lessonId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Lesson),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delLessonById(@param.path.string('lessonId') lessonId: string) {
    if (!(await this.lessonRepo.exists(lessonId))) {
      return new AppResponse();
    }
    await this.lessonRepo.deleteById(lessonId);
    return new AppResponse();
  }

  @get('/lesson/sample/age/{ageType}/{month}', spec(LessonsResponse))
  @authenticate('jwt')
  async getSampleLessonByAge(@param.path.number('ageType') ageType: number, @param.path.number('month') month: number) {
    const age = await this.ageRepo.findOne({where: {type: ageType}});
    if (!age) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    let lessons: any[] = await this.ageRepo.lessons(age.id).find({
      where: {isSampleLesson: true, month: month},
      include: [
        {
          relation: 'lessonResources',
          scope: {
            include: [{relation: 'resource'}],
          },
        },
        {
          relation: 'lessonQuestions',
          scope: {
            include: [{relation: 'question'}],
          },
        },
        {relation: 'kit'},
      ],
    });

    if (lessons) {
      lessons = JSON.parse(JSON.stringify(lessons));
      lessons = lessons.map((lesson) => {
        let lessonResources = lesson.lessonResources || [];
        let lessonQuestions = lesson.lessonQuestions || [];

        lessonResources = lessonResources.map((lessonResource: {resource: any}) => lessonResource.resource);
        lessonQuestions = lessonQuestions.map((lessonQuestion: {question: any}) => lessonQuestion.question);

        delete lesson.lessonResources;
        delete lesson.lessonQuestions;

        Object.assign(lesson, {resources: lessonResources});
        Object.assign(lesson, {questions: lessonQuestions});

        return lesson;
      });

      //   lesson. = lessonResources;
      //   console.log(JSON.stringify(lesson));
    }
    return new AppResponse({data: {lessons: lessons}});
  }

  @get('/lesson/{lessonId}', spec(EmptyResponse))
  @authenticate('jwt')
  async getLesson(
    @inject(SecurityBindings.USER)
    currentUserProfile: UserProfile,
    @param.path.string('lessonId') lessonId: string,
  ) {
    let lesson: any = await this.lessonRepo.findById(lessonId, {
      include: [
        {
          relation: 'lessonResources',
          scope: {
            include: [{relation: 'resource'}],
          },
        },
        {
          relation: 'lessonMembers',
          scope: {
            where: {memberId: currentUserProfile[securityId]}
          }
        },
        {
          relation: 'lessonQuestions',
          scope: {
            include: [{relation: 'question'}],
          },
        },
        {relation: 'kit'},
      ],
    });

    if (lesson) {
      lesson = JSON.parse(JSON.stringify(lesson));
      let lessonResources = JSON.parse(JSON.stringify(lesson.lessonResources));
      let lessonQuestions = JSON.parse(JSON.stringify(lesson.lessonQuestions));
      lessonResources = lessonResources.map((lessonResource: {resource: any}) => lessonResource.resource);
      lessonQuestions = lessonQuestions.map((lessonQuestion: {question: any}) => lessonQuestion.question);

      console.log('lessonResources : ', lessonResources);

      delete lesson.lessonResources;
      delete lesson.lessonQuestions;

      Object.assign(lesson, {resources: lessonResources});
      Object.assign(lesson, {questions: lessonQuestions});
      //   lesson. = lessonResources;
      //   console.log(JSON.stringify(lesson));

      if (currentUserProfile.uType === Constants.ACCOUNT_TYPE.MEMBER) {
        if (lesson.classId) {
          const classMember = await this.classMemberRepo.findOne({
            where: {classId: lesson.classId, memberId: currentUserProfile[securityId]}
          });
          console.log("classMember : ", classMember);
          if (classMember) {
            // if (lesson.month != classMember.studyMonth || new Date() < classMember.startOfMonth) {
            //   lesson.status = Constants.LESSON_STATUS.CLOSE;
            // } else {
            //   if (lesson.lessonMembers && lesson.lessonMembers.length > 0) {
            //     lesson.status = Constants.LESSON_STATUS.COMPLETE;
            //   } else {
            //     lesson.status = Constants.LESSON_STATUS.OPEN;
            //   }
            // }
            console.log("classMember : ", classMember)

            if (lesson.lessonMembers && lesson.lessonMembers.length > 0) {
              throw new AppResponse({
                code: 400,
                message: `Học viên không thế xem lại các bài học đã hoàn thành.`,
              });
            } else if (new Date() < classMember.startOfMonth[lesson.category]) {
              throw new AppResponse({code: 400, message: `Khóa học của bạn chưa bắt đầu`});
            } else if (lesson.month != classMember.studyMonth[lesson.category]) {
              throw new AppResponse({
                code: 400,
                message: `Bài học chưa được mở. Vui lòng hoàn thành tất cả bài học trong tháng ${classMember.studyMonth[lesson.category]}.`,
              });
            }


          }
        }
      }
    } else {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.LESSON_NOT_FOUND)});
    }

    return new AppResponse({data: {lesson: lesson}});
  }

  @get('/lessons/{parentName}/{parentId}', spec(AgesResponse))
  @authenticate('jwt')
  // @authorize({
  //   allowedRoles: ['member'],
  //   resource: res(Lesson),
  //   scopes: [Scope.DELETE],
  //   voters: [basicAuthor, roleAuthor],
  // })
  async getLessons(
    @inject(SecurityBindings.USER)
    currentUserProfile: UserProfile,
    @param.path.string('parentName', {description: 'age|kit|class', schema: {pattern: '(age|kid|class)'}})
    parentName: string,
    @param.path.string('parentId') parentId: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
    @param.query.number('month') month?: number,
    @param.query.string('category', {
      description: 'science|technology|engineering|art|math',
      schema: {pattern: '(science|technology|engineering|art|math)'},
    })
    category?: STEAM_CATEGORIES,
  ) {
    console.log('currentUserProfile : ', currentUserProfile);
    //   currentUserProfile :  { name: '',
    // id: '7e2d9ac9c4190eb007f3233070be5d181606207374629',
    // uType: 'admin',
    // [Symbol(securityId)]: '7e2d9ac9c4190eb007f3233070be5d181606207374629' }

    const skip = limit !== undefined && page !== undefined ? page * limit : 0;

    limit = limit === undefined ? 9999999999 : limit;

    let lessons: Lesson[];
    let total = 0;
    if (parentName === 'age') {
      lessons = await this.ageRepo.lessons(parentId).find({
        skip: skip,
        limit: limit,
        order: ['month DESC'],
      });
      total = (await this.lessonRepo.count({ageId: parentId})).count;
    } else if (parentName === 'kit') {
      lessons = await this.kitRepo.lessons(parentId).find({
        skip: skip,
        limit: limit,
        order: ['month DESC'],
      });
      total = (await this.lessonRepo.count({kitId: parentId})).count;
    } else {
      if (currentUserProfile.uType === Constants.ACCOUNT_TYPE.MEMBER) {
        //check in here
        if (parentName === 'class') {
          //STEAMQ
          const classMember = await this.classMemberRepo.findOne({
            where: {
              memberId: currentUserProfile[securityId],
              classId: parentId,
            },
          });
          const currentTimeMiliseconds = new Date().getTime();
          if (classMember) {
            //STEAMQ

          }
          if (!classMember || classMember.endTime.getTime() < currentTimeMiliseconds) {
            //need to register class
            throw new AppResponse({code: 404, message: MessageService.getMessage(Message.NEED_TO_REGISTER_ACCOUNT)});
            return;
          }
          if (classMember?.startTime.getTime() > currentTimeMiliseconds) {
            // registered class, but the start time of class is not begin.
            throw new AppResponse({code: 404, message: MessageService.getMessage(Message.CLASS_HAS_NOT_YET_STARTED)});
            return;
          }

          const currentTime = new Date();
          // if (month != classMember.studyMonth || currentTime < classMember.startOfMonth) {
          //   //the month is close
          //   throw new AppResponse({
          //     code: 404,
          //     message: MessageService.getMessage(Message.THE_LESSON_OF_MONTH_HAS_BEEN_CLOSED),
          //   });
          //   return;
          // }
          console.log('aaaaaaaaaa');
          console.log('parentId : ', parentId);
          console.log('skip : ', skip);
          console.log('limit : ', limit);
          let where = month ? {month: month, category: category} : {category: category};
          lessons = await this.classRepo.lessons(parentId).find({
            where: where,
            include: [
              {
                relation: 'lessonMembers',
                scope: {
                  where: {
                    memberId: currentUserProfile[securityId],
                  },
                },
              },
            ],
            skip: skip,
            limit: limit,
          });
          lessons = JSON.parse(JSON.stringify(lessons));
          lessons.map((lesson: any) => {
            // lesson = JSON.parse(JSON.stringify(lesson));
            // if (month != classMember.studyMonth[lesson.category] || currentTime < classMember.startOfMonth[lesson.category]) {
            //   lesson.status = Constants.LESSON_STATUS.CLOSE;
            // } else {
            if (lesson.lessonMembers && lesson.lessonMembers.length > 0) {
              lesson.status = Constants.LESSON_STATUS.COMPLETE;
            } else if (month != classMember.studyMonth[lesson.category]) {
              lesson.status = Constants.LESSON_STATUS.CLOSE;
            } else {
              lesson.status = Constants.LESSON_STATUS.OPEN;
            }


            delete lesson.lessonMembers;
            return lesson;
          });
          total = (await this.lessonRepo.count(Object.assign({classId: parentId}, where))).count;
        } else {
          let where = {month: month};
          lessons = await this.ageRepo.lessons(parentId).find({
            where: where,
            include: [
              {
                relation: 'lessonMembers',
                scope: {
                  where: {
                    memberId: currentUserProfile[securityId],
                  },
                },
              },
            ],
            skip: skip,
            limit: limit,
          });
          lessons = JSON.parse(JSON.stringify(lessons));
          // lessons.map((lesson: any) => {
          //   // lesson = JSON.parse(JSON.stringify(lesson));
          //   if (month != classMember.studyMonth[lesson.category] || currentTime < classMember.startOfMonth[lesson.category]) {
          //     lesson.status = Constants.LESSON_STATUS.CLOSE;
          //   } else {
          //     if (lesson.lessonMembers && lesson.lessonMembers.length > 0) {
          //       lesson.status = Constants.LESSON_STATUS.COMPLETE;
          //     } else {
          //       lesson.status = Constants.LESSON_STATUS.OPEN;
          //     }
          //   }

          // delete lesson.lessonMembers;
          // return lesson;

          total = (await this.lessonRepo.count(Object.assign({ageId: parentId}, where))).count;
        }


      } else {
        let where = month ? {month: month, category: category} : {category: category};
        lessons = await this.classRepo.lessons(parentId).find({
          where: where,
          skip: skip,
          limit: limit,
        });
        total = (await this.lessonRepo.count(Object.assign({classId: parentId}, where))).count;
      }
    }
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: total,
      data: lessons,
    });
  }

  @put('/lesson/{lessonId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Lesson),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editLesson(@param.path.string('lessonId') lessonId: string, @requestBody() body: UpdateLessonRequestBody) {
    try {
      const lesson = await this.lessonRepo.findById(lessonId);
      if (!lesson) {
        throw new AppResponse({code: 404, message: MessageService.getMessage(Message.LESSON_NOT_FOUND)});
      }
      const oldResources =
        (await this.lessonRepo.lessonResources(lessonId).find({fields: {resourceId: true}})).map(
          (lessonResource) => lessonResource.resourceId,
        ) || [];

      const oldQuestionIds =
        (await this.lessonRepo.lessonQuestions(lessonId).find({fields: {questionId: true}})).map(
          (lessonResource) => lessonResource.questionId,
        ) || [];

      const resources = body.resources || [];
      const questionIds = body.questionIds || [];
      // const bodyObject = JSON.parse(JSON.stringify(body));
      delete (body as AnyObject).resources;
      delete (body as AnyObject).questionIds;
      await this.lessonRepo.updateById(lesson.id, body);
      await Promise.all(
        resources
          .filter((resourceId) => oldResources.indexOf(resourceId) < 0)
          .map((resourceId) => this.lessonResourceRepo.create({resourceId, lessonId})),
      );
      await Promise.all(
        oldResources
          .filter((resourceId) => resources.indexOf(resourceId) < 0)
          .map((resourceId) => this.lessonResourceRepo.deleteAll({resourceId, lessonId})),
      );

      await Promise.all(
        questionIds
          .filter((questionId) => oldQuestionIds.indexOf(questionId) < 0)
          .map((questionId) => this.lessonQuestionRepo.create({questionId, lessonId})),
      );
      await Promise.all(
        oldQuestionIds
          .filter((questionId) => questionIds.indexOf(questionId) < 0)
          .map((questionId) => this.lessonQuestionRepo.deleteAll({questionId, lessonId})),
      );

      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }

  @put('/lesson/complete/{lessonId}', spec(EmptyResponse))
  @authenticate('jwt')
  async completeLesson(
    @inject(SecurityBindings.USER)
    currentUserProfile: UserProfile,
    @param.path.string('lessonId') lessonId: string,
  ) {
    try {
      const lesson = await this.lessonRepo.findById(lessonId);
      if (!lesson) {
        throw new AppResponse({code: 404, message: MessageService.getMessage(Message.LESSON_NOT_FOUND)});
      }

      if (
        (await this.lessonMemberRepo.count({memberId: currentUserProfile[securityId], lessonId: lesson.id})).count >= 1
      ) {
        return new AppResponse();
      }
      const lessonMember = await this.lessonMemberRepo.create({
        memberId: currentUserProfile[securityId],
        lessonId: lesson.id,
      });

      console.log('lesson : ', JSON.stringify(lesson));
      const lessonsInMonth = await this.lessonRepo.find({where: {classId: lesson.classId, month: lesson.month, category: lesson.category}});
      const lessonIdsInMonth = lessonsInMonth.map((lesson) => {
        return lesson.id;
      });
      console.log('lessonIdsInMonth : ', lessonIdsInMonth.length);
      console.log(
        'lessonIdsInMonth : ',
        JSON.stringify(
          await this.lessonMemberRepo.count({
            memberId: currentUserProfile[securityId],
            lessonId: {inq: lessonIdsInMonth},
          }),
        ),
      );
      if (
        (
          await this.lessonMemberRepo.count({
            memberId: currentUserProfile[securityId],
            lessonId: {inq: lessonIdsInMonth},
          })
        ).count >= lessonIdsInMonth.length
      ) {
        const classMember = await this.classMemberRepo.findOne({
          where: {classId: lesson.classId, memberId: currentUserProfile[securityId]},
        });
        if (classMember) {
          if (classMember?.studyMonth[lesson.category] >= 12) {
            let studyMonth = classMember.studyMonth;
            studyMonth[lesson.category] = 1;
            let startOfMonth = classMember.startOfMonth;
            startOfMonth[lesson.category].setMonth(startOfMonth[lesson.category].getMonth() + 1)
            await this.classMemberRepo.updateById(classMember.id, {
              studyMonth,
              startOfMonth
            });
          } else {
            let studyMonth = classMember.studyMonth;
            studyMonth[lesson.category] = studyMonth[lesson.category] + 1;
            let startOfMonth = classMember.startOfMonth;
            startOfMonth[lesson.category].setMonth(startOfMonth[lesson.category].getMonth() + 1)
            await this.classMemberRepo.updateById(classMember.id, {
              studyMonth,
              startOfMonth,
            });
          }
        }
      }
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }
}
