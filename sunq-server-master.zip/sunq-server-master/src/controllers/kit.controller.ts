import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {KitRequestBody} from '../model-forms/requests/kit.request';
import {KitsResponse} from '../model-forms/responses/kid.response';
import {Kit} from '../models';
import {KitRepository} from '../repositories';
import {FileService} from '../services';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

import path = require('path');

export class KitController {
  constructor(@repository(KitRepository) private kitRepo: KitRepository) { }

  @post('/kit')
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Kit),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createKit(@requestBody() body: KitRequestBody): Promise<object> {
    let thumbnails: string[] = [];
    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrls) {
      data.thumbnailUrls.forEach((thumbnailUrl: string) => {
        let strs: string[] = thumbnailUrl.split('/');
        let size = strs.length;
        thumbnails.push(strs[size - 1]);
      });
      data.thumbnails = thumbnails;
    }

    const kit = await this.kitRepo.create(data);
    return new AppResponse({data: {kit}});
  }

  @put('/kit/{kidId}')
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Kit),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async updateKit(@param.path.string('kidId') kidId: string, @requestBody() body: KitRequestBody): Promise<object> {
    const kit = await this.kitRepo.findById(kidId);
    if (!kit) {
      return new AppResponse({code: 404, message: MessageService.getMessage(Message.KID_NOT_FOUND)});
    }
    let oldThumbnails = kit.thumbnails || '';
    let thumbnails: string[] = [];
    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrls) {
      data.thumbnailUrls.forEach((thumbnailUrl: string) => {
        const strs: string[] = thumbnailUrl.split('/');
        const length = strs.length;

        thumbnails.push(strs[length - 1] || thumbnailUrl);
      });
      data.thumbnails = thumbnails;
    }
    await this.kitRepo.updateById(kidId, body);
    if (thumbnails.length > 0 && oldThumbnails.length > 0) {
      //delete old images
      while (oldThumbnails.length > 0) {
        const file = oldThumbnails.pop();
        if (file) {
          FileService.removeFile(path.join(FileService.IMAGE_DIR, file));
        }
      }
    }
    return new AppResponse();
  }

  @get('/kits', spec(KitsResponse, {}, 'Kit list'))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Kit),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getKits(
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ): Promise<object> {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    limit = limit === undefined ? 9999999999 : limit;
    const kits = await this.kitRepo.find({
      skip: skip,
      limit: limit,
    });
    const total = (await this.kitRepo.count()).count;
    return new AppResponse({data: kits, total: total, page: page !== undefined ? page : 0});
  }

  @get('/kits/fake', spec(KitsResponse, {}, 'Kit list'))
  async getKitFakes(
  ): Promise<object> {
    const kits = await this.kitRepo.find({});
    return new AppResponse({data: kits});
  }

  @get('/kit/{kidId}')
  @authenticate('jwt')
  async getKit(@param.path.string('kidId') kidId: string): Promise<object> {
    const kit = await this.kitRepo.findById(kidId);
    return new AppResponse({data: kit});
  }

  @del('/kit/{kidId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Kit),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async removeKid(@param.path.string('kidId') kidId: string): Promise<object> {
    const kit = await this.kitRepo.findById(kidId);
    if (!kit) {
      return new AppResponse({code: 404, message: MessageService.getMessage(Message.KID_NOT_FOUND)});
    }
    await this.kitRepo.deleteById(kidId);
    while (kit.thumbnails.length > 0) {
      const file = kit.thumbnails.pop();
      if (file) {
        FileService.removeFile(path.join(FileService.IMAGE_DIR, file));
      }
    }
    return new AppResponse();
  }
}
