import {authenticate, TokenService} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {repository, Where} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, OtpConfig, Scope} from '../constants';
import {
  AccountServiceBindings,
  PasswordHasherBindings,
  RefreshtokenServiceBindings,
  TokenServiceBindings
} from '../keys';
import {Gmail} from '../mail/gmail';
import {ResetPassword, VerifyAccount} from '../mail/model-mail';
import {BaseProfileResponse, EmptyResponse, RefeshTokenResponse, RefreshTokenRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {
  AccountChangePasswordRequestBody,
  AccountGetAdviceRequestBody,
  AccountRequestBody,
  AccountStateRequestBody,
  CheckOtpRequestBody,
  EditAccountRequestBody,
  ResetPasswordRequestBody,
  UpdateAccountGetAdviceRequestBody,
  UpdatePasswordWithOtpRequestBody,
  VerifyTokenMemberRequestBody
} from '../model-forms/requests/account.request';
import {CredentialsRequestBody} from '../model-forms/requests/credentials.request';
import {Account, AccountGetAdvice} from '../models';
import {AccountGetAdviceRepository, AccountRepository} from '../repositories';
import {OtpRepository} from '../repositories/otp.repository';
import {AccountService} from '../services';
import {Message, MessageService} from '../services/message.service';
import {RefreshtokenService} from '../services/refreshtoken.service';
import {VATocken} from '../services/verifyaccounttoken.service';
import {objectToEntity, PasswordHasher, res, spec, Spec} from '../utils';

export class AccountController {
  constructor(
    @repository(AccountRepository) public accountRepo: AccountRepository,
    @inject(AccountServiceBindings.ACCOUNT_SERVICE) public accountService: AccountService,
    @inject(PasswordHasherBindings.PASSWORD_HASHER) public passwordHasher: PasswordHasher,
    @inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: TokenService,
    @inject(RefreshtokenServiceBindings.REFRESHTOKEN_SERVICE) public refreshtokenService: RefreshtokenService,
    @repository(AccountGetAdviceRepository) public accountGetAdviceRepo: AccountGetAdviceRepository,
    @repository(OtpRepository) public otpRepository: OtpRepository,
  ) { }

  @get('/account/token/check', Spec.description('Empty response'))
  @authenticate('jwt')
  async checkToken() {
    return new AppResponse({message: 'Good'});
  }

  @post('/account/token/refresh', spec(RefeshTokenResponse, {}, 'Refreshing the token'))
  @authenticate('jwt')
  async refresh(
    @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    @requestBody() body: RefreshTokenRequestBody,
  ) {
    await this.refreshtokenService.verifyToken(body.refreshtoken, currentUserProfile);

    const token = await this.jwtService.generateToken(currentUserProfile);

    return {token};
  }

  @post('/account/{target}/login')
  async login(
    @requestBody() body: CredentialsRequestBody,
    @param.path.string('target', {description: 'member|teacher|admin', schema: {pattern: '(member|teacher|admin)'}})
    accountType: Constants.ACCOUNT_TYPE,
  ) {
    let account: any = await this.accountService.verifyCredentials(body);
    if (account.accountType !== accountType) {
      throw new AppResponse({code: 401, message: MessageService.getMessage(Message.ACCOUNT_OR_PASSWORD_NOT_FOUND)});
    }

    const userProfile = this.accountService.convertToUserProfile(account);

    const token = await this.jwtService.generateToken(userProfile);

    account = await this.accountRepo.getAccount(account.id, accountType);
    delete (account as any).password;

    const refreshToken = await this.refreshtokenService.generateToken(userProfile);

    return new AppResponse({data: Object.assign({token, refreshToken}, account)});
  }

  @post('/account/member/register', spec(BaseProfileResponse, {auth: false}))
  async register(@requestBody() body: AccountRequestBody) {
    if (await this.accountRepo.findOne({where: {phone: body.phone}})) {
      throw new AppResponse({code: 409, message: 'Phone is already taken.'});
    }
    const user = await this.accountRepo.createAccount(body, Constants.ACCOUNT_TYPE.MEMBER);

    const code = '123456';

    await this.otpRepository.create({email: body.email, code: code});
    //send email at here

    const token = VATocken.generateToken(body.email);

    Gmail.verifyAccount(
      new VerifyAccount({receiverEmail: user.email, receiverName: user.name || user.email, token: token}),
    );

    //end send

    return new AppResponse({data: Object.assign({token: token}, objectToEntity(user, BaseProfileResponse))});
  }

  @post('/account/member/verify', spec(EmptyResponse, {auth: false}))
  async verifyMember(@requestBody() body: VerifyTokenMemberRequestBody) {
    if (!VATocken.verifyToken(body.token)) {
      throw new AppResponse({code: 404, message: 'Token not found'});
    }
    const email = VATocken.getEmail(body.token);
    const account = await this.accountRepo.findOne({where: {email: email}});
    if (!account) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
    }
    await this.accountRepo.updateById(account.id, {state: Constants.ACCOUNT_STATE.ACTIVE});
    return new AppResponse();
  }

  @del('/account/advice/{advid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AccountGetAdvice),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delAdviceById(@param.path.string('advid') advid: string) {
    if (!(await this.accountGetAdviceRepo.exists(advid))) {
      return new AppResponse();
    }
    await this.accountGetAdviceRepo.deleteById(advid);
    return new AppResponse();
  }

  @put('/account/advice/{advid}', spec(AccountGetAdvice))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AccountGetAdvice),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async tickAdvice(@param.path.string('advid') advid: string, @requestBody() body: UpdateAccountGetAdviceRequestBody) {
    if (!(await this.accountGetAdviceRepo.exists(advid))) {
      return new AppResponse({code: 404, message: 'AccountGetAdvice not found.'});
    }
    await this.accountGetAdviceRepo.updateById(advid, body);
    const accountGetAdvice = this.accountGetAdviceRepo.findById(advid);
    return new AppResponse({data: accountGetAdvice});
  }

  @get('/account/advices', spec(AccountGetAdvice, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AccountGetAdvice),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAdvices(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    limit = limit === undefined ? 9999999999 : limit;
    const include = [{relation: 'course'}];
    const order = ['createAt DESC'];
    const accountGetAdvices = await this.accountGetAdviceRepo.find({
      skip: skip,
      limit: limit,
      order: order,
      include: include,
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.accountGetAdviceRepo.count()).count,
      data: accountGetAdvices,
    });
  }

  @get('/account/advices/{cid}', spec(AccountGetAdvice, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AccountGetAdvice),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAdviceByCid(
    @param.path.string('cid') cid: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const accountGetAdvices = await this.accountGetAdviceRepo.find({where: {courseId: cid}, skip: skip, limit: limit});
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.accountGetAdviceRepo.count({courseId: cid})).count,
      data: accountGetAdvices,
    });
  }

  @post('/account/advice/register/{cid}', spec(AccountGetAdvice, {auth: false}))
  async registerAdvice(@param.path.string('cid') cid: string, @requestBody() body: AccountGetAdviceRequestBody) {
    body.courseId = cid;
    const accountGetAdvice = await this.accountGetAdviceRepo.create(body);
    return new AppResponse({data: accountGetAdvice});
  }

  @put('/account/{aid}/password', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({allowedRoles: ['owner'], voters: [basicAuthor]})
  async changePassword(@param.path.string('aid') aid: string, @requestBody() body: AccountChangePasswordRequestBody) {
    const account = await this.accountRepo.findById(aid);
    if (!account) throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});

    const passwordMatched = await this.passwordHasher.comparePassword(body.oldPassword, account.password);
    if (!passwordMatched) throw new AppResponse({code: 404, message: 'Password incorrect.'});

    await this.accountRepo.updateById(aid, {password: await this.passwordHasher.hashPassword(body.newPassword)});
    return new AppResponse();
  }

  @post('/account/password/reset', spec(EmptyResponse))
  async resetPassword(@requestBody() body: ResetPasswordRequestBody) {
    const account: any = await this.accountRepo.findOne({where: {email: body.email}});
    if (!account) throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});

    //generate code

    // const code = '123456';
    // await this.otpRepository.create({email: body.email, code: code});

    //auto generate password here
    const password = new Date().getTime() % 10000000;
    await this.accountRepo.updateById(account.id, {
      password: await this.passwordHasher.hashPassword(password.toString()),
    });

    //send code to client by email

    Gmail.resetPassword(
      new ResetPassword({
        receiverEmail: account.email,
        receiverName: account.name || account.email,
        password: password.toString(),
      }),
    );

    //end send
    return new AppResponse();
  }

  @post('/account/checkotp', spec(EmptyResponse))
  async checkOtp(@requestBody() body: CheckOtpRequestBody) {
    const otps = await this.otpRepository.find({where: {email: body.email, code: body.code}});
    const currentTimeMilisecond = new Date().getMilliseconds();
    if (otps.length <= 0) {
      return new AppResponse({code: 404, message: 'Code not found.'});
    }
    await otps.forEach(async (otp) => {
      if (currentTimeMilisecond - new Date(otp.createAt).getMilliseconds() <= OtpConfig.EFFECTIVE_PERIOD_CHECK_OTP) {
        const account = await this.accountRepo.findOne({where: {email: body.email}});
        if (account && account.state === Constants.ACCOUNT_STATE.PENDING) {
          await this.accountRepo.updateById(account.id, {state: Constants.ACCOUNT_STATE.ACTIVE});
        }
        return new AppResponse();
      }
    });
    return new AppResponse({code: 404, message: 'Code expired.'});
  }

  @put('/account/password/updatewithotp', spec(EmptyResponse))
  async updatePasswordWithOtp(@requestBody() body: UpdatePasswordWithOtpRequestBody) {
    const otps = await this.otpRepository.find({where: {email: body.email, code: body.code}});
    const currentTimeMilisecond = new Date().getMilliseconds();
    if (otps.length <= 0) {
      return new AppResponse({code: 404, message: 'Code not found.'});
    }
    otps.forEach(async (otp) => {
      if (
        currentTimeMilisecond - new Date(otp.createAt).getMilliseconds() <=
        OtpConfig.EFFECTIVE_PERIOD_RESSET_PASSWORD_OTP
      ) {
        const account: Account | null = await this.accountRepo.findOne({where: {email: body.email}});
        if (!account) {
          return new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
        }
        this.accountRepo.updateById(account.id, {
          password: await this.passwordHasher.hashPassword(body.password || body.email),
        });
        await this.otpRepository.deleteById(otp.id);
        return new AppResponse();
      }
    });
    return new AppResponse({code: 404, message: 'Code expired.'});
  }

  @get('/accounts', spec(Account, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAccounts(
    @param.query.string('email') email: string,
    @param.query.string('accountType', {
      description: 'member|teacher|admin',
      schema: {pattern: '(member|teacher|admin)'},
    })
    accountType: Constants.ACCOUNT_TYPE,
    @param.query.string('rgid') rgid: string,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const where: Where<Account> = {};
    if (email) where.email = email;
    if (accountType) where.accountType = accountType;
    if (rgid) where.roleGroupId = rgid;
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.accountRepo.count(where)).count,
      data: await this.accountRepo.find({where: where, skip: skip, limit: limit}),
    });
  }

  @get('/account', spec(Account))
  @authenticate('jwt')
  async getAccount(@inject(SecurityBindings.USER) currentUserProfile: UserProfile) {
    const account = await this.accountRepo.findById(currentUserProfile.id);
    return new AppResponse({
      data: account,
    });
  }

  @put('/account/{aid}/state', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async editState(@param.path.string('aid') aid: string, @requestBody() body: AccountStateRequestBody) {
    if (!(await this.accountRepo.exists(aid))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
    }
    await this.accountRepo.updateById(aid, body);
    return new AppResponse();
  }

  @put('/account/{aid}', spec(EmptyResponse))
  @authenticate('jwt')
  // @authorize({
  //   allowedRoles: ['admin', 'owner'],
  //   resource: res(Account),
  //   scopes: [Scope.EDIT],
  //   voters: [basicAuthor, roleAuthor],
  // })
  async editAccount(@param.path.string('aid') aid: string, @requestBody() body: EditAccountRequestBody) {
    if (!(await this.accountRepo.exists(aid))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});
    }
    await this.accountRepo.editById(aid, Constants.ACCOUNT_TYPE.MEMBER, body);
    return new AppResponse();
  }

  // @put('/account/{aid}/password', spec(EmptyResponse))
  // @authenticate('jwt')
  // @authorize({allowedRoles: ['owner'], voters: [basicAuthor]})
  // async changePassword(@param.path.string('aid') aid: string, @requestBody() body: AccountChangePasswordRequestBody) {
  //   const account = await this.accountRepo.findById(aid);
  //   if (!account) throw new AppResponse({code: 404, message: MessageService.getMessage(Message.ACCOUNT_NOT_FOUND)});

  //   const passwordMatched = await this.passwordHasher.comparePassword(body.oldPassword, account.password);
  //   if (!passwordMatched) throw new AppResponse({code: 404, message: 'Password incorrect.'});

  //   await this.accountRepo.updateById(aid, {password: await this.passwordHasher.hashPassword(body.newPassword)});
  //   return new AppResponse();
  // }

  @get('/admin/members/info', spec(Account, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getMemberInfos() {
    const members = await this.accountRepo.find({
      where: {state: Constants.ACCOUNT_STATE.ACTIVE, accountType: Constants.ACCOUNT_TYPE.MEMBER},
      fields: {id: true, email: true},
    });
    return new AppResponse({data: members});
  }

  @get('/member/admins/info', spec(Account, {array: true}))
  @authenticate('jwt')
  async getAdminInfos() {
    const admins = await this.accountRepo.find({
      where: {state: Constants.ACCOUNT_STATE.ACTIVE, accountType: Constants.ACCOUNT_TYPE.ADMIN},
      fields: {id: true, email: true},
    });
    return new AppResponse({data: admins});
  }
}
