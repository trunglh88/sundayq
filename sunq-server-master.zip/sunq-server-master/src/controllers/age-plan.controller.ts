import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {serviceAuthor} from '../authentications/service.authorizor';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {AgePlanRequestBody} from '../model-forms/requests/age-plan.request';
import {AgePlanResponse, AgePlansResponse} from '../model-forms/responses/age-plan.response';
import {AgePlan} from '../models/age-plan.model';
import {AgePlanRepository} from '../repositories/age-plan.repository';
import {AgeRepository} from '../repositories/age.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';
import path = require('path');
import {CounterRepository} from '../repositories/counter.repository';

export class AgePlanController {
  constructor(
    @repository(AgePlanRepository) public agePlanRepo: AgePlanRepository,
    @repository(AgeRepository) public ageRepo: AgeRepository,
    @repository(CounterRepository) public counterRepo: CounterRepository,
  ) { }

  @post('/age-plan/month/{ageId}/{month}', spec(AgePlanResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AgePlan),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createAgePlan(
    @requestBody() body: AgePlanRequestBody,
    @param.path.string('ageId') ageId: string,
    @param.path.number('month') month: number,
  ) {
    if (!(await this.ageRepo.exists(ageId))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    if ((await this.ageRepo.agePlans(ageId).find({where: {month: month}})).length > 0) {
      //throw new AppResponse({code: 404, MessageService.getMessage(Message.AGE_NOT_FOUND)});
      throw new AppResponse({code: 409, message: 'The Age plan of this month has been created'});
    }

    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrl) {
      let strs = data.thumbnailUrl.split('/');
      let size = strs.length;
      data.thumbnail = strs[size - 1];
    }
    data.month = month;
    const agePlan = await this.ageRepo.agePlans(ageId).create(data);
    return new AppResponse({data: {agePlan}});
  }

  @get('/age-plan/month/{ageType}/{month}', spec(AgePlanResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['member', 'admin'],
    resource: res(AgePlan),
    scopes: [Scope.READ],
    voters: [basicAuthor, serviceAuthor],
  })
  async getAgePlanByMonth(@param.path.string('ageType') ageType: number, @param.path.number('month') month: number) {
    const age = await this.ageRepo.findOne({where: {type: ageType}});
    if (!age) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    const agePlan = (await this.ageRepo.agePlans(age.id).find({where: {month: month}}))[0];
    return new AppResponse({data: {agePlan}});
  }

  @get('/age-plan/{ageType}', spec(AgePlansResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['member', 'admin'],
    resource: res(AgePlan),
    scopes: [Scope.READ],
    voters: [basicAuthor, serviceAuthor],
  })
  async getAgePlan(@param.path.string('ageType') ageType: number) {
    const age = await this.ageRepo.findOne({where: {type: ageType}});
    if (!age) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    const agePlans = await this.ageRepo.agePlans(age.id).find({order: ['month ASC']});
    return new AppResponse({data: {agePlans}});
  }

  @put('/age-plan/{agePlanId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AgePlan),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editAgePlan(@requestBody() body: AgePlanRequestBody, @param.path.string('agePlanId') agePlanId: string) {
    if (!(await this.agePlanRepo.exists(agePlanId))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }

    let data = JSON.parse(JSON.stringify(body));
    if (data.thumbnailUrl) {
      let strs = data.thumbnailUrl.split('/');
      let size = strs.length;
      data.thumbnail = strs[size - 1];
    }
    const agePlan = await this.agePlanRepo.updateById(agePlanId, data);
    return new AppResponse();
  }

  @del('/age-plan/{agePlanId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(AgePlan),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delAgePlanById(@param.path.string('agePlanId') agePlanId: string) {
    if (!(await this.agePlanRepo.exists(agePlanId))) {
      return new AppResponse();
    }
    await this.agePlanRepo.deleteById(agePlanId);
    return new AppResponse();
  }
}
