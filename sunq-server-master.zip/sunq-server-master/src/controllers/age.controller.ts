import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {AgeRequestBody} from '../model-forms/requests/age.request';
import {AgesResponse} from '../model-forms/responses/age.response';
import {Age} from '../models/age.model';
import {AgeRepository} from '../repositories/age.repository';
import {CounterRepository} from '../repositories/counter.repository';
import {ServiceRepository} from '../repositories/service.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

export class AgeController {
  constructor(
    @repository(AgeRepository) public ageRepo: AgeRepository,
    @repository(ServiceRepository) public serviceRepo: ServiceRepository,
    @repository(CounterRepository) public counterRepo: CounterRepository,
  ) {}

  @post('/age/{serviceId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Age),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createAge(@requestBody() body: AgeRequestBody, @param.path.string('serviceId') serviceId: string) {
    try {
      if (!this.serviceRepo.exists(serviceId)) {
        throw new AppResponse({code: 404, message: 'Service not found.'});
      }
      const type = await this.counterRepo.nextCounter('age');
      let data = JSON.parse(JSON.stringify(body));
      data.type = type;
      await this.serviceRepo.ages(serviceId).create(data);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }

  @get('/ages/{serviceId}', spec(AgesResponse))
  @authenticate('jwt')
  async getAges(@param.path.string('serviceId') serviceId: string) {
    const ages = await this.serviceRepo.ages(serviceId).find();
    return new AppResponse({data: {ages: ages}});
  }

  @put('/age/{ageid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Age),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editAge(@param.path.string('ageid') ageid: string, @requestBody() body: AgeRequestBody) {
    if (!(await this.ageRepo.exists(ageid))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    try {
      await this.ageRepo.updateById(ageid, body);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }
}
