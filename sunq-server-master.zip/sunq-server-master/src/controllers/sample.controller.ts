import {get} from '@loopback/openapi-v3';
import {repository} from '@loopback/repository';
import {getJsonSchema} from '@loopback/repository-json-schema';
import {STEAM_CATEGORIES} from '../constants';
import {Event} from '../models';
import {KitRepository, MemberRepository, ResourceRepository} from '../repositories';
import {AgeRepository} from '../repositories/age.repository';
import {ClassMemberRepository} from '../repositories/class-member.repository';
import {ClassRepository} from '../repositories/class.repository';
import {LessonMemberRepository} from '../repositories/lesson-member.repository';
import {LessonQuestionRepository} from '../repositories/lesson-question.repository';
import {LessonResourceRepository} from '../repositories/lesson-resource.repository';
import {LessonRepository} from '../repositories/lesson.repository';
import {QuestionRepository} from '../repositories/question.repository';

export class SampleController {
  constructor(
    @repository(LessonMemberRepository) private lessonMemberRepo: LessonMemberRepository,
    @repository(LessonRepository) private lessonRepo: LessonRepository,
    @repository(MemberRepository) private memberRepo: MemberRepository,
    @repository(ClassRepository) private classRepo: ClassRepository,
    @repository(AgeRepository) private ageRepo: AgeRepository,
    @repository(KitRepository) private kitRepo: KitRepository,
    @repository(ResourceRepository) private resourceRepo: ResourceRepository,
    @repository(QuestionRepository) private questionRepo: QuestionRepository,
    @repository(LessonResourceRepository) private lessonResourceRepo: LessonResourceRepository,
    @repository(LessonQuestionRepository) private lessonQuestionRepo: LessonQuestionRepository,
    @repository(ClassMemberRepository) private classMemberRepo: ClassMemberRepository,
  ) { }

  @get('resetData')
  async resetData() {
    // console.log("data : ", getJsonSchema(Account))
    // console.log("data : ", getJsonSchema(BaseUser))
    // console.log("data : ", getJsonSchema(AccountGetAdvice))
    // console.log("data : ", getJsonSchema(Admin))
    // console.log("data : ", getJsonSchema(AgePlan))
    // console.log("data : ", getJsonSchema(Age))
    // console.log("data : ", getJsonSchema(ClassMember))
    // console.log("data : ", getJsonSchema(Class))
    // console.log("data : ", getJsonSchema(Club))
    // console.log("data : ", getJsonSchema(CoursePlan))
    // console.log("data : ", getJsonSchema(Course))
    console.log('data : ', getJsonSchema(Event));
    // console.log("data : ", getJsonSchema(Exhibition))
    // console.log("data : ", getJsonSchema(Feedback))
    // console.log("data : ", getJsonSchema(Kit))
    // console.log("data : ", getJsonSchema(LessonMember))
    // console.log("data : ", getJsonSchema(LessonQuestion))
    // console.log("data : ", getJsonSchema(LessonResource))
    // console.log("data : ", getJsonSchema(Lesson))
    // console.log("data : ", getJsonSchema(Member))
    // console.log("data : ", getJsonSchema(Order))
    // console.log("data : ", getJsonSchema(Question))
    // console.log("data : ", getJsonSchema(Resource))
    // console.log("data : ", getJsonSchema(ServiceMember))
    // console.log("data : ", getJsonSchema(ServiceResource))
    // console.log("data : ", getJsonSchema(Service))
    // console.log("data : ", getJsonSchema(Teacher))
    // console.log("data : ", getJsonSchema(TicketPrice))
    // console.log("data : ", getJsonSchema(Ticket))
    // console.log("data : ", getJsonSchema(Transaction))

    this.lessonMemberRepo.deleteAll();
    const member = await this.memberRepo.findOne({where: {email: 'test@sunq.com'}});
    const class1 = await this.classRepo.findOne({where: {type: 1}});


    const currentTime = new Date();

    let startTimeOfMonth = new Date(currentTime);
    startTimeOfMonth.setDate(1)
    let startOfMonth: any = {};
    let studyMonth: any = {};
    Object.values(STEAM_CATEGORIES).forEach(category => {
      startOfMonth[category] = startTimeOfMonth;
      studyMonth[category] = startOfMonth[category].getMonth() + 1
    });

    const classMember = Object.assign(
      JSON.parse(JSON.stringify(await this.classMemberRepo.findOne({where: {memberId: member?.id, classId: class1?.id}}))),
      {startOfMonth, studyMonth}
    );

    this.classMemberRepo.updateById(classMember.id, classMember);
    this.lessonMemberRepo.deleteAll();
    return 'success';
  }

  @get('fakeData')
  async fakeData() {
    //create Kit
    const dataKit = {
      title: 'Bộ KIT ABC',
      description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut labore et dolore magna aliqua.`,
      shortDescription: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut labore et dolore magna aliqua.`,
      thumbnailUrls: ["resource/image/d57169a28d768ad0c9f6afe483cf3256-1617020352621.jpeg",
        "resource/image/a69b7737483f03d313cbd9706eb5be13-1617020403914.jpeg",
        "resource/image/6fda2c2ac4ad4c96c890aec8a1e629b0-1617020435247.jpeg",
        "resource/image/57b516a25d2f85b24b45b1e9b91794a0-1617020533019.jpeg"],
      thumbnails: ["d57169a28d768ad0c9f6afe483cf3256-1617020352621.jpeg",
        "a69b7737483f03d313cbd9706eb5be13-1617020403914.jpeg",
        "6fda2c2ac4ad4c96c890aec8a1e629b0-1617020435247.jpeg",
        "57b516a25d2f85b24b45b1e9b91794a0-1617020533019.jpeg"],
      price: 245000,
    };
    let kit = await this.kitRepo.create(dataKit);

    const dataQus1: any = {
      content: 'Vật bị ném chuyển động như thế nào?',
      a: 'Theo phương thẳng đứng.',
      b: 'Theo phương ngang.',
      c: 'Theo toàn bộ hoặc một phần của Parapol.',
      d: 'Theo đồ thị hình Sin.',
      answer: 'c',
      interpretation: 'Vật bị ném chuyển động theo toàn bộ hoặc một phần của Parapol.',
    };
    const qus1 = await this.questionRepo.create(dataQus1);

    const dataQus2: any = {
      content: 'Albert Einstein sinh năm bao nhiêu?',
      a: '1642.',
      b: '1856.',
      c: '1879.',
      d: '1962.',
      answer: 'c',
      interpretation: 'Albert Einstein sinh năm 1879.',
    };
    const qus2 = await this.questionRepo.create(dataQus2);

    let arrClass = await this.classRepo.find();
    arrClass.forEach(async (class1) => {
      for (let i = 1; i < 13; i++) {
        let categories: string[] = ['science', 'technology', 'engineering', 'art', 'math'];
        categories.forEach(async (category: string) => {
          let numberLessons = Math.floor(Math.random() * 3) + 2;
          for (let j = 1; j < numberLessons; j++) {
            let resources: any[] = (await this.resourceRepo.find()).map(resource => resource.id);
            let questionIds = [qus1.id, qus2.id];
            let data = {
              title:
                `Chuyển động cơ học của vật bị ném - ${category} - lớp ${class1.type}` +
                (j == -1 ? ' sample.' : ` bài ${j}`),
              month: i,
              description: `
<p><b>1. Khái niệm:</b></p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
<p></p>
<p><b>2.Lý thuyết cơ bản.</b></p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
<p></p>
<p><b>3.Hướng dẫn thí nghiệm.</b></p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
`,
              thumbnailUrl: 'resource/image/98afb6760e8415d097b85a747cc263ca-1617019861533.png',
              shortDescription:
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
              kitId: kit.id,
              isSampleLesson: j == 0 ? true : false,
              category: category,
            };
            let lesson = await this.classRepo.lessons(class1.id).create(JSON.parse(JSON.stringify(data)));
            if (resources) {
              Promise.all(
                resources.map((resourceId) => this.lessonResourceRepo.create({resourceId, lessonId: lesson.id})),
              );
            }

            if (questionIds) {
              Promise.all(
                questionIds.map((questionId) => this.lessonQuestionRepo.create({questionId, lessonId: lesson.id})),
              );
            }
          }
        });
      }
    });

    let arrAge = await this.ageRepo.find();
    arrAge.forEach(async (age) => {
      for (let i = 1; i < 13; i++) {
        let numberLessons = Math.floor(Math.random() * 3) + 2;
        for (let j = 0; j <= numberLessons; j++) {
          let resources: any[] = (await this.resourceRepo.find()).map(resource => resource.id);
          let questionIds = [qus1.id, qus2.id];
          let data = {
            title: `Chuyển động cơ học của vật bị ném - ${age.description}` + (j == 0 ? ' sample.' : ` bài ${j}`),
            month: i,
            description: `
            <p><b>1. Khái niệm:</b></p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            <p></p>
            <p><b>2.Lý thuyết cơ bản.</b></p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            <p></p>
            <p><b>3.Hướng dẫn thí nghiệm.</b></p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            `,
            thumbnailUrl: 'resource/image/98afb6760e8415d097b85a747cc263ca-1617019861533.png',
            shortDescription:
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
            kitId: kit.id,
            isSampleLesson: j == 0 ? true : false,
          };
          let lesson = await this.ageRepo.lessons(age.id).create(JSON.parse(JSON.stringify(data)));
          if (resources) {
            Promise.all(
              resources.map((resourceId) => this.lessonResourceRepo.create({resourceId, lessonId: lesson.id})),
            );
          }

          if (questionIds) {
            Promise.all(
              questionIds.map((questionId) => this.lessonQuestionRepo.create({questionId, lessonId: lesson.id})),
            );
          }
        }
      }
    });

    return 'success';
  }
}
