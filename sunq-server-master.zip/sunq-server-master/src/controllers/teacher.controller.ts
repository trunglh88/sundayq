import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope} from '../constants';
import {CreateTeacherRequestBody, EmptyResponse, TeacherInfoResponse, UpdateTeacherRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {Teacher} from '../models';
import {AccountRepository, TeacherRepository} from '../repositories';
import {objectsToEntities, objectToEntity, res, spec} from '../utils';

export class TeacherController {
  constructor(
    @repository(AccountRepository) private accountRepo: AccountRepository,
    @repository(TeacherRepository) private teacherRepo: TeacherRepository,
  ) {}

  @get('/teachers', spec(Teacher, {array: true}))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Teacher),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getAll(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.teacherRepo.count()).count,
      data: await this.teacherRepo.find({skip: skip, limit: limit}),
    });
  }

  @get('/teacher/{uid}', spec(Teacher))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Teacher),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getById(@param.path.string('uid') uid: string) {
    if (!(await this.teacherRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    return new AppResponse({data: await this.teacherRepo.findById(uid)});
  }

  @get('/teacher/info/{uid}', spec(TeacherInfoResponse, {auth: false}))
  async getInfoById(@param.path.string('uid') uid: string) {
    if (!(await this.teacherRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    const teacher = await this.teacherRepo.findById(uid);
    return new AppResponse({data: objectToEntity(teacher, TeacherInfoResponse)});
  }

  @get('/teacher/infos', spec(TeacherInfoResponse, {auth: false}))
  async getAllInfo(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const teachers = await this.teacherRepo.find({skip: skip, limit: limit});
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.teacherRepo.count()).count,
      data: objectsToEntities(teachers, TeacherInfoResponse),
    });
  }

  @post('/teacher', spec(Teacher))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Teacher),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(@requestBody() body: CreateTeacherRequestBody) {
    if (!body.shortId) body.shortId = body.email;
    if (!body.email) body.email = body.shortId + '@sunq.com';
    const user = await this.accountRepo.createAccount(
      body,
      Constants.ACCOUNT_TYPE.TEACHER,
      Constants.ACCOUNT_STATE.ACTIVE,
    );
    return new AppResponse({data: user});
  }

  @put('/teacher/{uid}', spec(Teacher))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Teacher),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('uid') uid: string, @requestBody() body: UpdateTeacherRequestBody) {
    if (!(await this.teacherRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    try {
      await this.teacherRepo.updateById(uid, body);
    } catch (error) {
      if (error.code === 11000) {
        if (error.errmsg.includes('index: uniqueShortId')) throw new HttpErrors.Conflict('ShortId is already taken.');
      }
      throw error;
    }
    const teacher = await this.teacherRepo.findById(uid);
    return new AppResponse({data: teacher});
  }

  @del('/teacher/{uid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Teacher),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async delById(@param.path.string('uid') uid: string) {
    if (!(await this.teacherRepo.exists(uid))) {
      throw new AppResponse();
    }
    await this.accountRepo.deleteById(uid);
    await this.teacherRepo.deleteById(uid);
    return new AppResponse();
  }
}
