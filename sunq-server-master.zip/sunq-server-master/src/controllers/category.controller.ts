import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {CategoryRequestBody} from '../model-forms/requests/category.request';
import {AgesResponse} from '../model-forms/responses/age.response';
import {Category} from '../models/category.model';
import {AgeRepository} from '../repositories/age.repository';
import {CategoryRepository} from '../repositories/category.repository';
import {CounterRepository} from '../repositories/counter.repository';
import {ServiceRepository} from '../repositories/service.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

export class CategoryController {
  constructor(
    @repository(AgeRepository) public ageRepo: AgeRepository,
    @repository(ServiceRepository) public serviceRepo: ServiceRepository,
    @repository(CounterRepository) public counterRepo: CounterRepository,
    @repository(CategoryRepository) public categoryRepo: CategoryRepository,
  ) { }

  @post('/category/{serviceId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Category),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async createCategory(@requestBody() body: CategoryRequestBody, @param.path.string('serviceId') serviceId: string) {
    try {
      if (!this.serviceRepo.exists(serviceId)) {
        throw new AppResponse({code: 404, message: 'Service not found.'});
      }
      const type = await this.counterRepo.nextCounter('category');
      let data = JSON.parse(JSON.stringify(body));
      data.type = type;
      await this.serviceRepo.categories(serviceId).create(data);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }

  @get('/categories/{serviceId}', spec(AgesResponse))
  @authenticate('jwt')
  async getCategories(@param.path.string('serviceId') serviceId: string) {
    const categories = await this.serviceRepo.categories(serviceId).find();
    return new AppResponse({data: categories});
  }

  @put('/category/{ageid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Category),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editCategory(@param.path.string('categoryId') categoryId: string, @requestBody() body: CategoryRequestBody) {
    if (!(await this.categoryRepo.exists(categoryId))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.AGE_NOT_FOUND)});
    }
    try {
      await this.ageRepo.updateById(categoryId, body);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Name is already taken.');
      }
      throw error;
    }
  }
}
