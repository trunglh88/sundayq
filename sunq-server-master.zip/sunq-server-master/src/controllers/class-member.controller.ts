import {post, requestBody} from '@loopback/openapi-v3';
import {repository} from '@loopback/repository';
import {HttpErrors} from '@loopback/rest';
import {EmptyResponse} from '../model-forms';
import {ClassMemberRequestBody} from '../model-forms/requests/class-member.request';
import {ClassMemberRepository} from '../repositories/class-member.repository';
import {spec} from '../utils';
import {STEAM_CATEGORIES} from './../constants';
import {AppResponse} from './../model-forms/app-response.model';

export class ClassMemberController {
  constructor(
    @repository(ClassMemberRepository) public classMemberRepo: ClassMemberRepository,
  ) {
  }

  @post('/class-member/register', spec(EmptyResponse))
  async registerMember(@requestBody() body: ClassMemberRequestBody) {
    try {
      let currentTime = new Date()
      let startTime = new Date(currentTime);
      let endTime = new Date(startTime);
      endTime.setMonth(endTime.getMonth() + 12);

      let startTimeOfMonth = new Date(startTime);
      startTimeOfMonth.setDate(1)
      let startOfMonth: any = {};
      let studyMonth: any = {};
      Object.values(STEAM_CATEGORIES).forEach(category => {
        startOfMonth[category] = startTimeOfMonth;
        studyMonth[category] = startOfMonth[category].getMonth() + 1
      });
      Object.assign(body, {startTime, endTime, startOfMonth, studyMonth})
      this.classMemberRepo.create(body);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }
}
