import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/context';
import {repository} from '@loopback/repository';
import {del, get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {SecurityBindings, securityId, UserProfile} from '@loopback/security';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {ClassRequestBody} from '../model-forms/requests/class.request';
import {ClassesResponse} from '../model-forms/responses/class.response';
import {Class} from '../models/class.model';
import {ClassMemberRepository} from '../repositories/class-member.repository';
import {ClassRepository} from '../repositories/class.repository';
import {CounterRepository} from '../repositories/counter.repository';
import {LessonRepository} from '../repositories/lesson.repository';
import {ServiceRepository} from '../repositories/service.repository';
import {Message, MessageService} from '../services/message.service';
import {res, spec} from '../utils';

export class ClassController {
  constructor(
    @repository(ClassRepository) public classRepo: ClassRepository,
    @repository(ClassMemberRepository) public classMemberRepo: ClassMemberRepository,
    @repository(LessonRepository) public lessonRepo: LessonRepository,
    @repository(ServiceRepository) public serviceRepo: ServiceRepository,
    @repository(CounterRepository) public counterRepo: CounterRepository,
  ) {}

  @post('/class/{serviceCode}', spec(EmptyResponse))
  async createClass(@requestBody() body: ClassRequestBody, @param.path.number('serviceCode') serviceCode: number) {
    try {
      const service = await this.serviceRepo.findOne({where: {code: serviceCode}});
      if (!service) {
        throw new AppResponse({code: 404, message: 'Service not found.'});
      }
      const type = await this.counterRepo.nextCounter('class');
      let data = JSON.parse(JSON.stringify(body));
      data.type = type;
      console.log('data : ', data);
      await this.serviceRepo.classes(service.id).create(data);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }

  @get('/classes/{serviceId}', spec(ClassesResponse))
  @authenticate('jwt')
  async getClasses(@param.path.string('serviceId') serviceId: string) {
    const classes = await this.serviceRepo.classes(serviceId).find();
    return new AppResponse({data: {classes: classes}});
  }

  @get('/classesByServiceCode/{serviceCode}', spec(ClassesResponse))
  @authenticate('jwt')
  async getClassesByServiceCode(
    @param.path.number('serviceCode') serviceCode: number,
    @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
  ) {
    const service = await this.serviceRepo.findOne({where: {code: serviceCode}});
    if (!service) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.SERVICE_NOT_FOUND)});
    }
    let classes = await this.serviceRepo.classes(service.id).find();
    if ((currentUserProfile.uType = Constants.ACCOUNT_TYPE.MEMBER)) {
      if (classes) {
        classes = JSON.parse(JSON.stringify(classes));
        let classIds = classes.map((cls) => cls.id);
        let currentTime = new Date();
        let classMembers = await this.classMemberRepo.find({
          where: {classId: {inq: classIds}, memberId: currentUserProfile[securityId]},
        });
        classMembers = JSON.parse(JSON.stringify(classMembers));
        classMembers.filter(
          (clsMember) => new Date(clsMember.startTime) <= currentTime && new Date(clsMember.endTime) >= currentTime,
        );
        classes = classes.map((cls: any) => {
          let isPermission = false;
          if (
            classMembers.filter(
              (clsMember) => clsMember.classId == cls.id && clsMember.memberId == currentUserProfile[securityId],
            ).length > 0
          ) {
            isPermission = true;
          }
          cls.isPermission = isPermission;
          return cls;
        });
      }
    }
    return new AppResponse({data: {classes: classes}});
  }

  @put('/class/{classId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Class),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async editClass(@param.path.string('classId') classId: string, @requestBody() body: ClassRequestBody) {
    if (!(await this.classRepo.exists(classId))) {
      throw new AppResponse({code: 404, message: MessageService.getMessage(Message.CLASS_NOT_FOUND)});
    }
    try {
      await this.classRepo.updateById(classId, body);
      return new AppResponse();
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }

  @del('/class/{classId}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Class),
    scopes: [Scope.DELETE],
    voters: [basicAuthor, roleAuthor],
  })
  async deleteClass(@param.path.string('classId') classId: string) {
    const lessons = await this.classRepo.lessons(classId).find({fields: {id: true}});
    lessons.forEach((lesson) => this.lessonRepo.deleteById(lesson.id));
    await this.classRepo.deleteById(classId);
    return new AppResponse();
  }

  @get('/class/{classId}', spec(EmptyResponse))
  @authenticate('jwt')
  async getClass(@param.path.string('classId') classId: string) {
    try {
      const class1 = await this.classRepo.findById(classId);
      if (!class1) {
        return new AppResponse({code: 404, message: MessageService.getMessage(Message.CLASS_NOT_FOUND)});
      }
      return new AppResponse({data: {class: class1}});
    } catch (error) {
      console.log(error);
      if (error.code === 11000 && error.errmsg.includes('index: uniqueName')) {
        throw new HttpErrors.Conflict('Description is already taken.');
      }
      throw error;
    }
  }
}
