import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {repository} from '@loopback/repository';
import {del, get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Scope} from '../constants';
import {EmptyResponse, ExhibitionRequestBody, UpdateExhibitionRequestBody} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {Exhibition} from '../models';
import {ExhibitionRepository} from '../repositories';
import {res, spec} from '../utils';

export class ExhibitionController {
  constructor(@repository(ExhibitionRepository) private exhibitionRepo: ExhibitionRepository) {}

  @get('/exhibitions', spec(Exhibition, {array: true, auth: false}))
  async getAll(@param.query.number('page') page?: number, @param.query.number('limit') limit?: number) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const order = ['viewIndex ASC', 'createAt DESC'];
    const exhibitions = await this.exhibitionRepo.find({
      skip: skip,
      limit: limit,
      order: order,
      fields: {description: false},
    });
    return new AppResponse({
      page: page !== undefined ? page : 0,
      total: (await this.exhibitionRepo.count()).count,
      data: exhibitions,
    });
  }

  @get('/exhibition/{exhid}', spec(Exhibition, {auth: false}))
  async getByID(@param.path.string('exhid') exhid: string) {
    if (!(await this.exhibitionRepo.exists(exhid))) {
      throw new AppResponse({code: 404});
    }
    return new AppResponse({data: await this.exhibitionRepo.findById(exhid)});
  }

  @post('/exhibition', spec(Exhibition))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Exhibition),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(@requestBody() body: ExhibitionRequestBody) {
    const exhibition = await this.exhibitionRepo.create(body);
    return new AppResponse({data: exhibition});
  }

  @put('/exhibition/{exhid}', spec(Exhibition))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Exhibition),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('exhid') exhid: string, @requestBody() body: UpdateExhibitionRequestBody) {
    if (!(await this.exhibitionRepo.exists(exhid))) {
      throw new AppResponse({code: 404});
    }
    await this.exhibitionRepo.updateById(exhid, body);
    const exhibition = await this.exhibitionRepo.findById(exhid);
    return new AppResponse({data: exhibition});
  }

  @del('/exhibition/{exhid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Exhibition),
    scopes: [Scope.DELETE],
    voters: [basicAuthor],
  })
  async delById(@param.path.string('exhid') exhid: string) {
    if (!(await this.exhibitionRepo.exists(exhid))) {
      throw new AppResponse();
    }
    await this.exhibitionRepo.deleteById(exhid);
    return new AppResponse();
  }
}
