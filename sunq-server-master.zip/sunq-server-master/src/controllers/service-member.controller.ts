import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {get, HttpErrors, param, post, put, requestBody} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope} from '../constants';
import {AppResponse, EmptyResponse} from '../model-forms';
import {ServiceMemberRequestBody} from '../model-forms/requests/service-member.request';
import {Account} from '../models';
import {ServiceMemberRepository} from '../repositories';
import {res, spec} from '../utils';

export class ServiceMemberController {
  constructor(@repository(ServiceMemberRepository) public serviceMemberRepo: ServiceMemberRepository) {}

  @post('/service-member/requestService', spec(EmptyResponse))
  @authenticate('jwt')
  async requestService(
    @inject(SecurityBindings.USER)
    currentUserProfile: UserProfile,
    @requestBody() body: ServiceMemberRequestBody,
  ) {
    const memberId: string = currentUserProfile.id;
    let serviceMember = await this.serviceMemberRepo.findOne({
      where: {memberId: memberId, serviceId: body.serviceId},
    });
    const currentDateTime = new Date();
    const currentDateTimeNumber = currentDateTime.getTime();
    if (serviceMember) {
      if (
        serviceMember.status === Constants.SERVICE_STATUS.ACTIVE &&
        serviceMember.startTime.getTime() < currentDateTimeNumber &&
        serviceMember.endTime.getTime() > currentDateTimeNumber
      ) {
        throw new HttpErrors.Conflict('Service is already registered.');
      } else if (serviceMember.status === Constants.SERVICE_STATUS.PENDING) {
        return new AppResponse({data: serviceMember});
      } else {
        await this.serviceMemberRepo.updateById(serviceMember.id, {
          startTime: currentDateTime,
          endTime: currentDateTime,
          status: Constants.SERVICE_STATUS.PENDING,
        });
      }
    } else {
      let _body = JSON.parse(JSON.stringify(body));
      _body.endTime = _body.startTime = new Date();
      _body.memberId = memberId;
      _body.status = Constants.SERVICE_STATUS.PENDING;
      serviceMember = await this.serviceMemberRepo.create(_body);
    }
    return new AppResponse({data: serviceMember});
  }

  @put('/service-member/accept/{smid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async acceptRequest(@param.path.string('smid') smid: string) {
    const currentDateTime = new Date();
    const date = currentDateTime.getDate();
    const month = currentDateTime.getMonth();
    const year = currentDateTime.getFullYear();
    const hour = currentDateTime.getHours();
    const minute = currentDateTime.getMinutes();
    const second = currentDateTime.getSeconds();
    const millisecond = currentDateTime.getMilliseconds();

    const startTime = currentDateTime;

    const endTime = new Date(); // need to update in the future
    endTime.setDate(date);
    endTime.setMonth(month);
    endTime.setFullYear(year + 1);
    endTime.setHours(hour);
    endTime.setMinutes(minute);
    endTime.setSeconds(second);
    endTime.setMilliseconds(millisecond);
    await this.serviceMemberRepo.updateById(smid, {
      startTime: startTime,
      endTime: endTime,
      status: Constants.SERVICE_STATUS.ACTIVE,
    });
    return new AppResponse();
  }

  @get('/service-members', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Account),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getServiceMembers(
    @param.query.string('state', {
      description: 'pending|active|expire',
      schema: {pattern: '(pending|active|expire)'},
    })
    status: Constants.SERVICE_STATUS,
    @param.query.number('page') page?: number,
    @param.query.number('limit') limit?: number,
  ) {
    const skip = limit !== undefined && page !== undefined ? page * limit : 0;
    const include = [{relation: 'service'}, {relation: 'member', scope: {fields: {id: true, name: true}}}];
    const order = ['createAt DESC'];
    const where = {status: status};
    const serviceMembers = await this.serviceMemberRepo.find({
      where: where,
      skip: skip,
      limit: limit,
      order: order,
      include: include,
    });

    return new AppResponse({data: serviceMembers});
  }
}
