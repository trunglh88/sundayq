import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {AnyObject, repository} from '@loopback/repository';
import {get, param, post, put, requestBody} from '@loopback/rest';
import {basicAuthor, roleAuthor} from '../authentications';
import {Constants, Scope} from '../constants';
import {RoleBindings} from '../keys';
import {BaseProfileResponse, EmptyResponse} from '../model-forms';
import {AppResponse} from '../model-forms/app-response.model';
import {AccountRequestBody, UpdateBaseProfileRequestBody} from '../model-forms/requests/account.request';
import {Admin} from '../models';
import {AccountRepository, AdminRepository, RoleGroupRepository} from '../repositories';
import {objectToEntity, res, spec} from '../utils';

export class AdminController {
  constructor(
    @repository(AccountRepository) public accountRepo: AccountRepository,
    @repository(RoleGroupRepository) public roleGroupRepo: RoleGroupRepository,
    @repository(AdminRepository) public adminRepo: AdminRepository,
  ) {}

  @get('/admin/{uid}', spec(Admin))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Admin),
    scopes: [Scope.READ],
    voters: [basicAuthor, roleAuthor],
  })
  async getById(@param.path.string('uid') uid: string, @inject(RoleBindings.SCOPE) scope: Scope[]) {
    if (!(await this.adminRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    let admin: AnyObject = await this.adminRepo.findById(uid);
    if (scope.includes(Scope.EXE)) {
      const account = await this.accountRepo.findById(uid);
      admin = admin.toJSON();
      admin.roleGroupId = `${account.roleGroupId}`;
    }
    return new AppResponse({data: admin});
  }

  @post('/admin', spec(BaseProfileResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Admin),
    scopes: [Scope.CREATE],
    voters: [basicAuthor, roleAuthor],
  })
  async create(@requestBody() body: AccountRequestBody) {
    const user = await this.accountRepo.createAccount(
      body,
      Constants.ACCOUNT_TYPE.ADMIN,
      Constants.ACCOUNT_STATE.ACTIVE,
    );
    return new AppResponse({data: objectToEntity(user, BaseProfileResponse)});
  }

  @put('/admin/{uid}', spec(Admin))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Admin),
    scopes: [Scope.EDIT],
    voters: [basicAuthor, roleAuthor],
  })
  async edit(@param.path.string('uid') uid: string, @requestBody() body: UpdateBaseProfileRequestBody) {
    if (!(await this.adminRepo.exists(uid))) {
      throw new AppResponse({code: 404});
    }
    await this.adminRepo.updateById(uid, body);
    const admin = await this.adminRepo.findById(uid);
    return new AppResponse({data: admin});
  }

  @put('/admin/{adid}/rolegroup/{rgid}', spec(EmptyResponse))
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin'],
    resource: res(Admin),
    scopes: [Scope.EXE],
    voters: [basicAuthor, roleAuthor],
  })
  async setRole(@param.path.string('adid') adid: string, @param.path.string('rgid') rgid: string) {
    const admin = await this.accountRepo.findOne({where: {id: adid, accountType: Constants.ACCOUNT_TYPE.ADMIN}});
    if (!admin) throw new AppResponse({code: 404, message: 'Admin not found.'});
    if (!(await this.roleGroupRepo.exists(rgid))) throw new AppResponse({code: 404, message: 'Role group not found.'});
    await this.accountRepo.updateById(adid, {roleGroupId: rgid});
    return new AppResponse();
  }
}
