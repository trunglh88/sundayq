import {AnyObject} from '@loopback/repository';

const ip = require('ip').address();
// console.log( ip.address() );

export enum Scope {
  READ = 'read',
  CREATE = 'create',
  EDIT = 'edit',
  EXE = 'exe',
  DELETE = 'delete',
}

export enum STEAM_CATEGORIES {
  SCIENCE = 'science',
  TECHNOLOGY = 'technology',
  ENGINEERING = 'engineering',
  ART = 'art',
  MATH = 'math',
}

export namespace Constants {
  export enum ACCOUNT_TYPE {
    ADMIN = 'admin',
    MEMBER = 'member',
    TEACHER = 'teacher',
    PARENT = 'parent',
    OTHER = 'other',
  }
  export enum ACCOUNT_STATE {
    PENDING = 'pending',
    ACTIVE = 'active',
    INACTIVE = 'deactive',
  }
  export enum COURSE_TYPE {
    ONLINE = 'Đào tạo trực tuyến',
    OFFLINE = 'Đào tạo tại trường',
  }
  export enum SERVICE_STATUS {
    PENDING = 'pending',
    ACTIVE = 'active',
    EXPIRE = 'expire',
  }
  export enum FILE_TYPE {
    IMAGE = 'image',
    VIDEO = 'video',
    AUDIO = 'audio',
    DOCUMENT = 'document',
    POWERPOINT = 'powerpoint',
  }
  export enum UPLOAD_STATUS {
    CREATE = 'create',
    UPLOADING = 'uploading',
    COMPLETE = 'complete',
  }
  export enum ORDER_STATUS {
    PENDING = 'pending',
    PAID = 'paid',
    COMPLETE = 'complete',
  }
  export enum LESSON_STATUS {
    OPEN = 'open',
    CLOSE = 'close',
    COMPLETE = 'complete',
  }
}

export namespace Payment {
  export enum MERCHANDISE {
    KIT = 'kit',
    SERVICE = 'service',
  }
}

export enum OtpConfig {
  EFFECTIVE_PERIOD_CHECK_OTP = 30 * 1000,
  EFFECTIVE_PERIOD_RESSET_PASSWORD_OTP = 2 * 60 * 1000,
}

export const VnPayConfig = {
  VNP_TMNCODE: '1SNJ89L8',
  VNP_HASHSECRET: 'ODJLXOCEWMFIEJXHJNMZUVFFVRDDXLOT',
  VNP_URL: 'http://sandbox.vnpayment.vn/paymentv2/vpcpay.html',
  VNP_RETURNURL: `http://${ip}:3000/transaction/vnpay_return`,
};

export enum TransactionType {
  PAY_ONLINE = 'pay_online',
  TRANSFER_MONEY = 'transfer_money',
}

export enum TransactionStatus {
  DONE = 'done',
  CREATE = 'create',
  REJECT = 'reject',
}

export enum Answer {
  A = 'a',
  B = 'b',
  C = 'c',
  D = 'd',
}

export namespace Configs {
  export const DefaultAdmins: AnyObject[] = [
    {
      name: 'SunQ Admin',
      email: 'admin@sunq.com',
      phone: 'No1',
      password: 'SunqAdmin@@.!',
      accountType: Constants.ACCOUNT_TYPE.ADMIN,
      roleGroupName: 'root',
    },
  ];
  export const TicketPrices: AnyObject[] = [
    {
      viewIndex: 0,
      target: 'Học sinh từ > 4 tuổi',
      price: 200000,
      perUnit: 'buổi',
    },
    {
      viewIndex: 1,
      target: 'Người lớn',
      price: 150000,
      perUnit: 'buổi',
    },
    {
      viewIndex: 2,
      target: 'Gia đình',
      price: 150000,
      perUnit: 'buổi',
    },
    {
      viewIndex: 3,
      target: 'Thành viên',
      price: 0,
      perUnit: 'buổi',
    },
  ];
}
