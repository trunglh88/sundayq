import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {AgePlan, AgePlanRelations} from '../models/age-plan.model';
import {Age} from '../models/age.model';
import {AgeRepository} from './age.repository';

export class AgePlanRepository extends DefaultCrudRepository<AgePlan, typeof AgePlan.prototype.id, AgePlanRelations> {

  public readonly age: BelongsToAccessor<Age, typeof AgePlan.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('AgeRepository') ageRepo: Getter<AgeRepository>,
  ) {
    super(AgePlan, dataSource);

    this.age = this.createBelongsToAccessorFor('age', ageRepo);
    this.registerInclusionResolver('age', this.age.inclusionResolver);
  }
}
