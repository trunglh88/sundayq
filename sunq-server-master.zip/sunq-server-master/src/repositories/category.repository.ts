import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Age} from '../models/age.model';
import {Category, CategoryRelations} from '../models/category.model';
import {Service} from '../models/service.model';
import {AgeRepository} from './age.repository';
import {ServiceRepository} from './service.repository';
import {TimeStampRepository} from './timestamp-repository';

export class CategoryRepository extends TimeStampRepository<Category, typeof Category.prototype.id, CategoryRelations> {
  public readonly ages: HasManyRepositoryFactory<Age, typeof Category.prototype.id>;
  public readonly service: BelongsToAccessor<Service, typeof Category.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('AgeRepository') ageRepo: Getter<AgeRepository>,
    @repository.getter('ServiceRepository') serivceRepo: Getter<ServiceRepository>,
  ) {
    super(Category, dataSource);

    this.ages = this.createHasManyRepositoryFactoryFor('ages', ageRepo);
    this.registerInclusionResolver('ages', this.ages.inclusionResolver);

    this.service = this.createBelongsToAccessorFor('service', serivceRepo);
    this.registerInclusionResolver('service', this.service.inclusionResolver);
  }
}
