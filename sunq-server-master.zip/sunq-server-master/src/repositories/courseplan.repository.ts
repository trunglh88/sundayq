import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {CoursePlan, CoursePlanRelations, Teacher} from '../models';
import {TeacherRepository} from './teacher.repository';
import {TimeStampRepository} from './timestamp-repository';

export class CoursePlanRepository extends TimeStampRepository<
  CoursePlan,
  typeof CoursePlan.prototype.id,
  CoursePlanRelations
> {
  public readonly teacher: BelongsToAccessor<Teacher, typeof CoursePlan.prototype.id>;
  public readonly supporter: BelongsToAccessor<Teacher, typeof CoursePlan.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('TeacherRepository') teacherRepo: Getter<TeacherRepository>,
  ) {
    super(CoursePlan, dataSource);
    this.teacher = this.createBelongsToAccessorFor('teacher', teacherRepo);
    this.supporter = this.createBelongsToAccessorFor('supporter', teacherRepo);

    this.registerInclusionResolver('teacher', this.teacher.inclusionResolver);
    this.registerInclusionResolver('supporter', this.supporter.inclusionResolver);
  }
}
