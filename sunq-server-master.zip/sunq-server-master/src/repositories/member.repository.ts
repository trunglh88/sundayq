import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, HasOneRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {AccountRequestBody} from '../model-forms';
import {Account, BaseUser, Member, MemberRelations} from '../models';
import {Refreshtoken} from '../models/commons/refreshtoken.model';
import {objectToEntity} from '../utils';
import {AccountRepository, UserRepository} from './account.repository';
import {RefeshTokenRepository} from './refresh-token.repository';
import {TimeStampRepository} from './timestamp-repository';

export class MemberRepository extends TimeStampRepository<Member, typeof Member.prototype.id, MemberRelations>
  implements UserRepository {
  public readonly account: HasOneRepositoryFactory<Account, typeof Member.prototype.id>;
  public readonly refreshtokens: HasManyRepositoryFactory<Refreshtoken, typeof Member.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('AccountRepository')
    protected accountRepositoryGetter: Getter<AccountRepository>,
    @repository.getter('RefeshTokenRepository')
    protected refeshTokenRepositoryGetter: Getter<RefeshTokenRepository>,
  ) {
    super(Member, dataSource);

    this.account = this.createHasOneRepositoryFactoryFor('account', accountRepositoryGetter);
    this.refreshtokens = this.createHasManyRepositoryFactoryFor('refreshtokens', refeshTokenRepositoryGetter);
  }

  createWithId(uid: string, request: AccountRequestBody): Promise<BaseUser> {
    const user = objectToEntity(request, Member);
    user.id = uid;
    return this.create(user);
  }

  findAccount(uid: string): Promise<Account | undefined> {
    return this.account(uid).get();
  }
}
