import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Member} from '../models';
import {ServiceMember, ServiceMemberRelations} from '../models/service-member.model';
import {Service} from '../models/service.model';
import {Transaction} from '../models/transaction.model';
import {MemberRepository} from './member.repository';
import {ServiceRepository} from './service.repository';
import {TimeStampRepository} from './timestamp-repository';
import {TransactionRepository} from './transaction.repository';

export class ServiceMemberRepository extends TimeStampRepository<
  ServiceMember,
  typeof ServiceMember.prototype.id,
  ServiceMemberRelations
> {
  public readonly member: BelongsToAccessor<Member, typeof ServiceMember.prototype.id>;
  public readonly service: BelongsToAccessor<Service, typeof ServiceMember.prototype.id>;
  public readonly transactions: HasManyRepositoryFactory<Transaction, typeof ServiceMember.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('ServiceRepository') serviceRepo: Getter<ServiceRepository>,
    @repository.getter('MemberRepository') memberRepo: Getter<MemberRepository>,
    @repository.getter('TransactionRepository') transactionRepo: Getter<TransactionRepository>,
  ) {
    super(ServiceMember, dataSource);
    this.member = this.createBelongsToAccessorFor('member', memberRepo);
    this.service = this.createBelongsToAccessorFor('service', serviceRepo);
    this.transactions = this.createHasManyRepositoryFactoryFor('transactions', transactionRepo);



    this.registerInclusionResolver('member', this.member.inclusionResolver);

    this.registerInclusionResolver('service', this.service.inclusionResolver);

    this.registerInclusionResolver('transactions', this.transactions.inclusionResolver);
  }
}
