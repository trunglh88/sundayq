import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Account} from '../models';
import {Order} from '../models/order.model';
import {ServiceMember} from '../models/service-member.model';
import {Transaction, TransactionRelations} from '../models/transaction.model';
import {AccountRepository} from './account.repository';
import {OrderRepository} from './order.repository';
import {ServiceMemberRepository} from './service-member.repository';
import {TimeStampRepository} from './timestamp-repository';

export class TransactionRepository extends TimeStampRepository<
  Transaction,
  typeof Transaction.prototype.id,
  TransactionRelations
> {
  public readonly order: BelongsToAccessor<Order, typeof Transaction.prototype.id>;
  public readonly serviceMember: BelongsToAccessor<ServiceMember, typeof Transaction.prototype.id>;
  public readonly sender: BelongsToAccessor<Account, typeof Transaction.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('OrderRepository') orderRepo: Getter<OrderRepository>,
    @repository.getter('ServiceMemberRepository') serviceMemberRepo: Getter<ServiceMemberRepository>,
    @repository.getter('AccountRepository') accountRepo: Getter<AccountRepository>,
  ) {
    super(Transaction, dataSource);

    this.order = this.createBelongsToAccessorFor('order', orderRepo);
    this.registerInclusionResolver('order', this.order.inclusionResolver);

    this.serviceMember = this.createBelongsToAccessorFor('serviceMember', serviceMemberRepo);
    this.registerInclusionResolver('serviceMember', this.serviceMember.inclusionResolver);

    this.sender = this.createBelongsToAccessorFor('sender', accountRepo);
    this.registerInclusionResolver('sender', this.sender.inclusionResolver);
  }
}
