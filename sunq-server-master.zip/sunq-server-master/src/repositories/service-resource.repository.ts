import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {LessonResource} from '../models/lesson-resource.model';
import {Resource} from '../models/resource.model';
import {ServiceResource, ServiceResourceRelations} from '../models/service-resource.model';
import {Service} from '../models/service.model';
import {ResourceRepository} from './resource.repository';
import {ServiceRepository} from './service.repository';
import {TimeStampRepository} from './timestamp-repository';

export class ServiceResourceRepository extends TimeStampRepository<
  ServiceResource,
  typeof ServiceResource.prototype.id,
  ServiceResourceRelations
  > {
  public readonly service: BelongsToAccessor<Service, typeof LessonResource.prototype.id>;
  public readonly resource: BelongsToAccessor<Resource, typeof LessonResource.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('ServiceRepository') serviceRepo: Getter<ServiceRepository>,
    @repository.getter('ResourceRepository') resourceRepo: Getter<ResourceRepository>,
  ) {
    super(ServiceResource, dataSource);

    this.service = this.createBelongsToAccessorFor('service', serviceRepo);
    this.registerInclusionResolver('service', this.service.inclusionResolver);

    this.resource = this.createBelongsToAccessorFor('resource', resourceRepo);
    this.registerInclusionResolver('resource', this.resource.inclusionResolver);
  }
}
