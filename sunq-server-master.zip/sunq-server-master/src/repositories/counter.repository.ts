import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Counter, CounterRelations} from './../models/counter.model';

export class CounterRepository extends DefaultCrudRepository<Counter, typeof Counter.prototype.id, CounterRelations> {

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource
  ) {
    super(Counter, dataSource);
  }

  async nextCounter(modelName: string): Promise<number> {
    const counter = await this.findOne({where: {modelName: modelName}});
    if (!counter) {
      await this.create({seq: 1, modelName: modelName});
      return 1;
    } else {
      let seq = counter.seq + 1;
      await this.updateById(counter.id, {seq: seq});
      return seq;
    }
  }
}
