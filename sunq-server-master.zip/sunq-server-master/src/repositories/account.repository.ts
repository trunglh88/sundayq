import {Getter, inject} from '@loopback/core';
import {AnyObject, ApplicationWithRepositories, BelongsToAccessor, repository} from '@loopback/repository';
import {HttpErrors} from '@loopback/rest';
import {Constants} from '../constants';
import {MongoDataSource} from '../datasources';
import {AppBindings, PasswordHasherBindings} from '../keys';
import {AccountRequestBody, AppResponse} from '../model-forms';
import {Account, AccountRelations, BaseUser, RoleGroup} from '../models';
import {objectToEntity, PasswordHasher} from '../utils';
import {AdminRepository} from './admin.repository';
import {MemberRepository} from './member.repository';
import {RoleGroupRepository} from './role-group.repository';
import {TeacherRepository} from './teacher.repository';
import {TimeStampRepository} from './timestamp-repository';

export interface UserRepository {
  findById(id: string): Promise<BaseUser | undefined>;
  createWithId(uid: string, request: AccountRequestBody | AnyObject): Promise<BaseUser>;
  findAccount(uid: string): Promise<Account | undefined>;
  updateById(uid: string, request: AnyObject): Promise<void>;
}

export class AccountRepository extends TimeStampRepository<Account, typeof Account.prototype.id, AccountRelations> {
  public readonly roleGroup: BelongsToAccessor<RoleGroup, typeof Account.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @inject(AppBindings.APP) public app: ApplicationWithRepositories,
    @inject(PasswordHasherBindings.PASSWORD_HASHER) public passwordHasher: PasswordHasher,
    @repository.getter('RoleGroupRepository') public roleGroupRepo: Getter<RoleGroupRepository>,
  ) {
    super(Account, dataSource);
    this.roleGroup = this.createBelongsToAccessorFor('roleGroup', roleGroupRepo);

    this.registerInclusionResolver('roleGroup', this.roleGroup.inclusionResolver);
  }

  async getUserRepository(type: Constants.ACCOUNT_TYPE | string | undefined): Promise<UserRepository | undefined> {
    if (type === Constants.ACCOUNT_TYPE.ADMIN) return this.app.getRepository(AdminRepository);
    if (type === Constants.ACCOUNT_TYPE.MEMBER) return this.app.getRepository(MemberRepository);
    if (type === Constants.ACCOUNT_TYPE.TEACHER) return this.app.getRepository(TeacherRepository);
    return undefined;
  }

  async createAccount(
    request: AccountRequestBody | AnyObject,
    accountType?: Constants.ACCOUNT_TYPE,
    state?: Constants.ACCOUNT_STATE,
  ) {
    const type = accountType ?? request.accountType;
    const userRepo = await this.getUserRepository(type);
    if (!userRepo) {
      throw new AppResponse({code: 422, message: 'Account type is not supported.'});
    }
    if (state) request.state = state;
    request.accountType = type;
    request.password = await this.passwordHasher.hashPassword(request.password || request.email);
    try {
      const account = await this.create(objectToEntity(request, Account));
      return await userRepo.createWithId(account.id, request);
    } catch (error) {
      // MongoError 11000 duplicate key
      console.log("error.code : ", error.code);
      console.log("error.errmsg : ", error.errmsg)
      if (error.code === 11000) {
        if (error.errmsg.includes('index: uniqueEmail') || error.errmsg.includes('index: SunQ.Account.$uniqueEmail')) throw new HttpErrors.Conflict('Email is already taken.');
        if (error.errmsg.includes('index: uniqueShortId')) throw new HttpErrors.Conflict('ShortId is already taken.');
      }
      throw error;
    }
  }

  async getAccount(
    id: string,
    accountType: Constants.ACCOUNT_TYPE
  ) {
    const userRepo = await this.getUserRepository(accountType);
    if (!userRepo) {
      throw new AppResponse({code: 422, message: 'Account type is not supported.'});
    }
    return await userRepo.findById(id);

  }

  async editById(
    id: string,
    accountType: Constants.ACCOUNT_TYPE,
    request: AnyObject,
  ) {
    const userRepo = await this.getUserRepository(accountType);
    if (!userRepo) {
      throw new AppResponse({code: 422, message: 'Account type is not supported.'});
    }
    return await userRepo.updateById(id, request);

  }
}
