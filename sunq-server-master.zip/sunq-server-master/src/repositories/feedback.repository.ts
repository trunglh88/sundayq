import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {Feedback, FeedbackRelations} from '../models';
import {TimeStampRepository} from './timestamp-repository';

export class FeedbackRepository extends TimeStampRepository<Feedback, typeof Feedback.prototype.id, FeedbackRelations> {
  constructor(@inject('datasources.mongo') dataSource: MongoDataSource) {
    super(Feedback, dataSource);
  }
}
