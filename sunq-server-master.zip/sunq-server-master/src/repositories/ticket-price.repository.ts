import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {TicketPrice, TicketPriceRelations} from '../models';
import {TimeStampRepository} from './timestamp-repository';

export class TicketPriceRepository extends TimeStampRepository<
  TicketPrice,
  typeof TicketPrice.prototype.id,
  TicketPriceRelations
> {
  constructor(@inject('datasources.mongo') dataSource: MongoDataSource) {
    super(TicketPrice, dataSource);
  }
}
