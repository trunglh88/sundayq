import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {TeacherRepository} from '.';
import {MongoDataSource} from '../datasources';
import {Kit, Teacher} from '../models';
import {Age} from '../models/age.model';
import {Class} from '../models/class.model';
import {LessonMember} from '../models/lesson-member.model';
import {LessonQuestion} from '../models/lesson-question.model';
import {LessonResource} from '../models/lesson-resource.model';
import {Lesson, LessonRelations} from '../models/lesson.model';
import {AgeRepository} from './age.repository';
import {KitRepository} from './kit.repository';
import {LessonMemberRepository} from './lesson-member.repository';
import {LessonQuestionRepository} from './lesson-question.repository';
import {LessonResourceRepository} from './lesson-resource.repository';
import {TimeStampRepository} from './timestamp-repository';

export class LessonRepository extends TimeStampRepository<Lesson, typeof Lesson.prototype.id, LessonRelations> {
  [x: string]: any;
  public readonly lessonResources: HasManyRepositoryFactory<LessonResource, typeof Lesson.prototype.id>;
  public readonly lessonMembers: HasManyRepositoryFactory<LessonMember, typeof Lesson.prototype.id>;
  public readonly lessonQuestions: HasManyRepositoryFactory<LessonQuestion, typeof Lesson.prototype.id>;
  public readonly age: BelongsToAccessor<Age, typeof Lesson.prototype.id>;
  public readonly class: BelongsToAccessor<Class, typeof Lesson.prototype.id>;
  public readonly kit: BelongsToAccessor<Kit, typeof Lesson.prototype.id>;
  public readonly teacher: BelongsToAccessor<Teacher, typeof Lesson.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('AgeRepository') ageRepo: Getter<AgeRepository>,
    @repository.getter('ClassRepository') classRepo: Getter<AgeRepository>,
    @repository.getter('KitRepository') kitRepo: Getter<KitRepository>,
    @repository.getter('LessonMemberRepository') lessonMemberRepo: Getter<LessonMemberRepository>,
    @repository.getter('LessonResourceRepository') lessonResourceRepo: Getter<LessonResourceRepository>,
    @repository.getter('LessonQuestionRepository') lessonQuestionRepo: Getter<LessonQuestionRepository>,
    @repository.getter('TeacherRepository') teacherRepo: Getter<TeacherRepository>,
  ) {
    super(Lesson, dataSource);

    this.age = this.createBelongsToAccessorFor('age', ageRepo);
    this.registerInclusionResolver('age', this.age.inclusionResolver);

    this.class = this.createBelongsToAccessorFor('class', classRepo);
    this.registerInclusionResolver('class', this.class.inclusionResolver);

    this.kit = this.createBelongsToAccessorFor('kit', kitRepo);
    this.registerInclusionResolver('kit', this.kit.inclusionResolver);

    this.lessonResources = this.createHasManyRepositoryFactoryFor('lessonResources', lessonResourceRepo);
    this.registerInclusionResolver('lessonResources', this.lessonResources.inclusionResolver);

    this.lessonMembers = this.createHasManyRepositoryFactoryFor('lessonMembers', lessonMemberRepo);
    this.registerInclusionResolver('lessonMembers', this.lessonMembers.inclusionResolver);

    this.lessonQuestions = this.createHasManyRepositoryFactoryFor('lessonQuestions', lessonQuestionRepo);
    this.registerInclusionResolver('lessonQuestions', this.lessonQuestions.inclusionResolver);

    this.teacher = this.createBelongsToAccessorFor('teacher', teacherRepo);
    this.registerInclusionResolver('teacher', this.teacher.inclusionResolver);
  }
}
