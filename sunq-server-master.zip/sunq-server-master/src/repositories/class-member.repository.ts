import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MemberRepository} from '.';
import {MongoDataSource} from '../datasources';
import {Member} from '../models';
import {ClassMember, ClassMemberRelations} from '../models/class-member.model';
import {Class} from '../models/class.model';
import {ClassRepository} from './class.repository';
import {TimeStampRepository} from './timestamp-repository';

export class ClassMemberRepository extends TimeStampRepository<
  ClassMember,
  typeof ClassMember.prototype.id,
  ClassMemberRelations
> {
  public readonly class: BelongsToAccessor<Class, typeof ClassMember.prototype.id>;
  public readonly member: BelongsToAccessor<Member, typeof ClassMember.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('ClassRepository') classRepo: Getter<ClassRepository>,
    @repository.getter('MemberRepository') memberRepo: Getter<MemberRepository>,
  ) {
    super(ClassMember, dataSource);

    this.class = this.createBelongsToAccessorFor('class', classRepo);
    this.registerInclusionResolver('class', this.class.inclusionResolver);

    this.member = this.createBelongsToAccessorFor('member', memberRepo);
    this.registerInclusionResolver('member', this.member.inclusionResolver);
  }
}
