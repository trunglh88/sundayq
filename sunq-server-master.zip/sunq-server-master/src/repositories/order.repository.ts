import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {KitRepository} from '.';
import {MongoDataSource} from '../datasources';
import {Kit} from '../models';
import {Transaction} from '../models/transaction.model';
import {Order, OrderRelations} from './../models/order.model';
import {TimeStampRepository} from './timestamp-repository';
import {TransactionRepository} from './transaction.repository';

export class OrderRepository extends TimeStampRepository<Order, typeof Order.prototype.id, OrderRelations> {
  public readonly kit: BelongsToAccessor<Kit, typeof Order.prototype.id>;
  public readonly transactions: HasManyRepositoryFactory<Transaction, typeof Order.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('KitRepository') kitRepo: Getter<KitRepository>,
    @repository.getter('TransactionRepository') transactionRepo: Getter<TransactionRepository>,
  ) {
    super(Order, dataSource);

    this.kit = this.createBelongsToAccessorFor('kit', kitRepo);
    this.registerInclusionResolver('kit', this.kit.inclusionResolver);

    this.transactions = this.createHasManyRepositoryFactoryFor('transactions', transactionRepo);
    this.registerInclusionResolver('transactions', this.transactions.inclusionResolver);
  }
}
