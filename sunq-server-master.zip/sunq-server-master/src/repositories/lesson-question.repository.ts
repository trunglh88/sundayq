import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {LessonQuestion, LessonQuestionRelations} from '../models/lesson-question.model';
import {Lesson} from '../models/lesson.model';
import {Question} from '../models/question.model';
import {LessonRepository} from './lesson.repository';
import {QuestionRepository} from './question.repository';
import {TimeStampRepository} from './timestamp-repository';

export class LessonQuestionRepository extends TimeStampRepository<
  LessonQuestion,
  typeof LessonQuestion.prototype.id,
  LessonQuestionRelations
> {
  public readonly lesson: BelongsToAccessor<Lesson, typeof LessonQuestion.prototype.id>;
  public readonly question: BelongsToAccessor<Question, typeof LessonQuestion.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('QuestionRepository') questionRepo: Getter<QuestionRepository>,
  ) {
    super(LessonQuestion, dataSource);

    this.lesson = this.createBelongsToAccessorFor('lesson', lessonRepo);
    this.registerInclusionResolver('lesson', this.lesson.inclusionResolver);

    this.question = this.createBelongsToAccessorFor('question', questionRepo);
    this.registerInclusionResolver('question', this.question.inclusionResolver);
  }
}
