import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Resource} from '../models';
import {LessonQuestion} from '../models/lesson-question.model';
import {Question, QuestionRelations} from '../models/question.model';
import {LessonQuestionRepository} from './lesson-question.repository';
import {TimeStampRepository} from './timestamp-repository';

export class QuestionRepository extends TimeStampRepository<Question, typeof Question.prototype.id, QuestionRelations> {
  public readonly lessonQuestions: HasManyRepositoryFactory<LessonQuestion, typeof Resource.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonQuestionRepository') lessonQuestionRepo: Getter<LessonQuestionRepository>,
  ) {
    super(Question, dataSource);

    this.lessonQuestions = this.createHasManyRepositoryFactoryFor('lessonQuestions', lessonQuestionRepo);
    this.registerInclusionResolver('lessonQuestions', this.lessonQuestions.inclusionResolver);
  }
}
