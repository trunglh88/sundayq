import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Age} from '../models/age.model';
import {Category} from '../models/category.model';
import {Class} from '../models/class.model';
import {ServiceMember} from '../models/service-member.model';
import {ServiceResource} from '../models/service-resource.model';
import {Service, ServiceRelations} from '../models/service.model';
import {AgeRepository} from './age.repository';
import {CategoryRepository} from './category.repository';
import {ClassRepository} from './class.repository';
import {ServiceMemberRepository} from './service-member.repository';
import {ServiceResourceRepository} from './service-resource.repository';
import {TimeStampRepository} from './timestamp-repository';

export class ServiceRepository extends TimeStampRepository<Service, typeof Service.prototype.id, ServiceRelations> {
  public readonly serviceMembers: HasManyRepositoryFactory<ServiceMember, typeof Service.prototype.id>;

  public readonly ages: HasManyRepositoryFactory<Age, typeof Service.prototype.id>;

  public readonly classes: HasManyRepositoryFactory<Class, typeof Service.prototype.id>;

  public readonly categories: HasManyRepositoryFactory<Category, typeof Service.prototype.id>;

  public readonly serviceResources: HasManyRepositoryFactory<ServiceResource, typeof Service.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('ServiceMemberRepository') serviceMemberRepo: Getter<ServiceMemberRepository>,
    @repository.getter('AgeRepository') ageRepo: Getter<AgeRepository>,
    @repository.getter('ClassRepository') classRepo: Getter<ClassRepository>,
    @repository.getter('CategoryRepository') categoryRepo: Getter<CategoryRepository>,
    @repository.getter('ServiceResourceRepository') serviceResourceRepo: Getter<ServiceResourceRepository>,
  ) {
    super(Service, dataSource);

    this.serviceMembers = this.createHasManyRepositoryFactoryFor('serviceMembers', serviceMemberRepo);

    this.registerInclusionResolver('serviceMembers', this.serviceMembers.inclusionResolver);

    this.ages = this.createHasManyRepositoryFactoryFor('ages', ageRepo);

    this.registerInclusionResolver('ages', this.ages.inclusionResolver);

    this.classes = this.createHasManyRepositoryFactoryFor('classes', classRepo);

    this.registerInclusionResolver('classes', this.classes.inclusionResolver);

    this.categories = this.createHasManyRepositoryFactoryFor('categories', categoryRepo);

    this.registerInclusionResolver('categories', this.categories.inclusionResolver);

    this.serviceResources = this.createHasManyRepositoryFactoryFor('serviceResources', serviceResourceRepo);

    this.registerInclusionResolver('serviceResources', this.serviceResources.inclusionResolver);
  }
}
