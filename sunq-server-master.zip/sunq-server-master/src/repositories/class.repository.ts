import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Class, ClassRelations} from '../models/class.model';
import {Lesson} from '../models/lesson.model';
import {Service} from '../models/service.model';
import {LessonRepository} from './lesson.repository';
import {ServiceRepository} from './service.repository';
import {TimeStampRepository} from './timestamp-repository';

export class ClassRepository extends TimeStampRepository<Class, typeof Class.prototype.id, ClassRelations> {
  public readonly lessons: HasManyRepositoryFactory<Lesson, typeof Class.prototype.id>;
  public readonly service: BelongsToAccessor<Service, typeof Class.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('ServiceRepository') serivceRepo: Getter<ServiceRepository>,
  ) {
    super(Class, dataSource);

    this.lessons = this.createHasManyRepositoryFactoryFor('lessons', lessonRepo);
    this.registerInclusionResolver('lessons', this.lessons.inclusionResolver);

    this.service = this.createBelongsToAccessorFor('service', serivceRepo);
    this.registerInclusionResolver('service', this.service.inclusionResolver);
  }
}
