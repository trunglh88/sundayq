import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {LessonResource, LessonResourceRelations} from '../models/lesson-resource.model';
import {Lesson} from '../models/lesson.model';
import {Resource} from '../models/resource.model';
import {LessonRepository} from './lesson.repository';
import {ResourceRepository} from './resource.repository';
import {TimeStampRepository} from './timestamp-repository';

export class LessonResourceRepository extends TimeStampRepository<
  LessonResource,
  typeof LessonResource.prototype.id,
  LessonResourceRelations
> {
  public readonly lesson: BelongsToAccessor<Lesson, typeof LessonResource.prototype.id>;
  public readonly resource: BelongsToAccessor<Resource, typeof LessonResource.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('ResourceRepository') resourceRepo: Getter<ResourceRepository>,
  ) {
    super(LessonResource, dataSource);

    this.lesson = this.createBelongsToAccessorFor('lesson', lessonRepo);
    this.registerInclusionResolver('lesson', this.lesson.inclusionResolver);

    this.resource = this.createBelongsToAccessorFor('resource', resourceRepo);
    this.registerInclusionResolver('resource', this.resource.inclusionResolver);
  }
}
