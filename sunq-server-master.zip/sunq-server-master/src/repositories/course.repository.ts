import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {
  AccountGetAdvice,
  Course,
  CourseOwner,
  CourseOwnerRelations,
  CoursePlan,
  CourseRelations,
  Teacher,
} from '../models';
import {AccountGetAdviceRepository} from './account-get-advice.repository';
import {CoursePlanRepository} from './courseplan.repository';
import {TeacherRepository} from './teacher.repository';
import {TimeStampRepository} from './timestamp-repository';

export class CourseOwnerRepository extends TimeStampRepository<
  CourseOwner,
  typeof CourseOwner.prototype.courseId,
  CourseOwnerRelations
> {
  public readonly teacher: BelongsToAccessor<Teacher, typeof CourseOwner.prototype.teacherId>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('TeacherRepository') teacherRepo: Getter<TeacherRepository>,
  ) {
    super(CourseOwner, dataSource);
    this.teacher = this.createBelongsToAccessorFor('teacher', teacherRepo);

    this.registerInclusionResolver('teacher', this.teacher.inclusionResolver);
  }
}

export class CourseRepository extends TimeStampRepository<Course, typeof Course.prototype.id, CourseRelations> {
  public readonly owners: HasManyRepositoryFactory<CourseOwner, typeof Course.prototype.id>;
  public readonly coursePlans: HasManyRepositoryFactory<CoursePlan, typeof Course.prototype.id>;
  public readonly accountGetAdvices: HasManyRepositoryFactory<AccountGetAdvice, typeof Course.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('CourseOwnerRepository') courseOwnerRepo: Getter<CourseOwnerRepository>,
    @repository.getter('CoursePlanRepository') coursePlanRepo: Getter<CoursePlanRepository>,
    @repository.getter('AccountGetAdviceRepository') accountGetAdviceRepo: Getter<AccountGetAdviceRepository>,
  ) {
    super(Course, dataSource);
    this.owners = this.createHasManyRepositoryFactoryFor('owners', courseOwnerRepo);
    this.coursePlans = this.createHasManyRepositoryFactoryFor('coursePlans', coursePlanRepo);
    this.accountGetAdvices = this.createHasManyRepositoryFactoryFor('accountGetAdvices', accountGetAdviceRepo);

    this.registerInclusionResolver('coursePlans', this.coursePlans.inclusionResolver);
    this.registerInclusionResolver('owners', this.owners.inclusionResolver);
    this.registerInclusionResolver('accountGetAdvices', this.accountGetAdvices.inclusionResolver);
  }
}
