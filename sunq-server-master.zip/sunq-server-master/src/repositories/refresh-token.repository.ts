import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {Refreshtoken, RefreshtokenRelations} from '../models';
import {TimeStampRepository} from './timestamp-repository';

export class RefeshTokenRepository extends TimeStampRepository<
  Refreshtoken,
  typeof Refreshtoken.prototype.id,
  RefreshtokenRelations
> {
  constructor(@inject('datasources.mongo') dataSource: MongoDataSource) {
    super(Refreshtoken, dataSource);
  }
}
