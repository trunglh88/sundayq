import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Account, RoleGroup, RoleGroupRelations} from '../models';
import {AccountRepository} from './account.repository';
import {TimeStampRepository} from './timestamp-repository';

export class RoleGroupRepository extends TimeStampRepository<
  RoleGroup,
  typeof RoleGroup.prototype.id,
  RoleGroupRelations
> {
  public readonly accounts: HasManyRepositoryFactory<Account, typeof RoleGroup.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('AccountRepository') accountRepo: Getter<AccountRepository>,
  ) {
    super(RoleGroup, dataSource);
    this.accounts = this.createHasManyRepositoryFactoryFor('accounts', accountRepo);

    this.registerInclusionResolver('accounts', this.accounts.inclusionResolver);
  }
}
