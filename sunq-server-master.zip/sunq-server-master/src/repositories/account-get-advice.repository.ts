import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {AccountGetAdvice, AccountRelations, Course} from '../models';
import {CourseRepository} from './course.repository';
import {TimeStampRepository} from './timestamp-repository';

export class AccountGetAdviceRepository extends TimeStampRepository<
  AccountGetAdvice,
  typeof AccountGetAdvice.prototype.id,
  AccountRelations
> {
  public readonly course: BelongsToAccessor<Course, typeof AccountGetAdvice.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('CourseRepository') courseRepo: Getter<CourseRepository>,
  ) {
    super(AccountGetAdvice, dataSource);
    this.course = this.createBelongsToAccessorFor('course', courseRepo);

    this.registerInclusionResolver('course', this.course.inclusionResolver);
  }
}
