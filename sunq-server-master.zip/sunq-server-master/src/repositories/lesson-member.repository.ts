import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, repository} from '@loopback/repository';
import {MemberRepository} from '.';
import {MongoDataSource} from '../datasources';
import {Member} from '../models';
import {LessonMember, LessonMemberRelations} from '../models/lesson-member.model';
import {Lesson} from '../models/lesson.model';
import {LessonRepository} from './lesson.repository';
import {TimeStampRepository} from './timestamp-repository';

export class LessonMemberRepository extends TimeStampRepository<
  LessonMember,
  typeof LessonMember.prototype.id,
  LessonMemberRelations
> {
  public readonly lesson: BelongsToAccessor<Lesson, typeof LessonMember.prototype.id>;
  public readonly member: BelongsToAccessor<Member, typeof LessonMember.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('MemberRepository') memberRepo: Getter<MemberRepository>,
  ) {
    super(LessonMember, dataSource);

    this.lesson = this.createBelongsToAccessorFor('lesson', lessonRepo);
    this.registerInclusionResolver('lesson', this.lesson.inclusionResolver);

    this.member = this.createBelongsToAccessorFor('member', memberRepo);
    this.registerInclusionResolver('member', this.member.inclusionResolver);
  }
}
