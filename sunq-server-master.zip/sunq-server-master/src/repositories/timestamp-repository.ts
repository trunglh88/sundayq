import {AnyObject, DataObject, DefaultCrudRepository, Entity, juggler, Where} from '@loopback/repository';
import {Timestamp} from '../models';
import crypto = require('crypto');

export class TimeStampRepository<T extends Timestamp, ID, Relations extends object = {}> extends DefaultCrudRepository<
  T,
  ID,
  Relations
> {
  constructor(public entityClass: typeof Entity & {prototype: T}, public dataSource: juggler.DataSource) {
    super(entityClass, dataSource);
  }

  async create(entity: DataObject<T & {id: ID}>, options?: AnyObject) {
    if (!entity.id) entity.id = crypto.randomBytes(16).toString('Hex') + new Date().getTime();
    entity.createAt = new Date();
    entity.updateAt = new Date();
    return super.create(entity, options);
  }

  async createAll(entities: DataObject<T & {id: string}>[], options?: AnyObject) {
    entities = entities.map((entity) => {
      if (!entity.id) entity.id = crypto.randomBytes(16).toString('Hex') + new Date().getTime();
      entity.createAt = new Date();
      entity.updateAt = new Date();
      return entity;
    });
    return super.createAll!(entities, options);
  }

  updateAll(data: DataObject<T>, where?: Where<T>, options?: AnyObject) {
    data.updateAt = new Date();
    return super.updateAll(data, where, options);
  }

  replaceById(id: ID, data: DataObject<T>, options?: AnyObject) {
    data.updateAt = new Date();
    return super.replaceById(id, data, options);
  }

  // findById(id: ID, filter?: FilterExcludingWhere<T>, options?: AnyObject) {
  //   data.updateAt = new Date();
  //   return super.findById(id, data, options);
  // }
}
