import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {Log, LogRelations} from '../models/log.model';
import {TimeStampRepository} from './timestamp-repository';

export class LogRepository extends TimeStampRepository<
  Log,
  typeof Log.prototype.id,
  LogRelations
  > {

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
  ) {
    super(Log, dataSource);
  }
}
