import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {Ticket, TicketRelations} from '../models';
import {TimeStampRepository} from './timestamp-repository';

export class TicketRepository extends TimeStampRepository<Ticket, typeof Ticket.prototype.id, TicketRelations> {
  constructor(@inject('datasources.mongo') dataSource: MongoDataSource) {
    super(Ticket, dataSource);
  }
}

