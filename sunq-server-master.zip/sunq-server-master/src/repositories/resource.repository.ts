import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Resource, ResourceRelations} from '../models';
import {LessonResource} from '../models/lesson-resource.model';
import {ServiceResource} from '../models/service-resource.model';
import {LessonResourceRepository} from './lesson-resource.repository';
import {ServiceResourceRepository} from './service-resource.repository';
import {TimeStampRepository} from './timestamp-repository';

export class ResourceRepository extends TimeStampRepository<Resource, typeof Resource.prototype.id, ResourceRelations> {
  public readonly lessonResources: HasManyRepositoryFactory<LessonResource, typeof Resource.prototype.id>;
  public readonly serviceResources: HasManyRepositoryFactory<ServiceResource, typeof Resource.prototype.id>;


  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonResourceRepository') lessonResourceRepo: Getter<LessonResourceRepository>,
    @repository.getter('ServiceResourceRepository') serviceResourceRepo: Getter<ServiceResourceRepository>,
  ) {
    super(Resource, dataSource);

    this.lessonResources = this.createHasManyRepositoryFactoryFor('lessonResources', lessonResourceRepo);
    this.registerInclusionResolver('lessonResources', this.lessonResources.inclusionResolver);

    this.serviceResources = this.createHasManyRepositoryFactoryFor('serviceResources', serviceResourceRepo);
    this.registerInclusionResolver('serviceResources', this.serviceResources.inclusionResolver);
  }
}
