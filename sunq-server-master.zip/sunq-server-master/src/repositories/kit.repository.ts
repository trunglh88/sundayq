import {Getter, inject} from '@loopback/core';
import {HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {Kit, KitRelations} from '../models';
import {Lesson} from '../models/lesson.model';
import {Order} from './../models/order.model';
import {LessonRepository} from './lesson.repository';
import {OrderRepository} from './order.repository';
import {TimeStampRepository} from './timestamp-repository';

export class KitRepository extends TimeStampRepository<Kit, typeof Kit.prototype.id, KitRelations> {
  public readonly lessons: HasManyRepositoryFactory<Lesson, typeof Kit.prototype.id>;
  public readonly orders: HasManyRepositoryFactory<Order, typeof Kit.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('OrderRepository') orderRepo: Getter<OrderRepository>,
  ) {
    super(Kit, dataSource);

    this.lessons = this.createHasManyRepositoryFactoryFor('lessons', lessonRepo);
    this.registerInclusionResolver('lessons', this.lessons.inclusionResolver);

    this.orders = this.createHasManyRepositoryFactoryFor('orders', orderRepo);
    this.registerInclusionResolver('orders', this.orders.inclusionResolver);
  }
}
