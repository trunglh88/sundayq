import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {MongoDataSource} from '../datasources';
import {AgePlan} from '../models/age-plan.model';
import {Age, AgeRelations} from '../models/age.model';
import {Category} from '../models/category.model';
import {Lesson} from '../models/lesson.model';
import {Service} from '../models/service.model';
import {AgePlanRepository} from './age-plan.repository';
import {CategoryRepository} from './category.repository';
import {LessonRepository} from './lesson.repository';
import {ServiceRepository} from './service.repository';
import {TimeStampRepository} from './timestamp-repository';

export class AgeRepository extends TimeStampRepository<Age, typeof Age.prototype.id, AgeRelations> {
  public readonly lessons: HasManyRepositoryFactory<Lesson, typeof Age.prototype.id>;
  public readonly agePlans: HasManyRepositoryFactory<AgePlan, typeof Age.prototype.id>;
  public readonly service: BelongsToAccessor<Service, typeof Age.prototype.id>;
  public readonly category: BelongsToAccessor<Category, typeof Age.prototype.id>;

  constructor(
    @inject('datasources.mongo') dataSource: MongoDataSource,
    @repository.getter('LessonRepository') lessonRepo: Getter<LessonRepository>,
    @repository.getter('AgePlanRepository') agePlanRepo: Getter<AgePlanRepository>,
    @repository.getter('ServiceRepository') serivceRepo: Getter<ServiceRepository>,
    @repository.getter('CategoryRepository') categoryRepo: Getter<CategoryRepository>,
  ) {
    super(Age, dataSource);

    this.lessons = this.createHasManyRepositoryFactoryFor('lessons', lessonRepo);
    this.registerInclusionResolver('lessons', this.lessons.inclusionResolver);

    this.agePlans = this.createHasManyRepositoryFactoryFor('agePlans', agePlanRepo);
    this.registerInclusionResolver('agePlans', this.lessons.inclusionResolver);

    this.service = this.createBelongsToAccessorFor('service', serivceRepo);
    this.registerInclusionResolver('service', this.service.inclusionResolver);

    this.category = this.createBelongsToAccessorFor('category', categoryRepo);
    this.registerInclusionResolver('category', this.category.inclusionResolver);
  }
}
