import {inject} from '@loopback/core';
import {MongoDataSource} from '../datasources';
import {Otp, OtpRelations} from '../models/otp.model';
import {TimeStampRepository} from './timestamp-repository';

export class OtpRepository extends TimeStampRepository<Otp, typeof Otp.prototype.id, OtpRelations> {
  constructor(@inject('datasources.mongo') dataSource: MongoDataSource) {
    super(Otp, dataSource);
  }
}
