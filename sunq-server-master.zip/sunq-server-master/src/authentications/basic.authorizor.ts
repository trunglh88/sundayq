import {AuthorizationContext, AuthorizationDecision, AuthorizationMetadata} from '@loopback/authorization';
import {securityId, UserProfile} from '@loopback/security';

export async function basicAuthor(
  authorizationCtx: AuthorizationContext,
  metadata: AuthorizationMetadata,
): Promise<AuthorizationDecision> {
  // No access if authorization details are missing
  let currentUser: UserProfile;
  if (authorizationCtx.principals.length > 0) {
    const {uType} = authorizationCtx.principals[0];
    const id = authorizationCtx.principals[0][securityId];
    currentUser = {[securityId]: id, uType: uType};
  } else {
    return AuthorizationDecision.DENY;
  }

  if (!currentUser.uType) {
    return AuthorizationDecision.DENY;
  }

  // Authorize everything that does not have a allowedRoles property
  if (!metadata.allowedRoles) {
    return AuthorizationDecision.ALLOW;
  }

  if (metadata.allowedRoles.includes(currentUser.uType)) {
    return AuthorizationDecision.ALLOW;
  }

  /**
   * Allow access only to model owners, using route as source of truth
   *
   * eg. @post('/users/{userId}/orders', ...) returns `userId` as args[0]
   */
  if (
    metadata.allowedRoles.includes('owner') &&
    currentUser[securityId] === authorizationCtx.invocationContext.args[0]
  ) {
    return AuthorizationDecision.ALLOW;
  }

  return AuthorizationDecision.DENY;
}
