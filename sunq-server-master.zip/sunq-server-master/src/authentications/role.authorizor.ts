import {AuthorizationContext, AuthorizationDecision, AuthorizationMetadata} from '@loopback/authorization';
import {securityId, UserProfile} from '@loopback/security';
import {Scope} from '../constants';
import {AppBindings, RoleBindings} from '../keys';
import {AccountRepository} from '../repositories';

interface MyAuthorizationMetadata extends AuthorizationMetadata {
  currentUser?: UserProfile;
  decision?: AuthorizationDecision;
}

export async function roleAuthor(
  authorizationCtx: AuthorizationContext,
  metadata: MyAuthorizationMetadata,
): Promise<AuthorizationDecision> {
  console.log('authorizationCtx : ', authorizationCtx);
  console.log('metadata : ', metadata);
  let currentUser: UserProfile;
  if (authorizationCtx.principals.length > 0) {
    const {type} = authorizationCtx.principals[0];
    const id = authorizationCtx.principals[0][securityId];
    currentUser = {[securityId]: id, type: type};
  } else {
    return AuthorizationDecision.DENY;
  }

  console.log(1);

  const context = authorizationCtx.invocationContext;
  const app = await context.get(AppBindings.APP);
  const accountRepo = await app.getRepository(AccountRepository);

  const roleGroup = await accountRepo.roleGroup(currentUser[securityId]);

  console.log(2);

  if (!roleGroup) return AuthorizationDecision.DENY;
  if (roleGroup.name === 'root') {
    context.bind(RoleBindings.ROLEGROUP).to(roleGroup);
    context.bind(RoleBindings.SCOPE).to(Object.values(Scope));
    return AuthorizationDecision.ALLOW;
  }
  console.log(3);
  if (!roleGroup.roles || roleGroup.roles.length < 1) return AuthorizationDecision.DENY;
  if (!metadata.resource) return AuthorizationDecision.DENY;

  console.log(4);

  const resourceRoles = roleGroup.roles.filter((role) => {
    return role.resource === metadata.resource;
  });

  if (resourceRoles.length === 0) return AuthorizationDecision.DENY;
  const scopes: Scope[] = [];
  resourceRoles.forEach((role) => {
    scopes.push(...role.scopes);
  });

  console.log(5);

  context.bind(RoleBindings.ROLEGROUP).to(roleGroup);
  context.bind(RoleBindings.SCOPE).to(scopes);
  context.bind(RoleBindings.RESOURCE).to(metadata.resource);

  console.log(6);

  if (!metadata.scopes || metadata.scopes.length === 0) return AuthorizationDecision.ALLOW;

  console.log(7);

  for await (const scope of metadata.scopes) {
    if (!scopes.includes(scope as Scope)) return AuthorizationDecision.DENY;
  }
  console.log(8);
  return AuthorizationDecision.ALLOW;
}
