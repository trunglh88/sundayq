import {AuthorizationContext, AuthorizationDecision, AuthorizationMetadata} from '@loopback/authorization';
import {securityId, UserProfile} from '@loopback/security';
import {Constants} from '../constants';
import {AppBindings} from '../keys';
import {ServiceMemberRepository} from '../repositories';
import {AgePlanRepository} from '../repositories/age-plan.repository';
import {AgeRepository} from '../repositories/age.repository';

interface MyAuthorizationMetadata extends AuthorizationMetadata {
  currentUser?: UserProfile;
  decision?: AuthorizationDecision;
}

export async function serviceAuthor(
  authorizationCtx: AuthorizationContext,
  metadata: MyAuthorizationMetadata,
): Promise<AuthorizationDecision> {
  let currentUser: UserProfile;
  if (authorizationCtx.principals.length > 0) {
    const {type} = authorizationCtx.principals[0];
    const id = authorizationCtx.principals[0][securityId];
    currentUser = {[securityId]: id, type: type};
  } else {
    return AuthorizationDecision.DENY;
  }

  const context = authorizationCtx.invocationContext;
  const app = await context.get(AppBindings.APP);
  const serviceMemberRepo = await app.getRepository(ServiceMemberRepository);
  const agePlanRepo = await app.getRepository(AgePlanRepository);
  const ageRepo = await app.getRepository(AgeRepository);

  console.log("authorizationCtx.principals[0].uType : ", authorizationCtx.principals[0].uType)
  if (authorizationCtx.principals[0].uType !== Constants.ACCOUNT_TYPE.MEMBER) {
    return AuthorizationDecision.ALLOW;
  }

  const resourceName: string = metadata.resource || '';

  if (resourceName === 'AgePlan') {
    const age: any = await ageRepo.findOne({
      where: {type: authorizationCtx.invocationContext.args[0]},
      include: [{relation: 'service'}],
    });
    if (!age) {
      return AuthorizationDecision.DENY;
    }
    const serviceMember = await serviceMemberRepo.findOne({
      where: {serviceId: age.service.serviceId, memberId: authorizationCtx.principals[0].id},
    });
    if (!serviceMember) {
      return AuthorizationDecision.DENY;
    }
    console.log('age : ', age);
    const currentDateTimeNumber = new Date().getTime();
    const startTimeNumber = serviceMember.startTime.getTime();
    const endTimeNumber = serviceMember.endTime.getTime();
    if (currentDateTimeNumber < startTimeNumber || currentDateTimeNumber > endTimeNumber) {
      return AuthorizationDecision.DENY;
    }
  }
  return AuthorizationDecision.ALLOW;
}
