import {model, property} from '@loopback/repository';

@model()
export class CreatePaymentBody {
  @property({required: true})
  ipAddr: any;

  @property({required: true})
  txnRef: number;

  @property({required: true})
  amount: number;

  @property({required: true})
  orderInfo: string;

  @property()
  locale: string;

  constructor(ipAddr: any, txnRef: number, amount: number, orderInfo: string, locale?: string) {
    this.ipAddr = ipAddr;
    this.txnRef = txnRef;
    this.amount = amount;
    this.orderInfo = orderInfo;
    this.locale = locale || 'vn'
  }
}
