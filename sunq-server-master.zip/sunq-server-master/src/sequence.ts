import {AuthenticateFn, AuthenticationBindings} from '@loopback/authentication';
import {inject, Setter} from '@loopback/context';
import {
  FindRoute,
  InvokeMethod,
  ParseParams,
  Reject,
  Request,
  RequestContext,
  RestBindings,
  Send,
  SequenceHandler,
} from '@loopback/rest';
import {RequestBindings} from './keys';
import {AppResponse} from './model-forms';
import {Log} from './utils';

const SequenceActions = RestBindings.SequenceActions;

export class MySequence implements SequenceHandler {
  constructor(
    @inject(SequenceActions.FIND_ROUTE) protected findRoute: FindRoute,
    @inject(SequenceActions.PARSE_PARAMS) protected parseParams: ParseParams,
    @inject(SequenceActions.INVOKE_METHOD) protected invoke: InvokeMethod,
    @inject(SequenceActions.SEND) public send: Send,
    @inject(SequenceActions.REJECT) public reject: Reject,
    @inject(AuthenticationBindings.AUTH_ACTION) protected authenticateRequest: AuthenticateFn,
    @inject.setter(RequestBindings.IP) protected setRequestIP: Setter<string>,
  ) {}

  async handle(context: RequestContext) {
    let userProfile, requestIP;
    const {request, response} = context;
    let path = `[${request.path}]`;
    // response.removeHeader('x-powered-by');
    try {
      requestIP = this.getRequestIP(request);
      this.setRequestIP(requestIP);
      const route = this.findRoute(request);
      userProfile = await this.authenticateRequest(request);
      if (userProfile) path += ` <${userProfile.id}>`;
      Log.v('Client', requestIP, request.method, path);
      const args = await this.parseParams(request, route);
      const result = await this.invoke(route, args);
      this.send(response, result);
    } catch (err) {
      console.log('err : ', err);
      const data = AppResponse.fromError(err);

      if (data) {
        context.response.status(data.code);
        console.log('data : ', data);
        if (data.code == 422) {
          data.message = data.message?.replace('should have required property', 'Cần có thuộc tính');
          data.message = data.message?.replace('should match format', 'cần đúng định dạng');
        }
        Log.d('Handled error', requestIP, request.method, path, data);
        this.send(response, data);
      } else {
        Log.e('Unhandled error', requestIP, request.method, path, err);
        this.reject(context, err);
      }
    }
  }

  getRequestIP(req: Request) {
    return (
      (req.headers['x-forwarded-for']
        ?.toString()
        .split(',')
        .pop() ??
        req.connection.remoteAddress ??
        req.socket.remoteAddress ??
        req.ips[0]) ||
      req.ip
    );
  }
}
