import {Entity, model, property} from '@loopback/repository';

@model()
export class RefreshTokenRequestBody extends Entity {
  @property({required: true})
  refreshtoken: string;

  constructor(data?: Partial<RefreshTokenRequestBody>) {
    super(data);
  }
}
