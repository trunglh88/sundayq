import {Entity, model, property} from '@loopback/repository';
import {Constants, Scope} from '../../constants';
import {Role} from '../../models';
import {RegexForm} from '../../utils';

@model()
export class AccountRequestBody extends Entity {
  @property({required: true, jsonSchema: {minLength: 1}})
  name: string;

  @property({required: true, jsonSchema: {format: 'email'}})
  email: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property({required: true, jsonSchema: {minLength: 6}})
  password: string;

  // @property({jsonSchema: {format: 'regex', pattern: RegexForm.ACCOUNT_TYPE}})
  // accountType?: Constants.ACCOUNT_TYPE;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<AccountRequestBody>) {
    super(data);
  }
}

@model()
export class EditAccountRequestBody extends Entity {
  @property()
  name: string;

  @property()
  imgUrl: string;

  [prop: string]: any;

  constructor(data?: Partial<EditAccountRequestBody>) {
    super(data);
  }
}

@model()
export class VerifyTokenMemberRequestBody extends Entity {
  @property({required: true})
  token: string;

  constructor(data?: Partial<VerifyTokenMemberRequestBody>) {
    super(data);
  }
}

@model()
export class AccountPasswordRequestBody extends Entity {
  @property({required: true, jsonSchema: {minLength: 6}})
  password: string;

  constructor(data?: Partial<AccountPasswordRequestBody>) {
    super(data);
  }
}

@model()
export class AccountChangePasswordRequestBody extends Entity {
  @property({required: true, jsonSchema: {minLength: 6}})
  oldPassword: string;

  @property({required: true, jsonSchema: {minLength: 6}})
  newPassword: string;

  constructor(data?: Partial<AccountChangePasswordRequestBody>) {
    super(data);
  }
}

@model()
export class ResetPasswordRequestBody extends Entity {
  @property({required: true, jsonSchema: {format: 'email'}})
  email: string;

  constructor(data?: Partial<ResetPasswordRequestBody>) {
    super(data);
  }
}

@model()
export class CheckOtpRequestBody extends Entity {
  @property({required: true, jsonSchema: {format: 'email'}})
  email: string;

  @property({required: true})
  code: string;

  constructor(data?: Partial<ResetPasswordRequestBody>) {
    super(data);
  }
}

@model()
export class UpdatePasswordWithOtpRequestBody extends Entity {
  @property({required: true, jsonSchema: {format: 'email'}})
  email: string;

  @property({required: true})
  code: string;

  @property({required: true})
  password: string;

  constructor(data?: Partial<ResetPasswordRequestBody>) {
    super(data);
  }
}

@model()
export class AccountStateRequestBody extends Entity {
  @property({required: true, jsonSchema: {enum: Object.values(Constants.ACCOUNT_STATE)}})
  state: Constants.ACCOUNT_STATE;

  constructor(data?: Partial<AccountStateRequestBody>) {
    super(data);
  }
}

@model()
export class AccountGetAdviceRequestBody extends Entity {
  @property({required: true, jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({required: true, jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property()
  note: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<AccountGetAdviceRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateAccountGetAdviceRequestBody extends Entity {
  @property({required: true})
  isGotAdvice: boolean;

  @property()
  adminNote: string;

  constructor(data?: Partial<UpdateAccountGetAdviceRequestBody>) {
    super(data);
  }
}

@model()
export class RoleGroupRequestBody extends Entity {
  @property({required: true})
  name: string;

  @property.array(Role)
  roles: Role[];

  constructor(data?: Partial<RoleGroupRequestBody>) {
    super(data);
  }
}

@model()
export class CheckRoleRequestBody extends Entity {
  @property({required: true})
  resource: string;

  @property({required: true, jsonSchema: {enum: Object.values(Scope)}})
  scope: string;

  constructor(data?: Partial<CheckRoleRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateBaseProfileRequestBody extends Entity {
  @property()
  imgUrl: string;

  @property()
  name: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  constructor(data?: Partial<UpdateBaseProfileRequestBody>) {
    super(data);
  }
}
