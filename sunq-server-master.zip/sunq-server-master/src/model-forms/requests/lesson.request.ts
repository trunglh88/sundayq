import {Entity, model, property} from '@loopback/repository';
import {STEAM_CATEGORIES} from '../../constants';

@model()
export class LessonRequestBody extends Entity {
  @property({require: false})
  title: string;

  @property({require: true})
  month: number;

  @property()
  description: string;

  @property()
  thumbnailUrl: string;

  @property()
  shortDescription: string;

  @property()
  kitId: string;

  @property()
  isSampleLesson: boolean;

  @property.array(String)
  resources: string[];

  @property.array(String)
  questionIds: string[];

  @property()
  category: STEAM_CATEGORIES;

  constructor(data?: Partial<LessonRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateLessonRequestBody extends Entity {
  @property({require: false})
  title: string;

  @property({require: true})
  month: number;

  @property()
  isSampleLesson: boolean;

  @property()
  description: string;

  @property()
  thumbnailUrl: string;

  @property()
  shortDescription: string;

  @property()
  kitId: string;

  @property.array(String)
  resources: string[];

  @property()
  category: STEAM_CATEGORIES;

  @property.array(String)
  questionIds: string[];

  constructor(data?: Partial<UpdateLessonRequestBody>) {
    super(data);
  }
}
