import {Entity, model, property} from '@loopback/repository';

@model()
export class ExhibitionRequestBody extends Entity {
  @property({default: 999999999})
  viewIndex: number;

  @property({default: -1})
  minTargetAge: number;

  @property({default: -1})
  maxTargetAge: number;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<ExhibitionRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateExhibitionRequestBody extends Entity {
  @property()
  viewIndex: number;

  @property()
  minTargetAge: number;

  @property()
  maxTargetAge: number;

  @property()
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<UpdateExhibitionRequestBody>) {
    super(data);
  }
}
