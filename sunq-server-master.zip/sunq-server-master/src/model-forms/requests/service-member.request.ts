import {Entity, model, property} from '@loopback/repository';

@model()
export class ServiceMemberRequestBody extends Entity {
  @property({required: true})
  serviceId: string;

  constructor(data?: Partial<ServiceMemberRequestBody>) {
    super(data);
  }
}
