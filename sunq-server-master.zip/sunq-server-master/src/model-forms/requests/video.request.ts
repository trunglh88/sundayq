import {Entity, model, property} from '@loopback/repository';

@model()
export class VideoRequestBody extends Entity {
  @property({required: true})
  title: string;

  @property({required: false})
  description: string;

  @property({require: false})
  shortDescription: string;

  @property({require: false})
  thumbnailUrl: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // [prop: string]: any;

  constructor(data?: Partial<VideoRequestBody>) {
    super(data);
  }
}
