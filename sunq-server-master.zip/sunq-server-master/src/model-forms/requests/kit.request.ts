import {Entity, model, property} from '@loopback/repository';

@model()
export class KitRequestBody extends Entity {

  @property()
  title: string;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property.array(String)
  thumbnailUrls: string[];

  @property()
  price: number;

  constructor(data?: Partial<KitRequestBody>) {
    super(data);
  }
}
