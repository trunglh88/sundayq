import {Entity, model, property} from '@loopback/repository';

@model()
export class ResourceRequest extends Entity {
  @property()
  id: string;

  @property()
  title: string;

  constructor(data?: Partial<ResourceRequest>) {
    super(data);
  }
}
