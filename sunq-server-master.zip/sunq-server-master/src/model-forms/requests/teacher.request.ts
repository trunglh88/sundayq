import {Entity, model, property} from '@loopback/repository';
import {RegexForm} from '../../utils';

@model()
export class CreateTeacherRequestBody extends Entity {
  @property({required: true, jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone?: string;

  @property({default: ''})
  imgUrl?: string;

  @property()
  shortId?: string;

  @property()
  university: string;

  @property({required: true})
  degree: string;

  @property()
  shortDescription: string;

  @property({required: true})
  description: string;

  @property()
  specialist: string;

  @property()
  practiceAt: Date;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<CreateTeacherRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateTeacherRequestBody extends Entity {
  @property({jsonSchema: {minLength: 1}})
  name?: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone?: string;

  @property()
  imgUrl?: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.SHORT_ID}})
  shortId?: string;

  @property()
  university: string;

  @property()
  degree?: string;

  @property()
  shortDescription: string;

  @property()
  description?: string;

  @property()
  specialist: string;

  @property()
  practiceAt: Date;

  constructor(data?: Partial<UpdateTeacherRequestBody>) {
    super(data);
  }
}
