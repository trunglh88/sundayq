import {Entity, model, property} from '@loopback/repository';

export type Credentials = {
  email: string;
  password: string;
};

@model()
export class CredentialsRequestBody extends Entity {
  @property({required: true, jsonSchema: {format: 'email'}})
  email: string;

  @property({required: true})
  password: string;

  constructor(data?: Partial<CredentialsRequestBody>) {
    super(data);
  }
}
