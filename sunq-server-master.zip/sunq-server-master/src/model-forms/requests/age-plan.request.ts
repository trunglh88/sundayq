import {Entity, model, property} from '@loopback/repository';

@model()
export class AgePlanRequestBody extends Entity {

  @property()
  title: string;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  thumbnailUrl: string;

  constructor(data?: Partial<AgePlanRequestBody>) {
    super(data);
  }
}
