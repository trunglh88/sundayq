import {Entity, model, property} from '@loopback/repository';

@model()
export class ClassMemberRequestBody extends Entity{

  @property({required: true})
  classId: string;

  @property({required: true})
  memberId: string;

  constructor(data?: Partial<ClassMemberRequestBody>) {
    super(data);
  }
}
