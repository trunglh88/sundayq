import {model, property, Entity} from '@loopback/repository';
import {RegexForm} from '../../utils';

@model()
export class FeedbackRequestBody extends Entity {
  @property({jsonSchema: {minLength: 1}})
  name: string;

  @property({jsonSchema: {format: 'email'}})
  email: string;

  @property({jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  @property({required: true})
  message: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<FeedbackRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateFeedbackRequestBody extends Entity {
  @property({required: true})
  isReplied: boolean;

  @property()
  adminNote: string;

  constructor(data?: Partial<UpdateFeedbackRequestBody>) {
    super(data);
  }
}
