import {Entity, model, property} from '@loopback/repository';
import {RegexForm} from '../../utils';

@model()
export class OrderRequestBody extends Entity {

  @property({required: true, jsonSchema: {format: 'regex', pattern: RegexForm.PHONE_NUMBER_MOBILE_VN}})
  phone: string;

  constructor(data?: Partial<OrderRequestBody>) {
    super(data);
  }
}
