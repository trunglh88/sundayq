import {Entity, model, property} from '@loopback/repository';

@model()
export class TransactionPayOnlineRequestBody extends Entity {
  @property()
  locale: string;

  @property({required: true})
  merchandiseId: string;

  constructor(data?: Partial<TransactionPayOnlineRequestBody>) {
    super(data);
  }
}

@model()
export class TransferMoneyRequestBody extends Entity {
  @property({required: true})
  merchandiseId: string;

  @property()
  thumbnailUrl: string;

  constructor(data?: Partial<TransferMoneyRequestBody>) {
    super(data);
  }
}

@model()
export class VerifyTransactionRequestBody extends Entity {

  @property({required: true, default: false})
  isSuccess: boolean;

  constructor(data?: Partial<VerifyTransactionRequestBody>) {
    super(data);
  }
}
