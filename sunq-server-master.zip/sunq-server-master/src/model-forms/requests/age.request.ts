import {Entity, model, property} from '@loopback/repository';

@model()
export class AgeRequestBody extends Entity {
  @property({required: true})
  description: string;

  constructor(data?: Partial<AgeRequestBody>) {
    super(data);
  }
}
