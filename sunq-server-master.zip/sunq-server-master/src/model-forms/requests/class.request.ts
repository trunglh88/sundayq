import {Entity, model, property} from '@loopback/repository';

@model()
export class ClassRequestBody extends Entity {
  @property({required: true})
  description: string;

  constructor(data?: Partial<ClassRequestBody>) {
    super(data);
  }
}
