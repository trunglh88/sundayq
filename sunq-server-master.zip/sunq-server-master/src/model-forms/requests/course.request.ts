import {Entity, model, property} from '@loopback/repository';

@model()
export class CreateCoursePlanRequestBody extends Entity {
  @property()
  dayIndex: number;

  @property({required: true})
  title: string;

  @property()
  description: string;

  @property()
  time: string;

  @property()
  teacherId: string;

  @property()
  supporterId: string;

  constructor(data?: Partial<CreateCoursePlanRequestBody>) {
    super(data);
  }
}

@model()
export class CreateCourseRequestBody extends Entity {
  @property()
  viewIndex: number;

  @property()
  minTargetAge: number;

  @property()
  maxTargetAge: number;

  @property({required: true})
  courseType: string;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  @property.array(String)
  otherImgUrls: string[];

  @property.array(String)
  ownerIds: string[];

  @property.array(CreateCoursePlanRequestBody)
  coursePlans: CreateCoursePlanRequestBody[];

  constructor(data?: Partial<CreateCourseRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateCoursePlanRequestBody extends Entity {
  @property()
  id: string;

  @property()
  dayIndex: number;

  @property()
  title: string;

  @property()
  description: string;

  @property()
  time: string;

  @property()
  teacherId: string;

  @property()
  supporterId: string;

  constructor(data?: Partial<UpdateCoursePlanRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateCourseRequestBody extends Entity {
  @property()
  viewIndex: number;

  @property()
  minTargetAge: number;

  @property()
  maxTargetAge: number;

  @property()
  courseType: string;

  @property()
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  @property.array(String)
  otherImgUrls: string[];

  @property.array(String)
  ownerIds: string[];

  @property.array(UpdateCoursePlanRequestBody)
  coursePlans: UpdateCoursePlanRequestBody[];

  constructor(data?: Partial<CreateCourseRequestBody>) {
    super(data);
  }
}
