import {Entity, model, property} from '@loopback/repository';

@model()
export class ServiceRequestBody extends Entity {
  @property({required: true})
  name: string;

  @property({})
  description: string;

  @property()
  thumbnailUrl: string;

  @property.array(String)
  resources: string[];

  @property({required: true})
  price: number;

  @property({default: 0})
  discount: number;

  constructor(data?: Partial<ServiceRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateServiceRequestBody extends Entity {
  @property({required: false})
  name: string;

  @property({required: false})
  price: number;

  @property({})
  description: string;

  @property()
  thumbnailUrl: string;

  @property.array(String)
  resources: string[];

  @property()
  discount: number;

  constructor(data?: Partial<ServiceRequestBody>) {
    super(data);
  }
}
