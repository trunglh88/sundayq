import {Entity, model, property} from '@loopback/repository';

@model()
export class CategoryRequestBody extends Entity {
  @property({required: true})
  name: string;

  @property()
  description: string;

  constructor(data?: Partial<CategoryRequestBody>) {
    super(data);
  }
}
