import {Entity, model, property} from '@loopback/repository';
import {Answer} from '../../constants';

@model()
export class QuestionRequestBody extends Entity {
  @property()
  content: string;

  @property()
  a: string;

  @property()
  b: string;

  @property()
  c: string;

  @property()
  d: string;

  @property()
  answer: Answer;

  @property()
  interpretation: string;

  constructor(data?: Partial<QuestionRequestBody>) {
    super(data);
  }
}
