import {Entity, model, property} from '@loopback/repository';

@model()
export class EventRequestBody extends Entity {
  @property({default: 999999999})
  viewIndex: number;

  @property()
  startAt: Date;

  @property()
  finishAt: Date;

  @property({required: true})
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<EventRequestBody>) {
    super(data);
  }
}

@model()
export class UpdateEventRequestBody extends Entity {
  @property()
  viewIndex: number;

  @property()
  startAt: Date;

  @property()
  finishAt: Date;

  @property()
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<UpdateEventRequestBody>) {
    super(data);
  }
}
