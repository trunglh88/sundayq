import {Entity, model, property} from '@loopback/repository';

@model()
export class BaseProfileResponse extends Entity {
  @property()
  id: string;

  @property()
  imgUrl: string;

  @property()
  name: string;

  @property()
  email: string;

  @property()
  phone?: string;

  constructor(data?: Partial<BaseProfileResponse>) {
    super(data);
  }
}
