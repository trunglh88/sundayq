import {Entity, model, property} from '@loopback/repository';

@model()
export class RefeshTokenResponse extends Entity {
  @property()
  token: string;

  constructor(data?: Partial<RefeshTokenResponse>) {
    super(data);
  }
}
