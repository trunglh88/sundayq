import {Entity, model, property} from '@loopback/repository';

@model()
export class OrderResponse extends Entity {
  @property()
  id: string;

  @property()
  phone: string;

  @property()
  status: string;

  @property()
  kidId: string;

  constructor(data?: Partial<OrderResponse>) {
    super(data);
  }
}

@model()
export class OrdersResponse extends Entity {
  @property()
  orders: OrderResponse[];

  constructor(data?: Partial<OrdersResponse>) {
    super(data);
  }
}
