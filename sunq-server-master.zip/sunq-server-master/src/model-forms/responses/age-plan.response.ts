import {Entity, model, property} from '@loopback/repository';

@model()
export class AgePlanResponse extends Entity {
  @property()
  id: string;

  @property()
  title: string;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  thumbnail: string;

  @property()
  thumbnailUrl: string;

  @property()
  month: number;

  @property()
  ageId: string;
}

@model()
export class AgePlansResponse extends Entity {
  @property.array(AgePlanResponse)
  videos: AgePlanResponse[];
}
