import {Entity, model, property} from '@loopback/repository';

@model()
export class ServiceResponse extends Entity {
  @property()
  id: string;

  @property()
  name: string;

  @property()
  price: number;

  @property()
  discount: number;

  constructor(data?: Partial<ServiceResponse>) {
    super(data);
  }
}

@model()
export class ServicesResponse extends Entity {
  @property.array(ServiceResponse)
  services: ServiceResponse[];

  constructor(data?: Partial<ServicesResponse>) {
    super(data);
  }
}
