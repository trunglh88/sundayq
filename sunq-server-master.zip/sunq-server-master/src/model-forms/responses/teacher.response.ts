import {Entity, model, property} from '@loopback/repository';

@model()
export class TeacherInfoResponse extends Entity {
  @property()
  id: string;

  @property()
  name: string;

  @property()
  imgUrl: string;

  @property()
  university: string;

  @property()
  degree: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  specialist: string;

  @property()
  practiceAt: Date;

  constructor(data?: Partial<TeacherInfoResponse>) {
    super(data);
  }
}

@model()
export class TeacherInfoInCoursePlanResponse extends Entity {
  @property()
  id: string;

  @property()
  name: string;

  @property()
  imgUrl: string;

  @property()
  university: string;

  @property()
  degree: string;

  @property()
  shortDescription: string;

  @property()
  specialist: string;

  @property()
  practiceAt: Date;

  constructor(data?: Partial<TeacherInfoInCoursePlanResponse>) {
    super(data);
  }
}
