import {Entity, model, property} from '@loopback/repository';

@model()
export class AgeResponse extends Entity {
  @property()
  id: string;

  @property()
  description: string;

  @property()
  serviceId: string;

  constructor(data?: Partial<AgeResponse>) {
    super(data);
  }
}

@model()
export class AgesResponse extends Entity {

  @property.array(AgeResponse)
  ages: AgeResponse[];

  constructor(data?: Partial<AgesResponse>) {
    super(data);
  }
}
