import {Entity, model, property} from '@loopback/repository';

@model()
export class ResourceResponse extends Entity {
  @property()
  id: string;

  @property()
  title: string;

  constructor(data?: Partial<ResourceResponse>) {
    super(data);
  }
}
