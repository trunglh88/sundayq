import {Entity, model, property} from '@loopback/repository';

@model()
export class LoginResponse extends Entity {
  @property()
  token: string;

  @property()
  refreshToken: string;

  constructor(data?: Partial<LoginResponse>) {
    super(data);
  }
}
