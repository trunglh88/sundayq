import {Entity, model, property} from '@loopback/repository';

@model()
export class ClassResponse extends Entity {
  @property()
  id: string;

  @property()
  description: string;

  @property()
  serviceId: string;

  constructor(data?: Partial<ClassResponse>) {
    super(data);
  }
}

@model()
export class ClassesResponse extends Entity {
  @property.array(ClassResponse)
  classes: ClassResponse[];

  constructor(data?: Partial<ClassesResponse>) {
    super(data);
  }
}
