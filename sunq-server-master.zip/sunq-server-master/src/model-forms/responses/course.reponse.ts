import {Entity, model, property} from '@loopback/repository';
import {Constants} from '../../constants';
import {TeacherInfoInCoursePlanResponse} from './teacher.response';

@model()
export class CourseOwnerInfoResponse extends Entity {
  @property()
  teacher: TeacherInfoInCoursePlanResponse;

  constructor(data?: Partial<CourseOwnerInfoResponse>) {
    super(data);
  }
}

@model()
export class CoursePlanInfoResponse extends Entity {
  @property()
  id: string;

  @property()
  dayIndex: number;

  @property()
  title: string;

  @property()
  description: string;

  @property()
  time: string;

  @property()
  teacher: TeacherInfoInCoursePlanResponse;

  @property()
  supporter: TeacherInfoInCoursePlanResponse;

  constructor(data?: Partial<CoursePlanInfoResponse>) {
    super(data);
  }
}

@model()
export class CourseInfoResponse extends Entity {
  @property()
  id: string;

  @property()
  viewIndex: number;

  @property()
  minTargetAge: number;

  @property()
  maxTargetAge: number;

  @property()
  courseType: string;

  @property()
  title: string;

  @property()
  shortDescription: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  @property.array(String)
  otherImgUrls: string[];

  @property.array(CourseOwnerInfoResponse)
  owners: CourseOwnerInfoResponse[];

  @property.array(CoursePlanInfoResponse)
  coursePlans: CoursePlanInfoResponse[];

  constructor(data?: Partial<CourseInfoResponse>) {
    super(data);
  }
}
