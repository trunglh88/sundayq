import {Entity, model, property} from '@loopback/repository';
import {Answer} from '../../constants';

@model()
export class QuestionResponse extends Entity {
  @property()
  content: string;

  @property()
  a: string;

  @property()
  b: string;

  @property()
  c: string;

  @property()
  d: string;

  @property()
  answer: Answer;

  @property()
  interpretation: string;

  constructor(data?: Partial<QuestionResponse>) {
    super(data);
  }
}

@model()
export class QuestionsResponse extends Entity {
  @property.array(QuestionResponse)
  questions: QuestionResponse[];

  constructor(data?: Partial<QuestionsResponse>) {
    super(data);
  }
}
