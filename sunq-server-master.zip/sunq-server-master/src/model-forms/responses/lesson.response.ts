import {Entity, model, property} from '@loopback/repository';

@model()
export class LessonResponse extends Entity {
  @property({id: true})
  id: string;

  // @property({require: true, index: {unique: true, name: 'uniqueName', key: 1}})
  @property()
  title: string;

  @property()
  ages: string;

  @property()
  month: number;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  isSampleLesson: boolean;

  @property()
  ageId: string;

  @property()
  kitId: string;

  constructor(data?: Partial<LessonResponse>) {
    super(data);
  }
}

@model()
export class LessonsResponse extends Entity {

  @property.array(LessonResponse)
  lessons: LessonResponse[];

  constructor(data?: Partial<LessonsResponse>) {
    super(data);
  }
}
