import {Entity, model, property} from '@loopback/repository';

@model()
export class KitResponse extends Entity {
  @property()
  title: string;

  @property()
  description: string;

  @property()
  price: number;

  @property()
  shortDescription: string;

  @property()
  thumbnails: string[];

  @property.array(String)
  thumbnailUrls: string[];

  constructor(data?: Partial<KitResponse>) {
    super(data);
  }
}

@model()
export class KitsResponse extends Entity {
  @property.array(KitsResponse)
  kits: KitResponse[];

  constructor(data?: Partial<KitsResponse>) {
    super(data);
  }
}
