import {Entity, model, Model, property} from '@loopback/repository';
import {Address, Contact, TicketPrice} from '../../models';

@model()
export class CourseOverviewResponse extends Model {
  @property()
  id: string;

  @property()
  viewIndex: number;

  @property()
  title: string;

  @property()
  description: string;

  @property()
  descriptionImgUrl: string;

  constructor(data?: Partial<CourseOverviewResponse>) {
    super(data);
  }
}

@model()
export class SystemInfoResponse extends Entity {
  @property()
  timeOpen: string;

  @property()
  address: Address;

  @property()
  contact: Contact;

  @property.array(TicketPrice)
  ticketPrices: TicketPrice[];

  @property.array(CourseOverviewResponse)
  topCourses: CourseOverviewResponse[];

  constructor(data?: Partial<SystemInfoResponse>) {
    super(data);
  }
}
