import {Entity, model, property} from '@loopback/repository';

@model()
export class EmptyResponse extends Entity {
  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}

@model()
export class UrlResponse extends Entity {
  @property()
  urls: string;

  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}

@model()
export class UrlsResponse extends Entity {
  @property.array(String)
  urls: string[];

  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}

@model()
export class ResourseResponse extends Entity {
  @property()
  name: string;

  @property()
  description: string;

  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}

@model()
export class VideoResponse extends Entity {
  @property()
  title: string;

  @property()
  description: string;

  @property()
  shortDescription: string;

  @property()
  fileName: string;

  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}

@model()
export class VideosResponse extends Entity {
  @property.array(VideoResponse)
  videos: VideoResponse[];

  constructor(data?: Partial<EmptyResponse>) {
    super(data);
  }
}
