import {AUTHENTICATION_STRATEGY_NOT_FOUND, USER_PROFILE_NOT_FOUND} from '@loopback/authentication';
import {AnyObject, model, Model, property} from '@loopback/repository';

const MULTER_ERROR_CODE: AnyObject = {
  LIMIT_PART_COUNT: 'Part count too large',
  LIMIT_FILE_SIZE: 'File size too large',
  LIMIT_FILE_COUNT: 'File count too large',
  LIMIT_FIELD_KEY: 'Field key too large',
  LIMIT_FIELD_VALUE: 'Field value too large',
  LIMIT_FIELD_COUNT: 'Field count too large',
  LIMIT_UNEXPECTED_FILE: 'Unexpected file',
};

const RESPONSE_CODES: {[process: string]: string} = {
  200: 'Success',
  400: 'BadRequest',
  401: 'Unauthorized',
  402: 'PaymentRequired',
  403: 'Forbidden',
  404: 'NotFound',
  405: 'MethodNotAllowed',
  406: 'NotAcceptable',
  407: 'ProxyAuthenticationRequired',
  408: 'RequestTimeout',
  409: 'Conflict',
  410: 'Gone',
  411: 'LengthRequired',
  412: 'PreconditionFailed',
  413: 'PayloadTooLarge',
  414: 'URITooLong',
  415: 'UnsupportedMediaType',
  416: 'RangeNotSatisfiable',
  417: 'ExpectationFailed',
  418: 'ImATeapot',
  421: 'MisdirectedRequest',
  422: 'UnprocessableEntity',
  423: 'Locked',
  424: 'FailedDependency',
  425: 'UnorderedCollection',
  426: 'UpgradeRequired',
  428: 'PreconditionRequired',
  429: 'TooManyRequests',
  431: 'RequestHeaderFieldsTooLarge',
  451: 'UnavailableForLegalReasons',
  500: 'InternalServerError',
  501: 'NotImplemented',
  502: 'BadGateway',
  503: 'ServiceUnavailable',
  504: 'GatewayTimeout',
  505: 'HTTPVersionNotSupported',
  506: 'VariantAlsoNegotiates',
  507: 'InsufficientStorage',
  508: 'LoopDetected',
  509: 'BandwidthLimitExceeded',
  510: 'NotExtended',
  511: 'NetworkAuthenticationRequired',
};

@model()
export class AppResponse<T extends object> extends Model {
  @property()
  code: number;

  @property()
  message?: string;

  @property()
  page?: number;

  @property()
  total?: number;

  @property()
  data?: T;

  constructor(data?: Partial<AppResponse<T>>) {
    super(data);
    this.code = data?.code ?? 200;
    this.message = data?.message ?? '';
    this.data = data?.data ?? undefined;

    if (this.message === '') {
      this.message = RESPONSE_CODES[this.code] || (this.code < 200 ? 'RequestError' : 'ServerError');
    }
  }

  static fromError(error: AnyObject) {
    if (error instanceof AppResponse) return error;
    if (error.code === AUTHENTICATION_STRATEGY_NOT_FOUND || error.code === USER_PROFILE_NOT_FOUND) {
      Object.assign(error, {statusCode: 401});
    }
    if (MULTER_ERROR_CODE[`${error.code}`]) {
      Object.assign(error, {statusCode: 422, message: MULTER_ERROR_CODE[`${error?.code}`]});
    }
    if (error?.statusCode && typeof error.statusCode === 'number') {
      let message = (error.details && error.details[0] && error.details[0].message) || error.message;
      if (error.details && error.details[0] && error.details[0].path)
        message = error.details[0].path.replace(/(\/|.)/, '') + ' ' + message;
      if (error.type) message = error.type + ': ' + message;
      return new AppResponse({code: error.statusCode, message: message});
    }
    return undefined;
  }
}
