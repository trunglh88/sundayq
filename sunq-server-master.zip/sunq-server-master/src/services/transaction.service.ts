import dateFormat from 'dateformat';
import {Request} from 'express-serve-static-core';
import sha256 from 'sha256';
import {VnPayConfig} from '../constants';
import {CreatePaymentBody} from '../model-transactions/transaction';

export namespace TransactionService {
  export const createPaymentUrl = (body: CreatePaymentBody): string => {
    const tmnCode = VnPayConfig.VNP_TMNCODE;
    const secretKey = VnPayConfig.VNP_HASHSECRET;
    let vnpUrl: string = VnPayConfig.VNP_URL;
    const returnUrl = VnPayConfig.VNP_RETURNURL;

    const date = new Date();

    const createDate = dateFormat(date, 'yyyymmddHHmmss');
    const bankCode = "";
    let locale = body.locale;
    if (locale === null || locale === '') {
      locale = 'vn';
    }
    const currCode = 'VND';
    let vnp_Params: {[key: string]: any} = {};
    vnp_Params['vnp_Version'] = '2';
    vnp_Params['vnp_Command'] = 'pay';
    vnp_Params['vnp_TmnCode'] = tmnCode;
    // vnp_Params['vnp_Merchant'] = ''
    vnp_Params['vnp_Locale'] = locale;
    vnp_Params['vnp_CurrCode'] = currCode;
    vnp_Params['vnp_TxnRef'] = body.txnRef;
    vnp_Params['vnp_OrderInfo'] = body.orderInfo;
    vnp_Params['vnp_OrderType'] = 260001;
    vnp_Params['vnp_Amount'] = body.amount * 100;
    vnp_Params['vnp_ReturnUrl'] = returnUrl;
    vnp_Params['vnp_IpAddr'] = body.ipAddr;
    vnp_Params['vnp_CreateDate'] = createDate;
    if (bankCode !== null && bankCode !== '') {
      vnp_Params['vnp_BankCode'] = bankCode;
    }

    vnp_Params = sortObject(vnp_Params);

    var querystring = require('qs');
    var signData = secretKey + querystring.stringify(vnp_Params, {encode: false});

    var secureHash = sha256(signData);

    vnp_Params['vnp_SecureHashType'] = 'SHA256';
    vnp_Params['vnp_SecureHash'] = secureHash;
    vnpUrl += '?' + querystring.stringify(vnp_Params, {encode: true});

    return vnpUrl;
  }

  export const isPaymentSuccess = (req: Request) => {
    let vnp_Params = req.query;

    var secureHash = vnp_Params['vnp_SecureHash'];

    delete vnp_Params['vnp_SecureHash'];
    delete vnp_Params['vnp_SecureHashType'];

    vnp_Params = sortObject(vnp_Params);

    var tmnCode = VnPayConfig.VNP_TMNCODE;
    var secretKey = VnPayConfig.VNP_HASHSECRET;

    var querystring = require('qs');
    var signData = secretKey + querystring.stringify(vnp_Params, {encode: false});

    var checkSum = sha256(signData);

    return secureHash === checkSum;
  }

  const sortObject = (o: any) => {
    var sorted: {[key: string]: any} = {},
      key,
      a = [];

    for (key in o) {
      if (o.hasOwnProperty(key)) {
        a.push(key);
      }
    }

    a.sort();

    for (key = 0; key < a.length; key++) {
      sorted[a[key]] = o[a[key]];
    }
    return sorted;
  }

}
