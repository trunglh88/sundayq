import {TokenService} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {AnyObject, repository} from '@loopback/repository';
import {HttpErrors} from '@loopback/rest';
import {UserProfile} from '@loopback/security';
import {RefreshtokenServiceBindings} from '../keys';
import {RefeshTokenRepository} from '../repositories';

export interface RefreshtokenService extends TokenService {
  verifyToken(token: string, userProfile?: UserProfile): Promise<UserProfile>;

  revokeToken(token: string, userProfile?: UserProfile): Promise<boolean>;
}

export class MyRefreshtokenService implements RefreshtokenService {
  constructor(
    @repository(RefeshTokenRepository)
    public refeshTokenRepository: RefeshTokenRepository,
    @inject(RefreshtokenServiceBindings.REFRESHTOKEN_ETERNAL_ALLOWED, {
      optional: true,
    })
    private refreshtokenEternalAllowed: boolean = false,
    @inject(RefreshtokenServiceBindings.REFRESHTOKEN_EXPIRES_IN, {
      optional: true,
    })
    private refreshtokenExpiresIn: number = 60 * 60 * 24,
  ) {}

  async generateToken(userProfile: UserProfile): Promise<string> {
    // TODO(derdeka) objectId as refreshtoken is a bad idea
    const userRefreshtoken = await this.refeshTokenRepository.create({
      ttl: this.refreshtokenExpiresIn,
      userId: userProfile.id,
    });
    return userRefreshtoken.id;
  }

  async verifyToken(refreshtoken: string, userProfile?: UserProfile): Promise<UserProfile> {
    if (!userProfile || !userProfile.id) {
      throw new HttpErrors.Unauthorized('Invalid refreshToken');
    }
    const refeshToken = await this.refeshTokenRepository.findById(refreshtoken, {
      where: {userId: userProfile.id},
    } as AnyObject);
    if (!refeshToken) {
      throw new HttpErrors.Unauthorized('Invalid refreshToken');
    }
    const {createAt, ttl} = refeshToken;
    const isEternalToken = ttl === -1;
    const elapsedSeconds = (Date.now() - createAt.getTime()) / 1000;
    const isValid = isEternalToken ? this.refreshtokenEternalAllowed : elapsedSeconds < ttl;
    if (!isValid) {
      throw new HttpErrors.Unauthorized('Invalid refreshToken');
    }
    return userProfile;
  }

  async revokeToken(refreshtoken: string, userProfile: UserProfile): Promise<boolean> {
    try {
      await this.refeshTokenRepository.deleteById(refreshtoken, {
        where: {userId: userProfile.id},
      });
      return true;
    } catch (e) {
      return false;
    }
  }
}
