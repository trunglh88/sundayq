export namespace MessageService {
  export const getMessage = (messageModel: MessageModel) => {
    return messageModel.VN;
  };
}

export type MessageModel = {
  KEY: string;
  VN: string;
  EN: string;
};

export namespace Message {
  export const ACCOUNT_NOT_FOUND: MessageModel = {
    KEY: 'account_not_found',
    VN: 'Tài khoản không tồn tại.',
    EN: 'Account not found.',
  };

  export const ACCOUNT_OR_PASSWORD_NOT_FOUND: MessageModel = {
    KEY: 'account_or_password_not_found',
    VN: 'Tài khoản hoặc mật khẩu không tồn tại.',
    EN: 'Account or password not found.',
  };

  export const AGE_NOT_FOUND: MessageModel = {
    KEY: 'age_not_found',
    VN: 'Lứa tuổi không tồn tại.',
    EN: 'Age not found.',
  };

  export const CLASS_NOT_FOUND: MessageModel = {
    KEY: 'class_not_found',
    VN: 'Lớp học không tồn tại.',
    EN: 'Class not found.',
  };

  export const CATEGORY_NOT_FOUND: MessageModel = {
    KEY: 'category_not_found',
    VN: 'Danh mục không tồn tại.',
    EN: 'Category not found.',
  };

  export const RESOURCE_NOT_FOUND: MessageModel = {
    KEY: 'resource_not_found',
    VN: 'Nguồn không tồn tại.',
    EN: 'Resource not found.',
  };

  export const KID_NOT_FOUND: MessageModel = {
    KEY: 'kit_not_found',
    VN: 'Bộ kit không tồn tại.',
    EN: 'Kit not found.',
  };

  export const QUESTION_NOT_FOUND: MessageModel = {
    KEY: 'question_not_found',
    VN: 'Câu hỏi không tồn tại.',
    EN: 'Question not found.',
  };

  export const LESSON_NOT_FOUND: MessageModel = {
    KEY: 'lesson_not_found',
    VN: 'Bài học không tồn tại.',
    EN: 'Lesson not found.',
  };

  export const SERVICE_NOT_FOUND: MessageModel = {
    KEY: 'service_not_found',
    VN: 'Dịch vụ không tồn tại.',
    EN: 'Service not found.',
  };

  export const NAME_IS_TAKEN: MessageModel = {
    KEY: 'name_is_taken',
    VN: 'Tên đã tồn tại.',
    EN: 'Name is taken.',
  };

  export const VERIFY_ACCOUNT: MessageModel = {
    KEY: 'verify_account',
    VN: 'Vui lòng mở mail để xác thực tài khoản.',
    EN: 'Please open mail to verify account.',
  };

  export const INACTIVE_ACCOUNT: MessageModel = {
    KEY: 'inactive_account',
    VN: 'Tài khoản không hoạt động.',
    EN: 'Inactive account.',
  };

  export const NEED_TO_REGISTER_ACCOUNT: MessageModel = {
    KEY: 'need_to_register_account',
    VN: 'Cần đăng ký tài khoản.',
    EN: 'Need to register account.',
  };

  export const CLASS_HAS_NOT_YET_STARTED: MessageModel = {
    KEY: 'class_has_not_yet_started',
    VN: 'Lớp học chưa được mở.',
    EN: 'Class has not yet started.',
  };

  export const THE_LESSON_OF_MONTH_HAS_BEEN_CLOSED: MessageModel = {
    KEY: 'the_lesson_of_the_month_has_been_closed',
    VN: 'Bài học của tháng đã bị đóng.',
    EN: 'The lesson of month has been closed.',
  };
}
