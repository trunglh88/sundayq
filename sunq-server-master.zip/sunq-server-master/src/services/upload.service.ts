import path = require('path');
import multer = require('multer');
import {HttpErrors} from '@loopback/rest';
import {Request, Response} from 'express-serve-static-core';
import {FileFilterCallback} from 'multer';
import {promisify} from 'util';
import {Constants} from '../constants';
import {FileService} from './file.service';

const IMAGE_TYPE = ['.png', '.jpg', '.jpeg', '.bmp'];
const VIDEO_TYPE = ['.webm', '.mpeg', '.mpe', '.mpv', '.ogg', '.mp4', '.m4v', '.avi', '.wmv', '.mov', '.flv', '.swf'];
const AUDIO_TYPE = ['.m4a', '.flac', '.mp3', '.wav', '.wma', '.aac'];
const DOCUMENT_TYPE = ['.pdf', '.docx', '.doc'];
const POWERPOINT_TYPE = ['.pptx'];

const MAX_FILE_SIZE = 10 * 1024 * 1024; //1000MB
const MAX_AUDIO_FILE_SIZE = 10 * 1024 * 1024; //10MB
const MAX_VIDEO_FILE_SIZE = 1000 * 1024 * 1024; //10MB
const MAX_DOCUMENT_FILE_SIZE = 10 * 1024 * 1024; //10MB
const MAX_POWERPOINT_FILE_SIZE = 10 * 1024 * 1024; //10MB

export const TEMP_DIR = path.join(__dirname, '../../private/temp');

export type FileFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => void;
export type UploadedInfo = {filename: string; originalname: string; filepath: string};

FileService.makeDir(TEMP_DIR);

export namespace UploadService {
  const sTempStorage = multer.diskStorage({
    destination: TEMP_DIR,
    filename: (req, file, cb) => cb(null, FileService.randomFileName(path.extname(file.originalname))),
  });

  const getFileSetting = (filetype: Constants.FILE_TYPE) => {
    let fileFilter = UploadService.imageFilter;
    let fileSize = MAX_FILE_SIZE;
    if (filetype === Constants.FILE_TYPE.AUDIO) {
      fileFilter = UploadService.audioFilter;
      fileSize = MAX_AUDIO_FILE_SIZE;
    } else if (filetype === Constants.FILE_TYPE.VIDEO) {
      fileFilter = UploadService.videoFilter;
      fileSize = MAX_VIDEO_FILE_SIZE;
    } else if (filetype === Constants.FILE_TYPE.DOCUMENT) {
      fileFilter = UploadService.documentFilter;
      fileSize = MAX_DOCUMENT_FILE_SIZE;
    } else if (filetype === Constants.FILE_TYPE.POWERPOINT) {
      fileFilter = UploadService.powerpointFilter;
      fileSize = MAX_POWERPOINT_FILE_SIZE;
    }
    return {
      fileFilter: fileFilter,
      fileSize: fileSize,
    };
  };

  export const checkType = (fileTag: string, filetype: Constants.FILE_TYPE): boolean => {
    if (filetype === Constants.FILE_TYPE.AUDIO) {
      return AUDIO_TYPE.includes(fileTag.toLocaleLowerCase());
    } else if (filetype === Constants.FILE_TYPE.IMAGE) {
      return IMAGE_TYPE.includes(fileTag.toLocaleLowerCase());
    } else if (filetype === Constants.FILE_TYPE.VIDEO) {
      return VIDEO_TYPE.includes(fileTag.toLocaleLowerCase());
    } else if (filetype === Constants.FILE_TYPE.DOCUMENT) {
      return DOCUMENT_TYPE.includes(fileTag.toLocaleLowerCase());
    } else if (filetype === Constants.FILE_TYPE.POWERPOINT) {
      return POWERPOINT_TYPE.includes(fileTag.toLocaleLowerCase());
    }
    return false;
  };

  export const uploadFile = async (
    req: Request,
    res: Response,
    fieldName: string,
    filetype: Constants.FILE_TYPE,
  ): Promise<UploadedInfo | undefined> => {
    await new Promise((resolve, reject) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const next = (err: any) => {
        if (err) reject(err);
        resolve();
      };

      const {fileFilter, fileSize} = getFileSetting(filetype);
      const upload = promisify(
        multer({
          storage: sTempStorage,
          fileFilter: fileFilter,
          limits: {fileSize: fileSize},
        }).single(fieldName),
      );

      upload(req, res, next)
        .then((res) => {
          console.log('aaaaaaaaaaaaaaaaaaaaaa');
        })
        .catch(next);
    });

    if (!req.file) return undefined;
    console.log('fieldName   bcbcbcb-------    ', fieldName);
    return {
      filename: req.file.filename,
      filepath: path.join(TEMP_DIR, req.file.filename),
      originalname: req.file.originalname,
    };
  };

  export const uploadFiles = async (
    req: Request,
    res: Response,
    fieldName: string,
    filetype: Constants.FILE_TYPE,
  ): Promise<UploadedInfo[] | undefined> => {
    await new Promise((resolve, reject) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const next = (err: any) => {
        if (err) reject(err);
        resolve();
      };

      const {fileFilter, fileSize} = getFileSetting(filetype);
      const upload = promisify(
        multer({
          storage: sTempStorage,
          fileFilter: fileFilter,
          limits: {fileSize: fileSize},
        }).array(fieldName),
      );

      upload(req, res, next)
        .then()
        .catch(next);
    });

    if (!req.files) return undefined;
    return (req.files as Express.Multer.File[]).map((file) => {
      return {
        filename: file.filename,
        filepath: path.join(TEMP_DIR, file.filename),
        originalname: file.originalname,
      };
    });
  };

  export const imageFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => {
    const err = checkMineType(file, 'image') && checkExtname(file, IMAGE_TYPE);
    // (file.size <= 4 * 1024 * 1024 * 1024 ? null : new HttpErrors.UnprocessableEntity('File too large'));
    if (err) callback(new HttpErrors.UnsupportedMediaType('File must be image type.'));
    else callback(null, true);
  };

  export const videoFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => {
    const err = checkMineType(file, 'video') && checkExtname(file, VIDEO_TYPE);
    if (err) callback(new HttpErrors.UnsupportedMediaType('File must be video type.'));
    else callback(null, true);
  };

  export const audioFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => {
    const err = checkMineType(file, 'audio') && checkExtname(file, AUDIO_TYPE);
    if (err) callback(new HttpErrors.UnsupportedMediaType('File must be audio type.'));
    else callback(null, true);
  };

  export const documentFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => {
    const err = checkMineType(file, 'document') && checkExtname(file, DOCUMENT_TYPE);
    if (err) callback(new HttpErrors.UnsupportedMediaType('File must be document type.'));
    else callback(null, true);
  };

  export const powerpointFilter = (req: Express.Request, file: Express.Multer.File, callback: FileFilterCallback) => {
    const err = checkMineType(file, 'powerpoint') && checkExtname(file, POWERPOINT_TYPE);
    if (err) callback(new HttpErrors.UnsupportedMediaType('File must be powerpoint type.'));
    else callback(null, true);
  };

  const checkMineType = (file: Express.Multer.File, type: string) => {
    return file.mimetype && file.mimetype.toLowerCase().startsWith(type);
  };

  const checkExtname = (file: Express.Multer.File, acceptTypes: string[]) => {
    return acceptTypes.includes(file.originalname.toLowerCase());
  };
}
