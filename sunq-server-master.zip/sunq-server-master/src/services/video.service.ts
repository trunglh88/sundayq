import {exec, spawn} from 'child_process';
import {FileService} from './file.service';
import fs = require('fs');
import path = require('path');
// const FFMPEG_PATH = 'C:\\Users\\bao.nt\\Downloads\\ffmpeg\\bin\\ffmpeg';

const FFMPEG_PATH = 'ffmpeg';

export namespace VideoProcessing {
  export const resizeVideo = async (
    src: string,
    originalVideo: string,
    fileNameIgnoreTag: string,
    quality: number,
  ): Promise<string | undefined> =>
    new Promise((resolve, reject) => {
      fileNameIgnoreTag = `${fileNameIgnoreTag}_${quality}`;
      const des: string = path.join(originalVideo, fileNameIgnoreTag);
      if (!fs.existsSync(des)) fs.mkdirSync(des, {recursive: true});
      const ffmpeg = spawn(FFMPEG_PATH, [
        '-i',
        `${src}`,
        '-codec:v',
        'libx264',
        '-profile:v',
        'main',
        '-preset',
        'slow',
        '-b:v',
        '400k',
        '-maxrate',
        '400k',
        '-bufsize',
        '800k',
        '-vf',
        `scale=-2:${quality}`,
        '-threads',
        '0',
        '-b:a',
        '128k',
        `${des}/${fileNameIgnoreTag}.mp4`,
      ]);
      console.log(new Date());
      ffmpeg.stderr.on('data', (data) => {
        console.log(`${data}`);
      });
      ffmpeg.on('close', async (code) => {
        console.log(new Date());
        await splitVideo(`${des}/${fileNameIgnoreTag}.mp4`, des, fileNameIgnoreTag);
        resolve(`${des}/${fileNameIgnoreTag}.mp4`);
      });
    });

  export const splitVideo = (src: string, des: string, fileNameIgnoreTag: string): Promise<void> =>
    new Promise((resolve, reject) => {
      const ls = exec(
        `${FFMPEG_PATH} -i ${src} -profile:v baseline -level 3.0 -s 640x360 -start_number 0 -hls_time 10 -hls_list_size 0 -f hls ${des}/${fileNameIgnoreTag}.m3u8`,
        function (error, stdout, stderr) {
          if (error) {
            reject(error);
            return;
            //   console.log(error.stack);
            //   console.log('Error code: ' + error.code);
            //   console.log('Signal received: ' + error.signal);
          }
          console.log('Child Process STDOUT: ' + stdout);
          console.log('Child Process STDERR: ' + stderr);
          resolve();
        },
      );

      ls.on('exit', function (code) {
        console.log('Child process exited with exit code ' + code);
      });
    });

  export const generateThumbnai = (src: string, fileNameIgnoreTag: string): Promise<void> =>
    new Promise((resolve, reject) => {
      const ls = exec(
        `${FFMPEG_PATH} -i ${src} -ss 00:00:01.000 -vframes 1 ${FileService.IMAGE_DIR}/${fileNameIgnoreTag}.png`,
        function(error, stdout, stderr) {
          if (error) {
            reject(error);
            return;
            //   console.log(error.stack);
            //   console.log('Error code: ' + error.code);
            //   console.log('Signal received: ' + error.signal);
          }
          console.log('Child Process STDOUT: ' + stdout);
          console.log('Child Process STDERR: ' + stderr);
          resolve();
        },
      );

      ls.on('exit', function(code) {
        console.log('Child process exited with exit code ' + code);
      });
    });
}
