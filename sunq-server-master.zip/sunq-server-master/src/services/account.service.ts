import {UserService} from '@loopback/authentication';
import {inject} from '@loopback/context';
import {repository} from '@loopback/repository';
import {HttpErrors} from '@loopback/rest';
import {securityId, UserProfile} from '@loopback/security';
import {Constants} from '../constants';
import {PasswordHasherBindings} from '../keys';
import {Credentials} from '../model-forms';
import {Account} from '../models';
import {AccountRepository} from '../repositories';
import {PasswordHasher} from '../utils';
import {Message, MessageService} from './message.service';

export class AccountService implements UserService<Account, Credentials> {
  constructor(
    @repository(AccountRepository) public accountRepository: AccountRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
  ) {}

  async verifyCredentials(credentials: Credentials): Promise<Account> {
    const {email, password} = credentials;
    // const invalidCredentialsError = 'Invalid username or password.';
    const invalidCredentialsError = MessageService.getMessage(Message.ACCOUNT_OR_PASSWORD_NOT_FOUND);

    if (!email) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    const foundAccount = await this.accountRepository.findOne({
      where: {email},
    });
    if (!foundAccount) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    if (foundAccount.state === Constants.ACCOUNT_STATE.PENDING) {
      // throw new HttpErrors.PaymentRequired('Please contact to activate');
      throw new HttpErrors.PaymentRequired(MessageService.getMessage(Message.VERIFY_ACCOUNT));
    }
    if (foundAccount.state === Constants.ACCOUNT_STATE.INACTIVE) {
      // throw new HttpErrors.Forbidden('Your account is inactive');
      throw new HttpErrors.Forbidden(MessageService.getMessage(Message.INACTIVE_ACCOUNT));
    }
    if (foundAccount.state !== Constants.ACCOUNT_STATE.ACTIVE) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }

    const passwordMatched = await this.passwordHasher.comparePassword(password, foundAccount.password);

    if (!passwordMatched) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }

    return foundAccount;
  }

  convertToUserProfile(account: Account): UserProfile {
    return {
      [securityId]: account.id,
      id: account.id,
      uType: account.accountType,
    };
  }
}
