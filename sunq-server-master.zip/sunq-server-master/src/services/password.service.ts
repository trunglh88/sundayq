export namespace Password {
  export const createAutoPassword = (): string => {
    let password = '';
    for (let i in Array.from({length: 8}, (v, k) => k + 1)) {
      const random = Math.floor(Math.random() * 10) % 3;
      if (random == 0) {
        password += Math.floor(Math.random() * 10);
      } else if (random == 1) {
        password += String.fromCharCode((Math.floor(Math.random() * 1000) % 26) + 65);
      } else {
        password += String.fromCharCode((Math.floor(Math.random() * 1000) % 26) + 97);
      }
    }
    return password;
  };

  export const test = () => {
    console.log(createAutoPassword());
  };
}
