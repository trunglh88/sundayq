const cryptojs = require('crypto-js');
const crypto = require('crypto');
export namespace VATocken {
  export const generateToken = (email: string) => {
    const key = new Date().getMilliseconds().toString();
    const encryptMess = cryptojs.AES.encrypt(email, key).toString();

    const hash = crypto
      .createHash('sha256')
      .update(`${email}-${encryptMess}-${key}`)
      .digest('base64');
    return `${hash}-${encryptMess}-${key}`;
  };

  export const verifyToken = (token: string): boolean => {
    const [hash, encryptMess, key, ...args] = token.split('-');

    if (!hash || !encryptMess || !key || args.length > 0) {
      return false;
    }

    const email = cryptojs.AES.decrypt(encryptMess, key).toString(cryptojs.enc.Utf8);
    const isMap =
      hash ===
      crypto
        .createHash('sha256')
        .update(`${email}-${encryptMess}-${key}`)
        .digest('base64');

    // console.log(message_decode);
    return isMap;
  };

  export const getEmail = (token: string): string => {
    const [hash, encryptMess, key, ...args] = token.split('-');

    const email = cryptojs.AES.decrypt(encryptMess, key).toString(cryptojs.enc.Utf8);
    return email || '';
  };

  export const test = () => {
    console.log(verifyToken("a-b-c-d"));
  };
}
