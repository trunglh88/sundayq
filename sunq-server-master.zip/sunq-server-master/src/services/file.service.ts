import fs = require('fs');
import path = require('path');
import crypto = require('crypto');
import {VideoProcessing} from './video.service';

export namespace FileService {
  export const ROOT_DIR = path.join(__dirname, '../../private');
  export const IMAGE_DIR = path.join(__dirname, '../../private/image');
  export const VIDEO_DIR = path.join(__dirname, '../../private/video');
  export const AUDIO_DIR = path.join(__dirname, '../../private/audio');
  export const DOCUMENT_DIR = path.join(__dirname, '../../private/document');

  export const isExists = function(dirPath: string, filename: string) {
    const file = filename ? path.join(dirPath, filename) : dirPath;
    return fs.existsSync(file) && file;
  };

  export const getWriteStream = function(dirPath: string, filename?: string): fs.WriteStream | undefined {
    const file = filename ? path.join(dirPath, filename) : dirPath;
    return fs.existsSync(file) ? fs.createWriteStream(file) : undefined;
  };

  export const getReadStream = function(dirPath: string, filename?: string): fs.ReadStream | undefined {
    const file = filename ? path.join(dirPath, filename) : dirPath;
    return fs.existsSync(file) ? fs.createReadStream(file) : undefined;
  };

  export const readDir = function(dirPath: string): string[] {
    return fs.existsSync(dirPath) ? fs.readdirSync(dirPath) : [];
  };

  export const getFileName = function(filePath: string): string {
    return path.basename(filePath);
  };

  export const moveFile = function(src: string, des: string, filename: string): string {
    if (!fs.existsSync(des)) fs.mkdirSync(des, {recursive: true});
    if (fs.existsSync(src)) fs.renameSync(src, path.join(des, filename));
    return path.join(des, filename);
  };

  export const removeFile = function(src: string) {
    if (fs.existsSync(src)) fs.unlinkSync(src);
  };

  export const removeFolder = function(dir: string) {
    if (fs.existsSync(dir)) {
      fs.readdirSync(dir).forEach(function(file, index) {
        var curPath = dir + '/' + file;
        if (fs.lstatSync(curPath).isDirectory()) {
          // recurse
          removeFolder(curPath);
        } else {
          // delete file
          fs.unlinkSync(curPath);
        }
      });
      fs.rmdirSync(dir);
    }
  };

  export const makeDir = function(dirPath: string) {
    if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, {recursive: true});
  };

  export const randomFileName = function(extname: string): string {
    const name = crypto.randomBytes(16).toString('Hex');
    const date = new Date();
    const filename = name + '-' + date.getTime() + (extname ? (extname.startsWith('.') ? extname : '.' + extname) : '');
    return filename;
  };

  export const processVideo = async (src: string, des: string, filename: string) => {
    const fileNameIgnoreTag: string = filename.split('.')[0];
    const originalVideoSrc = path.join(des, fileNameIgnoreTag);
    await moveFile(src, originalVideoSrc, filename);
    await VideoProcessing.generateThumbnai(path.join(originalVideoSrc, filename), fileNameIgnoreTag);
    await Promise.all([
      VideoProcessing.resizeVideo(path.join(originalVideoSrc, filename), originalVideoSrc, fileNameIgnoreTag, 720),
      VideoProcessing.resizeVideo(path.join(originalVideoSrc, filename), originalVideoSrc, fileNameIgnoreTag, 480),
      VideoProcessing.resizeVideo(path.join(originalVideoSrc, filename), originalVideoSrc, fileNameIgnoreTag, 360),
    ]);
    // .then((result) => {})
    // .catch((error) => {});
  };
}
