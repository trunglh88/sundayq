module.exports = {
  extends: '@loopback/eslint-config',
  rules: {
    "max-len": ["off", { "code": 120 }],
    "no-unused-vars": "off",
    "@typescript-eslint/no-unused-vars": ["warn"]
  }
};
