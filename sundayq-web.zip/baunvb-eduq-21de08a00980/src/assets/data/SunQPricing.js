export const SunQPricingData = [
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5057551_cover_home_ipados_14_beta.jpg" //aptional
    },
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5060422_Cover_Microsoft.jpg" //aptional
    },
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5057551_cover_home_ipados_14_beta.jpg" //aptional
    },
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5060422_Cover_Microsoft.jpg" //aptional
    },
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5057551_cover_home_ipados_14_beta.jpg" //aptional
    },
    {
        title: "Khóa học cho bé",
        content: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        excerpt: "", //optional
        featured_image: "https://photo2.tinhte.vn/data/attachment-files/2020/06/5060422_Cover_Microsoft.jpg" //aptional
    },

]