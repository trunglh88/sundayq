export const Member = `<p>&nbsp;&nbsp;&nbsp;&nbsp; Khoa học c&ocirc;ng nghệ l&agrave; điều kiện ti&ecirc;n quyết để đất nước ta bắt nhịp, h&ograve;a nhập với thời đại v&agrave; dẫn đầu xu hướng to&agrave;n cầu h&oacute;a. Ch&iacute;nh v&igrave; thế, c&aacute;c th&agrave;nh vi&ecirc;n khi tham gia SundayQ sẽ c&oacute; cơ hội tiếp cận v&agrave; trải nghiệm với khoa học c&ocirc;ng nghệ mới nhất, được khơi dậy khả năng s&aacute;ng tạo, sự tự tin v&agrave; niềm đam m&ecirc; với c&ocirc;ng nghệ.</p>
<p>H&atilde;y trở th&agrave;nh th&agrave;nh vi&ecirc;n của SundayQ, bạn sẽ nhận được những lợi &iacute;ch tuyệt vời!</p>
<p><strong>Những ưu đ&atilde;i khi trở th&agrave;nh th&agrave;nh vi&ecirc;n của SundayQ:</strong></p>
<p>* Kh&ocirc;ng giới hạn v&agrave;o ph&ograve;ng trưng b&agrave;y của SundayQ.</p>
<p>* V&agrave;o cửa miễn ph&iacute; tại nhiều trung t&acirc;m khoa học v&agrave; bảo t&agrave;ng tr&ecirc;n khắp dất nước.</p>
<p>* Giảm gi&aacute; 10% khi mua h&agrave;ng tại Qshop. Giảm gi&aacute; &aacute;p dụng tại cửa h&agrave;ng v&agrave; mua sắm trực tuyến.</p>
<p>* Mọi th&ocirc;ng tin chi tiết về SundayQ sẽ được th&ocirc;ng b&aacute;o bằng email.</p>
<p>* Truy cập v&agrave;o ph&ograve;ng chờ của th&agrave;nh vi&ecirc;n.</p>
<p>* Được cung cấp một t&agrave;i khoản miễn ph&iacute; để giới thiệu cho bạn b&egrave; về SundayQ.</p>
<p><strong>C&aacute;ch thức tham gia:</strong></p>
<p>* Trực tiếp: đăng k&iacute; trực tiếp với nh&acirc;n vi&ecirc;n ch&uacute;ng t&ocirc;i tại trung t&acirc;m. Bạn c&oacute; thể ngay lập tức trở th&agrave;nh th&agrave;nh vi&ecirc;n v&agrave; nhận được những ưu đ&atilde;i bất ngờ.</p>
<p>* Qua email: gửi email cho ch&uacute;ng t&ocirc;i qua địa chỉ (.........) v&agrave; ch&uacute;ng t&ocirc;i sẽ tư vấn v&agrave; gửi cho bạn mẫu đơn đăng k&iacute;.</p>
<p>* Qua điện thoại: vui l&ograve;ng li&ecirc;n hệ theo số (...........) v&agrave; nh&acirc;n vi&ecirc;n của ch&uacute;ng t&ocirc;i sẽ tư vấn v&agrave; giải đ&aacute;p to&agrave;n bộ thắc mắc của bạn.</p>
<p><a href="/q-academy/club?id=club-1&dialog=1"><span style="color: #ff0000;"><em>* Lưu &yacute;: ( quyền ri&ecirc;ng tư v&agrave; bảo mật)</em></span></a></p>
<p><strong>Bảng gi&aacute;:</strong></p>
<p>Tham gia SundayQ, c&aacute;c bạn c&oacute; thể gh&eacute; thăm v&agrave; tham quan c&aacute;c triển l&atilde;m của ch&uacute;ng t&ocirc;i bất k&igrave; l&uacute;c n&agrave;o trong thời gian mở cửa. Nếu trở th&agrave;nh kh&aacute;ch h&agrave;ng th&acirc;n thiết của SundayQ, bạn ho&agrave;n to&agrave;n c&oacute; thể nhận được những ưu đ&atilde;i bất ngờ. Ngo&agrave;i ra, ch&uacute;ng t&ocirc;i c&ograve;n c&oacute; dịch vụ giảm gi&aacute; d&agrave;nh cho những kh&aacute;ch h&agrave;ng c&oacute; nhu cầu gia hạn th&ecirc;m.</p>
<p><em><span style="text-decoration: underline;">( bảng gi&aacute;)</span></em></p>
<p><strong>Trải nghiệm thử SunndayQ:</strong></p>
<p>Bạn c&oacute; thể mua v&eacute; đến trải nghiệm tại trung t&acirc;m theo ng&agrave;y hoặc theo từng đợt, từng kh&oacute;a. Nếu bạn cảm thấy h&agrave;i l&ograve;ng với dịch vụ tại trung t&acirc;m, bạn c&oacute; thể đến quầy lễ t&acirc;n để đăng k&iacute; trở th&agrave;nh th&agrave;nh vi&ecirc;n ch&iacute;nh thức ngay khi kết th&uacute;c chuyến thăm.</p>
<p><strong>Th&agrave;nh vi&ecirc;n qu&agrave; tặng:</strong>&nbsp;</p>
<p>Nếu bạn muốn tặng qu&agrave; cho th&agrave;nh vi&ecirc;n kh&aacute;c, vui l&ograve;ng mua thẻ qu&agrave; tặng tr&ecirc;n Qshop. Cửa h&agrave;ng c&oacute; thể gửi thẻ đến địa chỉ m&agrave; bạn đ&atilde; chỉ định. Thẻ qu&agrave; tặng c&oacute; thể trao đổi giữa c&aacute;c th&agrave;nh vi&ecirc;n của SundayQ.</p>
<p>Tư c&aacute;ch th&agrave;nh vi&ecirc;n sẽ kh&ocirc;ng c&oacute; hiệu lực cho đến khi thẻ qu&agrave; tặng được trao đổi.</p>`

export const Science = `<ul>
<li>CLB Dr labo: hiện nay ở hầu hết c&aacute;c trường học ở Việt Nam kh&ocirc;ng c&oacute; ph&ograve;ng học th&iacute; nghiệm v&agrave; ph&ograve;ng thực h&agrave;nh chuẩn.</li>
</ul>
<p>Đ&oacute; l&agrave; l&yacute; do v&igrave; sao ch&uacute;ng t&ocirc;i đưa đến m&ocirc; h&igrave;nh Q-Labs với c&aacute;c thiết bị v&agrave; nội dung chuẩn mực gi&uacute;p c&aacute;c học sinh ở Việt Nam c&oacute; cơ hội được học tập trải nghiệm v&agrave; thực h&agrave;nh tốt hơn.</p>
<p>C&aacute;c m&ocirc;n học được đưa ra trong Q-Labs bao gồm :</p>
<ul>
<li>To&aacute;n học (Math)</li>
<li>vật L&yacute; (Physic)</li>
<li>H&oacute;a học (Chemistry)</li>
<li>Sinh vật cảnh (Biology)</li>
<li>giải phẫu học</li>
<li>Vũ trụ kh&ocirc;ng gian (astronaus)</li>
<li>CLB trải nghiệm khoa học vui: c&ugrave;ng với m&ocirc;i trường học ti&ecirc;u chuẩn, hấp dẫn, l&iacute; th&uacute;, ch&uacute;ng t&ocirc;i c&ograve;n thiết kế đồ chơi v&agrave; x&acirc;y dựng c&aacute;c show khoa học để c&aacute;c bạn trực tiếp được nh&igrave;n, thực hiện v&agrave; cảm nhận nhằm khơi dậy niềm đam m&ecirc; t&igrave;m t&ograve;i, ph&aacute;t minh, nghi&ecirc;n cứu. Nhờ việc học tập th&ocirc;ng qua trải nghiệm vui, c&aacute;c bạn học vi&ecirc;n sẽ biết c&aacute;ch thực h&agrave;nh những kĩ năng nghi&ecirc;n cứu khoa học qua đ&oacute; c&aacute;c bạn sẽ lĩnh hội kiến thức một c&aacute;ch tự nhi&ecirc;n nhẹ nh&agrave;ng v&agrave; thấy được sự th&uacute; vị của kiến thức, h&igrave;nh th&agrave;nh v&agrave; ph&aacute;t triền năng lực hợp t&aacute;c.</li>
<li>CLB s&aacute;ng tạo: r&egrave;n luyện v&agrave; ph&aacute;t triển tư duy s&aacute;ng tạo,t&iacute;nh kh&eacute;o l&eacute;o gi&uacute;p c&aacute;c bạn c&oacute; thể tự l&agrave;m đồ chơi an to&agrave;n gi&uacute;p bố mẹ v&agrave; c&aacute;c bạn học vi&ecirc;n c&oacute; thể c&ugrave;ng nhau t&igrave;m hiểu chất liệu, l&agrave;m đồ chơi v&agrave; chơi với nhau.</li>
</ul>
<p>Gồm c&aacute;c nội dung t&igrave;m hiểu:</p>
<p>◄Thiết kế thời trang (vẽ thời trang đơn giản nhất)</p>
<p>◄Vẽ v&agrave; trang tr&iacute; (vẽ s&aacute;p ong, vẽ m&agrave;u acrylic, nhuộm m&agrave;u tự nhi&ecirc;n từ củ quả, nhuộm m&agrave;u bột của l&agrave;o, tranh gh&eacute;p vải &hellip;)</p>
<p>◄ Thiết kế v&agrave; l&agrave;m c&aacute;c đồ thủ c&ocirc;ng: b&uacute;p b&ecirc;, đồ chơi, đồ d&ugrave;ng trang tr&iacute;, vật dụng c&aacute; nh&acirc;n (,l&agrave;m đồ vật từ vải dạ nỉ, (bạn lớn th&igrave; kh&acirc;u chỉ trang tr&iacute;, b&eacute; th&igrave; chọn m&agrave;u rồi d&aacute;n), l&agrave;m hoa tai, trang sức từ chất liệu resin, l&agrave;m hoa tai, trang sức từ chất liệu tận dụng như vải dạ, th&ecirc;u nổi để vừa l&agrave;m trang tr&iacute; vừa c&oacute; t&iacute;nh ứng dụng v&agrave;o t&uacute;i x&aacute;ch,quần &aacute;o...)</p>
<p>◄ T&igrave;m hiểu về c&ocirc;ng nghệ v&agrave; ứng dụng mới trong ng&agrave;nh thiết kế v&agrave; s&aacute;ng tạo như: m&aacute;y cắt laze 3D, ứng dụng phần mềm trong cắt v&agrave; thiết kế</p>`

export const Club3 = `Chúng tôi liên kết thông tin với các hãng công nghệ hàng đầu tại Việt Nam như FPT, VNG, SamSung, LG, Panasonic,... nhằm ngay lập tức cập nhật những phát minh công nghệ mới nhất, ứng dụng công nghệ thế hệ 4.0 đến với các bạn học viên. Với những thông tin mới nhất được cập nhật đó các bạn sẽ luôn đón đầu xu hướng hiện đại, luôn nhanh nhạy linh hoạt nắm bắt thông tin công nghệ từ đó các bạn sẽ phát triển một cách đúng hướng, bắt kịp với thời đại.`

export const Club4 = `<p><strong>Triển l&atilde;m v&agrave; đồ lưu niệm:</strong></p>
<p>*Qu&agrave; lưu niệm SundayQ</p>
<p>*Tr&ograve; chơi to&aacute;n học SundayQ</p>
<p>*M&ocirc; h&igrave;nh</p>
<p>* Cơ quan h&agrave;ng kh&ocirc;ng vũ trụ</p>
<p><strong>Bộ dụng cụ khoa học:</strong></p>
<p>*K&iacute;nh hiển vi v&agrave; k&iacute;nh thi&ecirc;n văn</p>
<p>* Bộ dụng cụ sinh học</p>
<p>* Bộ dụng cụ h&oacute;a học</p>
<p>* Tr&aacute;i đất v&agrave; kh&ocirc;ng gian</p>
<p>*Bộ dụng cụ khoa học sinh th&aacute;i</p>
<p>*Bộ dụng cụ vật l&yacute;</p>
<p>*Điện v&agrave; từ t&iacute;nh</p>
<p>*C&ocirc;ng nghệ v&agrave; m&atilde; h&oacute;a</p>
<p>*To&aacute;n học</p>
<p><strong>D&agrave;nh cho trẻ em:</strong></p>
<p>*Học tập từ sớm</p>
<p>*Đồ chơi</p>
<p>* Bảng tr&ograve; chơi</p>
<p>* C&acirc;u đố 2D, 3D, 4D</p>
<p>*Bộ dụng cụ x&acirc;y dựng</p>
<p>* Khoa học nh&agrave; bếp</p>
<p>*Robot</p>
<p>*Kh&ocirc;ng gian</p>
<p>*Hoạt động ngo&agrave;i trời</p>
<p><strong>Nh&agrave; v&agrave; trung t&acirc;m:</strong></p>
<p>*M&oacute;n ăn</p>
<p>*S&aacute;ch</p>
<p>*Đồ gia dụng v&agrave; trang tr&iacute;</p>
<p>*Quần &aacute;o v&agrave; phụ kiện</p>
<p>*Khoa học nh&agrave; bếp</p>
<p>*Văn ph&ograve;ng phẩm</p>
<p>* Thời tiết</p>
<p><strong>&Yacute; tưởng qu&agrave; tặng:</strong></p>
<p>*Lứa tuổi 2-4</p>
<p>*Lứa tuổi 5-7</p>
<p>*Lứa tuổi 8-11</p>
<p>*Từ 12 tuổi trở l&ecirc;n</p>
<p>*Người lớn</p>
<p>*Khoa học bỏ t&uacute;i</p>
<p>*Lạ v&agrave; tuyệt vời</p>
<p>*Qu&agrave; lưu niệm SundayQ</p>
<p>*Thẻ qu&agrave; tặng</p>
<p><strong>T&agrave;i nguy&ecirc;n giảng dạy:</strong></p>
<p>*Sinh học</p>
<p>*Vi khuẩn khổng lồ</p>
<p>*H&oacute;a học</p>
<p>*Vật l&yacute;</p>
<p>*Tr&aacute;i đất v&agrave; kh&ocirc;ng gian</p>
<p>*C&ocirc;ng nghệ</p>
<p>*To&aacute;n học</p>
<p>*Tr&ograve; chơi to&aacute;n học SundayQ</p>
<p>*S&aacute;ch t&agrave;i nguy&ecirc;n</p>`

export const Club5 = `<p>Trung t&acirc;m ch&uacute;ng t&ocirc;i kết hợp với c&aacute;c đơn vị, c&aacute;c trường đại học nghi&ecirc;n cứu chuy&ecirc;n s&acirc;u về khoa học, c&aacute;c bảo t&agrave;ng, c&aacute;c viện nghi&ecirc;n cứu tr&ecirc;n to&agrave;n quốc để tổ chức c&aacute;c tour d&atilde; ngoại thực tế cho c&aacute;c th&agrave;nh vi&ecirc;n c&acirc;u lạc bộ v&agrave; đưa c&acirc;u lạc bộ SundayQ đến c&aacute;c tỉnh.</p>
<p><strong>Ch&uacute;ng t&ocirc;i hợp t&aacute;c với c&aacute;c đơn vị như:</strong></p>
<p><strong>*Vườn khoa học:</strong> ch&uacute;ng t&ocirc;i hợp t&aacute;c c&ugrave;ng với vườn khoa học Erahouse để tổ chức c&aacute;c tham quan cho c&aacute;c th&agrave;nh vi&ecirc;n trong c&acirc;u lạc bộ. Với cảnh quan xanh- tho&aacute;ng- rộng- đẹp, kh&ocirc;ng gian y&ecirc;n tĩnh, c&oacute; khu b&atilde;i rộng để tổ chức c&aacute;c sự kiện, cắm trại, teambuilding ngo&agrave;i trời, đặc biệt l&agrave; gi&aacute; cả hợp l&yacute;, ch&iacute;nh v&igrave; thế khi tham quan trải nghiệm tại đ&acirc;y, c&aacute;c th&agrave;nh vi&ecirc;n sẽ c&oacute; cơ hội t&igrave;m hiểu về khoa học, sinh học, vũ trụ xung quanh ta. C&aacute;c kiến thức về n&agrave;y sẽ được chuyển h&oacute;a th&agrave;nh những tr&ograve; chơi, b&agrave;i học đơn giản dễ nhớ, đi k&egrave;m với những hoạt động thể chất l&agrave;nh mạnh để học sinh c&oacute; thể hiểu một c&aacute;ch đơn giản về những hiện tượng vật l&yacute;, h&oacute;a học, sinh học xảy ra trong cuộc sống.</p>
<p><strong>*Viện To&aacute;n học:</strong> l&agrave; địa điểm d&agrave;nh cho những bạn trẻ y&ecirc;u th&iacute;ch To&aacute;n học. C&aacute;c th&agrave;nh vi&ecirc;n sẽ c&oacute; cơ hội tham quan Viện To&aacute;n học, trực tiếp trải nghiệm v&agrave; tham gia c&aacute;c buổi diễn thuyết của c&aacute;c gi&aacute;o sư h&agrave;ng đầu Việt Nam. Từ đ&oacute;, c&aacute;c bạn học vi&ecirc;n sẽ c&oacute; hứng th&uacute; với bộ m&ocirc;n To&aacute;n học, được r&egrave;n luyện khả năng tư duy logic gi&uacute;p cho việc học To&aacute;n tại trường trở n&ecirc;n đơn giản v&agrave; th&uacute; vị hơn.</p>
<p><strong>*Viện h&agrave;n l&acirc;m Khoa học v&agrave; C&ocirc;ng nghệ:</strong> nơi đ&acirc;y chuy&ecirc;n cứu cơ bản về khoa học tự nhi&ecirc;n v&agrave; ph&aacute;t triển c&ocirc;ng nghệ trong c&aacute;c lĩnh vực: To&aacute;n học, vật l&yacute;, h&oacute;a học, sinh học, c&ocirc;ng nghệ sinh học, c&ocirc;ng nghệ th&ocirc;ng tin, điện tử, tự động h&oacute;a, c&ocirc;ng nghệ vũ trụ, khoa học vật liệu, đa dạng sinh học...C&aacute;c th&agrave;nh vi&ecirc;n tham quan tại đ&acirc;y sẽ được hướng dẫn thực hiện một v&agrave;i nghi&ecirc;n cứu cơ bản về l&igrave;nh vực tr&ecirc;n để hiểu th&ecirc;m về khoa học, k&iacute;ch th&iacute;ch t&iacute;nh s&aacute;ng tạo, học hỏi, nghi&ecirc;n cứu, t&igrave;m t&ograve;i v&agrave; ph&aacute;t triển kĩ năng&nbsp; hợp t&aacute;c v&agrave; l&agrave;m việc theo nh&oacute;m.</p>
<p><strong>*Viện H&agrave;ng kh&ocirc;ng Vũ trụ:</strong> đ&acirc;y l&agrave; ng&ocirc;i nh&agrave; chung cho những người y&ecirc;u c&ocirc;ng nghệ, đam m&ecirc; nghi&ecirc;n cứu v&agrave; s&aacute;ng tạo. C&aacute;c th&agrave;nh vi&ecirc;n trong c&acirc;u lạc bộ sẽ được trực tiếp tham quan v&agrave; trải nghiệm tại Viện nghi&ecirc;n cứu H&agrave;ng kh&ocirc;ng Vũ trụ Viettel, l&agrave;m quen với c&ocirc;ng nghiệp H&agrave;ng kh&ocirc;ng, vũ trụ c&ocirc;ng nghệ cao của Việt nam trong tương lai, với cơ sở hạ tầng, trang thiết bị c&ocirc;ng nghệ hiện đại v&agrave; đội ngũ chuy&ecirc;n gia thiết kế, c&aacute;n bộ kĩ thuật c&ocirc;ng nghệ xuất sắc.</p>
<p><strong>*Trường Đại học B&aacute;ch khoa H&agrave; Nội:</strong> C&aacute;c học vi&ecirc;n sẽ được tham quan tại Trung t&acirc;m nghi&ecirc;n cứu kĩ thuật cơ kh&iacute; ch&iacute;nh x&aacute;c, Xưởng thực nghiệm v&agrave; nghi&ecirc;n cứu triển khai. Qua đ&oacute;, c&aacute;c bạn sẽ được tận mắt v&agrave; tận tay thực hiện những th&iacute; nghiệm đơn giản về kĩ thuật cơ kh&iacute;, được cầm tr&ecirc;n tay th&agrave;nh quả m&agrave; m&igrave;nh tạo ra, t&iacute;ch lũy được những kiến thức li&ecirc;n quan đến kĩ thuật cơ kh&iacute;.</p>
<p><strong>*Trường Đại học N&ocirc;ng nghiệp:</strong> đến đ&acirc;y c&aacute;c bạn học vi&ecirc;n sẽ được đi tham quan c&aacute;c vườn ươm ngay tại khu&ocirc;n vi&ecirc;n trường, được t&igrave;m hiểu về đặc t&iacute;nh của từng giống c&acirc;y, c&aacute;ch lai tạo c&aacute;c giống c&acirc;y trồng, c&aacute;ch ươm c&acirc;y giống, c&aacute;ch chăm s&oacute;c c&acirc;y ph&ugrave; hợp với kh&iacute; hậu Việt Nam, được tự tay trồng loại c&acirc;y giống. Ngo&agrave;i ra, c&aacute;c bạn c&ograve;n c&oacute; thể t&igrave;m hiểu về c&aacute;c giống vật nu&ocirc;i đặc th&ugrave; tại Việt Nam, c&aacute;ch phối giống vật nu&ocirc;i, v&agrave; được thử trải nghiệm chăm s&oacute;c vật nu&ocirc;i tại c&aacute;c trang trại.</p>
<p><strong>*Bảo t&agrave;ng Thi&ecirc;n nhi&ecirc;n Việt Nam:</strong> tại Bảo t&agrave;ng trưng b&agrave;y gần 1.400 mẫu vật kh&aacute;i qu&aacute;t c&acirc;u chuyện lịch sự sự sống qua 3,6 tỉ năm về nguồn gốc sự sống v&agrave; thi&ecirc;n nhi&ecirc;n Việt Nam. C&aacute;c bạn học vi&ecirc;n c&oacute; thể thỏa sức t&igrave;m hiểu về qu&aacute; tr&igrave;nh tiến h&oacute;a của sự sống, c&aacute;c mẫu h&oacute;a thạch ti&ecirc;u biểu qua c&aacute;c thời k&igrave; ph&aacute;t triển địa chất, đặc biệt c&aacute;c bạn sẽ được chứng kiến qu&aacute; tr&igrave;nh tiến h&oacute;a của lo&agrave;i người từ linh trưởng, h&igrave;nh người đầu ti&ecirc;n rồi tiến h&oacute;a l&ecirc;n những chủng người kh&aacute;c nhau v&agrave; cuối c&uacute;ng l&agrave; người hiện đại ng&agrave;y nay, bằng c&aacute;c mẫu hiện vật sinh động, sắc n&eacute;t, ch&acirc;n thực.</p>
<p><strong>* Viện thiết kế thời trang:</strong> gh&eacute; thăm viện thiết kế thời trang c&aacute;c c&aacute;c bạn học vi&ecirc;n sẽ được quan s&aacute;t c&aacute;c c&ocirc;ng đoạn tạo n&ecirc;n một sản phẩm thời trang từ việc nghĩ &yacute; tưởng cho đến khi sản phẩm được ra mắt, sau đ&oacute; c&aacute;c bạn sẽ được trực tiếp tham gia v&agrave;o qu&aacute; tr&igrave;nh thiết kế sản phẩm thời trang dưới sự hướng dẫn của c&aacute;c chuy&ecirc;n vi&ecirc;n d&agrave;y dặn kinh nghiệm v&agrave; c&oacute; thể tập thiết kế những trang phục đơn giản. Chuyến tham quan n&agrave;y c&oacute; thể trở th&agrave;nh sợi d&acirc;y li&ecirc;n kết những bạn y&ecirc;u th&iacute;ch v&agrave; c&oacute; ước mơ trở th&agrave;nh nh&agrave; thiết kế thời trang đến gần hơn với ước mơ của m&igrave;nh.</p>
<p><strong>*Xưởng thủ c&ocirc;ng-mỹ nghệ:</strong> c&aacute;c bạn học vi&ecirc;n sẽ được trực tiếp trải nghiệm tại c&aacute;c xưởng thủ c&ocirc;ng mỹ nghệ như: L&agrave;ng gốm B&aacute;t Tr&agrave;ng, Mỹ nghệ Sừng Minh Giang Craft, Đồ M&acirc;y tre Mỹ nghệ Sapa, H&agrave; Dũng Craft,... C&aacute;c bạn sẽ c&oacute; c&aacute;i nh&igrave;n cận cảnh qu&aacute; tr&igrave;nh tạo ra sản phẩm thủ c&ocirc;ng đẹp mắt, qua đ&ocirc;i b&agrave;n tay kh&eacute;o l&eacute;o của những người thợ l&agrave;nh nghề. Đặc biệt, khi đến xưởng, ngo&agrave;i việc tham quan, xem c&aacute;c sản phẩm tinh tế, quan s&aacute;t c&ocirc;ng việc của c&aacute;c nghệ nh&acirc;n, c&aacute;c bạn c&ograve;n c&oacute; cơ hội tham gia một số kh&acirc;u sản xuất đơn giản v&agrave; mang về những sản phẩm do ch&iacute;nh tay m&igrave;nh l&agrave;m ra. Qua những khoảnh khắc như thế, c&aacute;c bạn sẽ hiểu được để tạo ra những sản phẩm ho&agrave;n hảo, độc đ&aacute;o như vậy, cần c&oacute; sự s&aacute;ng tạo, kh&eacute;o l&eacute;o v&agrave; phải trải qua một qu&aacute; tr&igrave;nh m&agrave;y dũa l&acirc;u d&agrave;i. Những tour tham quan thực tế n&agrave;y sẽ gi&uacute;p khơi dậy niềm đam m&ecirc;, thỏa m&atilde;n sự t&ograve; m&ograve;, định h&igrave;nh v&agrave; nu&ocirc;i dưỡng ước mơ về nghệ thuật trong mỗi bạn học vi&ecirc;n. </p>`

export const Club6 = `<p>CLB SundayQ li&ecirc;n kết với c&aacute;c CLB khoa học tại c&aacute;c trường c&oacute; chuy&ecirc;n m&ocirc;n về khoa học c&ocirc;ng nghệ tr&ecirc;n cả nước như: CLB khoa học VOER, CLB Oucru, CLB L&ocirc;m&ocirc;n&ocirc;x&ocirc;p, CLB Khoa học v&agrave; C&ocirc;ng nghệ - FIT-HITU,... C&aacute;c bạn học vi&ecirc;n c&oacute; thể c&ugrave;ng với c&aacute;c chuy&ecirc;n gia đầu ng&agrave;nh trong lĩnh vực khoa học c&ocirc;ng nghệ, khoa học tr&aacute;i đất, khoa học tự nhi&ecirc;n, khoa học x&atilde; hội, tr&ograve; chuyện v&agrave; giải đ&aacute;p thắc mắc. Đặc biệt c&aacute;c bạn c&ograve;n c&oacute; cơ hội tham gia v&agrave;o c&aacute;c dự &aacute;n nghi&ecirc;n cứu khoa học, qu&aacute; tr&igrave;nh nghi&ecirc;n cứu ph&aacute;t minh s&aacute;ng chế mới c&ugrave;ng c&aacute;c chuy&ecirc;n gia, c&aacute;c giảng vi&ecirc;n c&oacute; kinh nghiệm d&agrave;y dặn. Qua đ&oacute;, c&aacute;c bạn ph&aacute;t triển được tư duy khoa học, hiểu được một quy tr&igrave;nh nghi&ecirc;n cứu khoa học, n&acirc;ng cao năng lực giải quyết vấn đề.</p>`