import {Member, Science, Club3, Club4, Club5, Club6} from './ClubHtml'
export const SunQClubData = [
    {
        id: "club-1",
        title: "Trở thành thành viên",
        excerpt: "Trở thành thành viên của Qclub ngay hôm nay để được hưởng những ưu đãi không giới hạn.",
        content: Member, //optional
        featured_image: require('../icon/club1.svg'),
        
    },
    {
        id: "club-2",
        title: "Khám phá khoa học",
        excerpt: "Học và chơi cùng con từ 0-2 tuổi. Phát triển thể lực trí tuệ cho trẻ từ 0-2 tuổi.",
        content: Science, //optional
        featured_image: require('../icon/club2.svg')
    },
    {
        id: "club-3",
        title: "Phát minh/công nghệ mới",
        excerpt: "Liên kết thông tin với hãng để giới thiệu các sản phẩm mới.",
        content: Club3, //optional
        featured_image: require('../icon/club3.svg')
    },
    {
        id: "club-4",
        title: "Qshop",
        excerpt: "Giới thiệu và bán các loại đồ chơi khoa học, thiết bị giáo dục…",
        content: Club4, //optional
        featured_image: require('../icon/club4.svg')
    },
    {
        id: "club-5",
        title: "Tour",
        excerpt: "Kết hợp với các đơn vị, trường tổ chức các tour dã ngoại cho thành viên hoặc đưa CLB SundayQ đến các tỉnh",
        content: Club5, //optional
        featured_image: require('../icon/club5.svg')
    },
    {
        id: "club-6",
        title: "Sáng chế/ Dự án",
        excerpt: "Liên kết các câu lạc bộ khoa học tại các trường để giới thiệu",
        content: Club6, //optional
        featured_image: require('../icon/club6.svg')
    },

]
