import React, { Component } from 'react';
import './lecturer-list.css';
import SectionInner from '../../../component/Container/SectionInner';
import Pagination from '@material-ui/lab/Pagination';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants, Utils } from '../../../utils';
import { NavLink } from 'react-router-dom';
import { NavigationSubMenu } from '../coursedetail/CourseDetailScreen';

// {name, university, specialist}
const PAGE_COUNT = 5;
const LENGTH = 19;
// const lecturer = {
//     name: 'pgs. ts lưu vũ quang',
//     university: 'Trường Đại học Kinh tế Kỹ thuật công nghiệp',
//     specialist: 'Điện tử điện lạnh',
//     experience: 12,
//     position: 'Giảng viên',
//     description: 'Trong bối cảnh cạnh tranh gay gắt hướng tới xu thế hội nhập quốc tế, ngành Dịch vụ Logistics Việt Nam đòi hỏi phải phát triển nguồn nhân lực có chất lượng cao cả về kỹ năng, kiến thức chuyên môn và trình độ tiếng Anh chuyên ngành. Tuy nhiên, hiện nay nguồn nhân lực trong ngành Logistics còn yếu và thiếu hụt cả về chất lượng và số lượng. Chỉ tính riêng nguồn nhân lực cho các công ty cung cấp dịch vụ Logistics bên thứ 3 (không bao gồm các công ty vận tải thủy, bộ, biển, hàng không, cảng thuần túy) từ nay tới năm 2030 sẽ cần đào tạo mới và bài bản 250.000 nhân sự. Nhiều vị trí khan hiếm nhân lực từ lãnh đạo - quản trị tới quản lý, giám sát Trong bối cảnh cạnh tranh gay gắt hướng tới xu thế hội nhập quốc tế, ngành Dịch vụ Logistics Việt Nam đòi hỏi phải phát triển nguồn nhân lực có chất lượng cao cả về kỹ năng, kiến thức chuyên môn và trình độ tiếng Anh chuyên ngành. Tuy nhiên, hiện nay nguồn nhân lực trong ngành Logistics còn yếu và thiếu hụt cả về chất lượng và số lượng. Chỉ tính riêng nguồn nhân lực cho các công ty cung cấp dịch vụ Logistics bên thứ 3 (không bao gồm các công ty vận tải thủy, bộ, biển, hàng không, cảng thuần túy) từ nay tới năm 2030 sẽ cần đào tạo mới và bài bản 250.000 nhân sự. Nhiều vị trí khan hiếm nhân lực từ lãnh đạo - quản trị tới quản lý, giám sát',
// };
// let listLecturer = [];
// for (let i = 0; i < LENGTH; i++) {
//     listLecturer.push({ ...lecturer, id: i, experience: i + 1 });
// }

function LecturerInfo(props) {
    let { name, university, specialist, practiceAt, degree, description, id, imgUrl, shortDescription } = props.lecturer;
    description = description.replace(/<pre>/g, '');
    let pracAt = Utils.calcYearDistance(practiceAt);
    let avatar = Utils.imageUrl(imgUrl)

    return (
        <div className="lecturer-list-wrap-item-main">
            <div className="lecturer-list-item-wrap-name">
                <span className="lecturer-list-item-name">{name}</span>
            </div>
            <div className="lecturer-list-wrap-item">
                <div className="lecturer-list-item-avatar" style={{ backgroundImage: `url(${avatar})` }} ></div>
                <div style={{ padding: "4px 17px" }}></div>

                <div className="lecturer-list-wrap-item-info">
                    <span className="lecturer-list-item-university">Nơi công tác: <span
                        className="lecturer-list-item-university-info">{university}</span></span>
                    <span className="lecturer-list-item-specialist">Chuyên khoa: <span
                        className="lecturer-list-item-specialist-info">{specialist}</span></span>
                    <span className="lecturer-list-item-experience">Kinh nghiệm chuyên môn: <span
                        className="lecturer-list-item-experience-info">{`${pracAt} năm`}</span></span>
                    <span className="lecturer-list-item-position">Chức danh trong học viện: <span
                        className="lecturer-list-item-position-info">{degree}</span></span>
                    <span style={{ fontStyle: "italic", marginTop: "10px" }} className="lecturer-list-item-description-info">{shortDescription}</span>
                    <a className="lecturer-list-text-decor-none" href={`/q-expert?id=${id}`}>
                        <div className="lecturer-list-item-show-more">
                            <span>Đọc thêm</span>
                            <img src={require("../../../assets/icon/ic_navigate_expert_red.svg")}/>
                        </div>
                    </a>
                </div>
            </div>

        </div>

    );
}

function PaginationLecturer(props) {
    return (
        <div className="lecturer-list-pagination">
            <Pagination
                hideNextButton={true}
                hidePrevButton={true}
                classes={{ ul: "lecturer-list-wrap-page-index" }}
                onChange={(event, page) => props.onChange(page)}
                count={Math.ceil(props.total / PAGE_COUNT)}
                variant="outlined"
                shape="rounded"
            />
        </div>
    );
}

class LecturerList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            page: 1,
            listLecturer: [],
            searchStr: ""
        };
    }

    componentDidMount() {
        ApiHelper.get(Constants.GET_TEACHER_LIST())
            .then(({ data }) => {
                console.log('data::', data);
                this.setState({
                    listLecturer: data,
                });
            })
            .catch((error) => {
                console.log('error::', error);
            });
    }

    onChangePageIndex = (page) => {
        this.setState({ page: page });
    };

    onSearch = (value) => {
        this.setState({ searchStr: value })
    }

    render() {
        const { page, listLecturer, searchStr } = this.state;
        let searchResult = listLecturer;
        let listLecturerShowed = listLecturer.slice((page - 1) * PAGE_COUNT, page * PAGE_COUNT);
        if (searchStr != "") {
            searchResult = listLecturer.filter((e) => (Utils.search(searchStr, e.name, e.degree, e.university)));
            listLecturerShowed = searchResult.slice((page - 1) * PAGE_COUNT, page * PAGE_COUNT);

        }
        // let routes = ['Q-academy', 'Nhà khoa học Dr.Right', 'Tất cả giảng viên'];

        return (
            <div className="lecturer-list-main">
                {/* <NavigationSubMenu routes={routes} /> */}

                <SectionInner extraClassName={['screen-full-width', 'qexpert-screen-main-layout']}>
                    <div className="lecturer-list-header-screen-title">
                        Tất cả giảng viên
                    </div>
                    <div className="lecturer-list-main-cover">
                        <img className="lecturer-list-main-cover-img"
                            src={require('../../../assets/icon/lecturer_list_bg.jpg')} />
                        {/* <span className="lecturer-list-main-cover-title">đội ngũ giảng viên</span> */}
                    </div>
                    <div className="lecturer-list-wrap-list">
                        <div className="lecturer-list-wrap-search-wrap">
                            <div className="lecturer-list-wrap-search">
                                <img src={require("../../../assets/icon/ic_search.svg")} />

                                <input
                                    onChange={e => this.onSearch(e.target.value)}
                                    placeholder="Tìm kiếm theo tên, nơi công tác, học vị"
                                />
                            </div>
                        </div>
                        {
                            listLecturerShowed.map((lecturer, key) => {
                                return (
                                    <LecturerInfo lecturer={lecturer} />
                                );
                            })
                        }

                    </div>
                </SectionInner>
                <div>
                    <PaginationLecturer
                        total={searchResult.length}
                        onChange={this.onChangePageIndex}
                    />
                </div>
            </div>
        );
    }
}

export default LecturerList;
