import React, { Component } from 'react';
import { NavigationSubMenu } from '../coursedetail/CourseDetailScreen';
import SectionInner from '../../../component/Container/SectionInner';
import './styles.css';
import LecturerInformation from '../coursedetail/components/lecturercard';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants, Utils } from '../../../utils';
import ServerUI from '../../../component/Container/ServerUI';
import moment from 'moment';

const EXPERT_DESCRIPTION = 'Trong bối cảnh cạnh tranh gay gắt hướng tới xu thế hội nhập quốc tế, ngành Dịch vụ Logistics Việt Nam đòi hỏi phải phát triển nguồn nhân lực có chất lượng cao cả về kỹ năng, kiến thức chuyên môn và trình độ tiếng Anh chuyên ngành. Tuy nhiên, hiện nay nguồn nhân lực trong ngành Logistics còn yếu và thiếu hụt cả về chất lượng và số lượng. Chỉ tính riêng nguồn nhân lực cho các công ty cung cấp dịch vụ Logistics bên thứ 3 (không bao gồm các công ty vận tải thủy, bộ, biển, hàng không, cảng thuần túy) từ nay tới năm 2030 sẽ cần đào tạo mới và bài bản 250.000 nhân sự. Nhiều vị trí khan hiếm nhân lực từ lãnh đạo - quản trị tới quản lý, giám sát và cả nhân viên chuyên nghiệp. \n\nBên cạnh đó, Logistics còn là ngành đặc thù đòi hỏi sự cập nhật và tiếp cận liên tục với những tiêu chuẩn từ thế giới như một bước đi tiên quyết đối với sự phát triển của doanh nghiệp. Và một trong những tổ chức hỗ trợ nâng cao trình độ chuyên môn, giải quyết được bài toán về chất lượng nguồn nhân lực, mở ra nhiều cơ hội cho doanh nghiệp và cá nhân tiếp cận với thị trường quốc tế chính là FIATA - Liên đoàn các Hiệp hội Giao nhận Vận tải Quốc Tế (International Federation of Freight Forwarders Associations). Được thành lập vào năm 1926, từ đó đến nay, với nhiệm vụ chính là hình thành tiêu chuẩn nghề nghiệp và nâng cao năng lực quản lý, FIATA đã không ngừng đổi mới và phát triển. Hiện tại, Liên đoàn có khoảng 40.000 thành viên tại hơn 150 Quốc gia. Ngoài ra, với lịch sử 92 năm hình thành, FIATA hiện đang đảm nhận chức vụ tư vấn cho Hội đồng Kinh tế và Xã Hội (ECOSOC) của Liên Hiệp quốc (bao gồm ECE, ESCAP, ESCWA); Hội nghị của Liên Hiệp quốc về Thương Mại và Phát triển (UNCTAD) và Uỷ Ban Liên Hiệp quốc về Luật thương mại Quốc tế (UNCITRAL).';

const ItemLecturer = (props) => {
    let teacher = props.lecturer;

    console.log("teacher::", teacher);

    //use hover instead of mouse event
    let containerClassName = `course-detail-lecturer-information-container`
    let practiceAt = moment(teacher.practiceAt);
    let current = moment();
    let yearDiff = (current.diff(practiceAt, 'year') + 1) || 0;


    return (
        <a className="expert-information-item-lecturer-wrap"
            href={`/q-expert?id=${teacher.id}`}
        >
            <img
                src={Utils.imageUrl(teacher.imgUrl)}
            />
            <span className="name">{teacher.name}</span>
            <span className="university">{teacher.university}</span>
            <div>
                <span className="label text-bold">{'Chuyên khoa: '}</span>
                <span className="label margin-left">{teacher.specialist}</span>
            </div>
            <div className="margin-top">
                <span className="label text-bold">{'Kinh nghiệm giảng dạy: '}</span>
                <span className="label margin-left">{`${yearDiff} năm`}</span>
            </div>
        </a>
    )
}

export default class QExpertScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: {

            },
            referenceLecturer: []
        };
    }

    componentDidMount() {
        let { search } = this.props.location;
        let teacherId = search.replace('?id=', '');
        this.setState({
            teacherId,
        });

        ApiHelper.get(Constants.GET_TEACHER_INFORMATION(teacherId))
            .then(({ data }) => {
                console.log('lecturer:', data);
                this.setState({
                    data,
                });
            })
            .catch((error) => {

            });

        //fetch list referent teacher
        ApiHelper.get(Constants.GET_TEACHER_LIST())
            .then(({ data }) => {
                console.log('data:: referenceLecturer', data);
                this.setState({
                    referenceLecturer: data,
                });
            })
            .catch((error) => {
                console.log('error::', error);
            });

    }

    renderLecturerInformation() {
        let { data } = this.state;
        let { practiceAt = "", degree = "", name = "", university = "", specialist = "", imgUrl = "", description = "" } = data;
        // description = description.replace(/<pre>/g, '');
        // description = description.replace(/<\/prev>/g, '');
        console.log("Description", description);
        // 2020-07-10T14:37:24.912Z
        practiceAt = moment(practiceAt);
        let current = moment();
        let yearDiff = (current.diff(practiceAt, 'year') + 1) || 0;

        console.log("diff::", practiceAt, current, yearDiff);
        return (
            <div className="expert-information-detail-wrapper">
                <div className="expert-information-detail-container">
                    <img
                        src={Utils.imageUrl(imgUrl)}
                        className="expert-information-image"
                    />
                    <div style={{ width: "32px", height: "16px" }}></div>
                    <div className="expert-information-detail-upper-view">
                        <p className="expert-information-text-field expert-information-name">{`${name}`}</p>
                        <p className="expert-information-text-field">
                            <span className="expert-information-info-bold expert-information-info">{"Nơi công tác: "}</span>
                            <span
                                className="expert-information-info">{` ${university}`}</span>
                        </p>
                        <p className="expert-information-text-field">
                            <span
                                className="expert-information-info-bold expert-information-info">{'Chuyên khoa: '}</span>
                            <span className="expert-information-info">{` ${specialist}`}</span>
                        </p>
                        <p className="expert-information-text-field">
                            <span
                                className="expert-information-info-bold expert-information-info">{'Kinh nghiệm chuyên môn: '}</span>
                            <span className="expert-information-info">{`${yearDiff} năm`}</span>
                        </p>
                        {/* <p className="expert-information-text-field">
                            <span
                                className="expert-information-info-bold expert-information-info">{'Chức danh trong học viện: '}</span>
                            <span className="expert-information-info">{degree}</span>
                        </p> */}
                        {/* <div className="expert-information-divider"></div> */}
                    </div>
                </div>
                <div className="expert-information-des-header">
                    giới thiệu
                </div>
                <div className="expert-information-container">
                    <ServerUI
                        extraClassName={["expert-information-lecturer-detail-information"]}
                        content={description}>
                    </ServerUI>
                </div>
            </div>

        );
    }

    renderReferenceLecturerView(referenceLecturer) {
        return (
            <div className="expert-reference-lecturer-container">
                <span className="expert-reference-title">{'Giảng viên khác'}</span>
                <div className="expert-reference-list-container">
                    {referenceLecturer.map(
                        (lecturer, index) => {
                            if (index < 5) {
                                return (
                                    <ItemLecturer
                                        lecturer={lecturer}
                                    />
                                )
                            }
                        }
                    )}
                </div>
                <div className="expert-reference-button-container pointer">
                    <span onClick={() => this.props.history.push("/q-expert/lecturers")} className="expert-reference-button-text">
                        {'Xem tất cả giảng viên'}
                    </span>
                    <img src={require('../../../assets/icon/ic_navigate_blue.svg')} />
                </div>
            </div>
        );
    }

    render() {
        // let routes = ['Q-academy', 'Nhà khoa học Dr.Right', 'Giảng viên'];

        return (
            <div>
                {/* <NavigationSubMenu routes={routes} /> */}
                <SectionInner extraClassName={['screen-full-width']}>
                    <div className="expert-container-content-container">
                        {this.renderLecturerInformation()}
                        <div style={{ flex: 1 }} />
                        {this.renderReferenceLecturerView(this.state.referenceLecturer)}
                    </div>
                </SectionInner>
            </div>
        );
    }
}
