import { FETCH_TOP_COURSE } from './QAcademyAction';

export const initState = {
    topCourse: {
        loading: false,
        data: [],
        success: false,
        message: '',
    },
};

export const homeReducer = (state = initState, action) => {
    let newState = { ...state };
    newState['action'] = state.type;

    switch (action.type) {
        case FETCH_TOP_COURSE.LOADING: {
            newState['topCourse'] = {
                loading: true,
                data: [],
                success: false,
                message: ''
            };
            return newState;
        }

        case FETCH_TOP_COURSE.SUCCESS: {
            newState['topCourse'] = {
                loading: false,
                data: action.data,
                success: true,
                message: ''
            };
            return newState;
        }

        case FETCH_TOP_COURSE.ERROR: {
            newState['topCourse'] = {
                loading: false,
                data: [],
                success: false,
                message: ''
            };
            return newState;
        }
    }

    return state;
};
