import React, { Component, useState, useEffect } from 'react';
import './course-detail-screen.css';
import SectionInner from '../../../component/Container/SectionInner';
import CourseDetailBasicInformation from './CourseDetailBasicInformation';
import CourseDetailCourseRecommend from './CourseDetailCourseRecommend';
import CourseDetailImageSlider from './CourseDetailImageSlider';
import CourseDetailRelatedCourse from './CourseDetailRelatedCourse';
import AdviseRegistration from './CourseDetailAdviseRegistration';
import CourseDetailDescription from './CourseDetailDescription';
import CourseDetailSchedule from './CourseDetailSchedule';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';

const SCROLL_STEP = 280;

const RenderCourseDetailLeftView = (props) => {
    let { suggestions } = props;
    const [offset, setOffset] = useState(0);
    useEffect(() => {
        var myElement = document.getElementById('scroll_course');
        myElement.scrollTo({
            left: offset,
            behavior: 'smooth'
        })
    }, [offset])


    return (
        <div className="course-detail-left-view-container">
            <div style={{display: "flex", marginBottom: "9px"}}>
                <span className="course-detail-right-view-title">
                    {'Tất cả khóa học'}
                </span>
                <div style={{marginLeft: "33px"}} className="course-detail-screen-btn-scroll"
                    onClick={() => {
                        if (offset >= SCROLL_STEP) {
                            setOffset(offset - SCROLL_STEP)
                        } else {
                            setOffset(0)
                        }

                    }}>
                    <img src={require("../../../assets/icon/ic_prev_scroll_course.svg")}/>
                </div>
                <div
                    className="course-detail-screen-btn-scroll"
                    onClick={() => {
                        const maxWidthOffset = document.getElementById('scroll_course').scrollWidth - document.getElementById('scroll_course').offsetWidth;
                        if (offset < maxWidthOffset) {
                            let nextOffset = offset + SCROLL_STEP;
                            if (nextOffset >= maxWidthOffset) {
                                setOffset(maxWidthOffset)
                            } else {
                                setOffset(offset + SCROLL_STEP)
                            }
                        }

                    }}>
                    <img src={require("../../../assets/icon/ic_next_scroll_course.svg")}/>

                </div>
            </div>
            <CourseDetailCourseRecommend
                courses={suggestions}
            />
        </div>
    );
}
class QAcademyCourseScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: null,
            suggestions: [],
            courses: 0,
        };
    }

    componentDidMount() {
        console.log('didMount::');
        let { search } = this.props.location;
        let courseId = search.replace('?id=', '');
        this.setState({
            courseId,
        });

        ApiHelper.get(Constants.GET_COURSE_INFORMATION(courseId))
            .then(({ data }) => {
                console.log("Data", data)
                this.setState({
                    data,
                });
            })
            .catch((error) => {

            });

        ApiHelper.get(Constants.GET_SUGGESTION_COURSE(courseId))
            .then(({ data }) => {
                this.setState({
                    suggestions: data,
                });
            })
            .catch((error) => {

            });
        window.scrollTo(0, 0);
    }

    render() {
        let routes = ['Q-academy'];
        let { data } = this.state;
        if (data)
            routes.push(data.title);

        return (
            <div className="course-detail-container">
                {/* <NavigationSubMenu routes={routes} /> */}
                {this.renderCourseSummaryInformationSection()}
                <SectionInner extraClassName={['course-detail-wrap-content']}>
                    <div className="course-detail-main-body">
                        <RenderCourseDetailLeftView suggestions={this.state.suggestions} />
                        <div style={{ flex: 1 }} />
                        {this.renderCourseDetailRightView()}
                    </div>
                </SectionInner>
            </div>
        );
    }



    renderCourseDetailRightView() {
        let { data, suggestions } = this.state;

        return (
            <div className="course-detail-right-view-container">
                {/* description */}
                <CourseDetailDescription
                    data={data}
                />
                {/* schedule */}
                <CourseDetailSchedule
                    data={data}
                />
                <AdviseRegistration
                    data={data}
                />
                <CourseDetailRelatedCourse
                    courses={suggestions}
                />
            </div>
        );
    }

    renderCourseSummaryInformationSection() {
        let { data } = this.state;
        let images = (data) ? data.otherImgUrls : [];
        let title = (data) ? data.title : ""

        return (
            <SectionInner extraClassName={['course-detail-wrap-content']}>
                <div className="course-detail-summary-container">
                    <CourseDetailBasicInformation
                        course={data}
                    />
                    <div>
                        <CourseDetailImageSlider
                            name={title}
                            images={images}
                        />
                    </div>
                </div>
            </SectionInner>
        );
    }
}

export function NavigationSubMenu(props) {
    let { routes } = props;

    let content = [];
    routes.forEach((value, index) => {
        content.push(
            <span
                className={'course-detail-navigation-submenu-title'}
            >
                {value}
            </span>,
        );
        if (index !== routes.length - 1) {
            content.push(
                <span
                    className={'course-detail-navigation-submenu-title'}
                >
                    {'>'}
                </span>,
            );
        }
    });
    return (
        <SectionInner extraClassName={['course-detail-navigation-section-inner']}>
            <div
                className="course-detail-navigation-submenu-container"
            >
                {content}
            </div>
        </SectionInner>
    );
}

export default QAcademyCourseScreen;
