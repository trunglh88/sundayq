import './course-detail-description.css';
import React from 'react';
import { Utils } from '../../../utils';

export default class CourseDetailDescription extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let { data } = this.props;
        let description = data ? data.description : "";
        let imageUrl = data ? data.descriptionImgUrl : "";
        imageUrl = Utils.imageUrl(imageUrl);

        return (
            <div className="course-detail-description-main-flex">
                <div className="course-detail-description-desc">
                    <span className="course-detail-description-desc-title">Mô tả</span>
                    <img className="course-detail-description-img" src={imageUrl} />
                    <span className="course-detail-description-desc-content"
                        dangerouslySetInnerHTML={{__html: description}}
                    ></span>
                </div>
                {/*<div className="course-detail-description-wrap-img">*/}
                {/*    <img className="course-detail-description-img"*/}
                {/*         src={imageUrl} />*/}
                {/*</div>*/}
                <span className="course-detail-description-desc-title-mobile">Mô tả</span>
            </div>
        );
    }

}
