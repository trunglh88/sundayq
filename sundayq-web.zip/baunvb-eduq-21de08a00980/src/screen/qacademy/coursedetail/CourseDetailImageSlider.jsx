import React, { useState } from 'react';
import Slider from 'react-slick';
import './course-detail-image-slider.css';
import { Utils } from '../../../utils';
import { Carousel } from 'react-responsive-carousel';

export default function CourseDetailImageSlider(props) {
    const [center, setCenter] = useState(0);

    let { images = [], name } = props;
    const settings = {
        className: 'course-detail-image-slider',
        // centerMode: true,
        dots: true,
        infinite: true,
        slidesToShow: 1,
        speed: 500,
        nextArrow: <NextArrow />,
        prevArrow: <PrevArrow />,

    };

    let isCenter = (index) => {
        return index === center;
    };
    const ImageSlide = [
        require("../../../assets/image/home_bg_slider.png"),
        require("../../../assets/image/home_bg_slider.png"),
        require("../../../assets/image/home_bg_slider.png"),
        require("../../../assets/image/home_bg_slider.png"),
        require("../../../assets/image/home_bg_slider.png"),
        require("../../../assets/image/home_bg_slider.png"),
      
      ]
    return (
        <div className="course-detail-image-slider-container">
            <div className="course-detail-course-main-title">
                <span>
                    {name}
                </span>
            </div>

            <div >
                {/* <Slider
                    afterChange={(index) => {
                        setCenter(index);
                    }}
                    {...settings}>
                    {images.map((image, index) => (
                        <div
                            className={`course-detail-image-container`}
                        >
                            <img
                                className={`course-detail-image-slider-item`}
                                alt="Slide image"
                                src={Utils.imageUrl(image)}
                            />
                            
                        </div>
                    ))}
                </Slider> */}

                <Carousel
                    showThumbs={false}
                    showStatus={false}
                    autoPlay={true}
                    interval={3000}
                    infiniteLoop={true}
                >
                    {
                        images.map((image) => {
                            return (
                                <div className="course-detail-image-container">
                                    <img className="course-detail-image-slider-item" src={Utils.imageUrl(image)} />
                                </div>
                            )
                        })
                    }
                </Carousel>
            </div>
        </div>
    );
}

function PrevArrow(props) {
    const { onClick } = props;
    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-left-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={require('../../../assets/icon/ic_prev_arrow.png')}
            />
        </div>
    );
}

function NextArrow(props) {
    const { onClick } = props;
    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-right-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={require('../../../assets/icon/ic_next_arrow.png')}
            />

        </div>
    );
}
