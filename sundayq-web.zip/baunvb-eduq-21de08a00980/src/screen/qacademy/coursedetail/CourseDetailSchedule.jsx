import './course-detail-schedule.css';
import React, { useState } from 'react';

const tableData = [
    {
        number: 'Buổi 1',
        content: 'Dao động điều hoà',
        time: '9:30 am',
        teacher: 'Nguyễn Văn A',
        support: 'Nguyễn Văn B',
    },
    {
        number: 'Buổi 2',
        content: 'Tổng hợp hai giao động điều hoà cùng phương, cùng tần số. Phương pháp giản đồ Fre-nen',
        time: '9:30 am',
        teacher: 'Nguyễn Văn A',
        support: 'Nguyễn Văn B',
    },

];

export function LecturerNameField(props) {
    let { lecturer } = props;
    
    const [mouseEnter, setMouseEnter] = useState(false);

    let className = 'course-detail-schedule-pointer-cursor';
    className = `${className} ${(mouseEnter) ? 'course-detail-lecturer-name-field' : ''}`;

    return (
        <span
            onClick={() => {
                window.location.href=`/q-expert?id=${lecturer.id}`;
            }}
            onMouseEnter={() => setMouseEnter(true)}
            onMouseLeave={() => setMouseEnter(false)}
            className={className}
        >
            {lecturer ? lecturer.name : ''}
        </span>
    );
}

export default class CourseDetailSchedule extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let { data } = this.props;
        let tableData = [];
        if (data && data.coursePlans)
            tableData = data.coursePlans;

        return (
            <div>
                <span className="course-detail-schedule-title">Lộ trình khóa học</span>
                <table class="course-detail-schedule-table">
                    <tr className="course-detail-schedule-full-width">
                        <th className="course-detail-schedule-th">{'Buổi'.toUpperCase()}</th>
                        <th>{'Nội dung'.toUpperCase()}</th>
                        <th>{'Thời gian'.toUpperCase()}</th>
                        <th>{'Giảng viên'.toUpperCase()}</th>
                        <th>{'Trợ giảng'.toUpperCase()}</th>

                    </tr>
                    {
                        tableData.map((item, key) => {
                            return (
                                <tr key={key}>
                                    <td className="course-detail-schedule-th">{`Buổi ${(item.dayIndex + 1)}`}</td>
                                    <td>{item.title}</td>
                                    <td>{item.time}</td>
                                    <td>
                                        <span>
                                            <LecturerNameField lecturer={item.teacher} />
                                            {/*{item.teacher.name}*/}
                                        </span>
                                    </td>
                                    <td>{(item.supporter) ? item.supporter.name : ''}</td>
                                </tr>
                            );
                        })
                    }


                </table>
               
            </div>


        );
    }

}
