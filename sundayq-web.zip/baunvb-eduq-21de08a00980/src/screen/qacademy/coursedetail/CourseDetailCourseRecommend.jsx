import * as React from 'react';
import { useState } from 'react';
import { useSelector } from 'react-redux';

export default function CourseDetailCourseRecommend(props) {
    // let { courseId } = props;
    // let courses = useSelector(state => state.homeReducer.topCourse.data);
    // courses = courses.filter(course => course.id !== courseId);
    let { courses } = props;
    return (
        <div className="course-detail-reference-course-list-container" id="scroll_course">
           
            {courses.map((course, index) => (
                <RecommendCourse
                    index={index}
                    course={course}
                />
            ))}
            <div style={{padding: "4px"}}></div>
        </div>

    );
}

const getColor = (index) => {
    return 'standard'
    // switch (index % 4) {
    //     case 0:
    //         return 'blue';
    //     case 1:
    //         return 'red';
    //     case 2:
    //         return 'green';
    //     default:
    //         return 'purple';
    // }
};

export function RecommendCourse(props) {

    const [mouseEnter, setMouseEnter] = useState(false);

    let { course, index } = props;
    // let headerTextColor = `course-name-${getColor(index)}`;
    let headerTextColor = "";

    let containerBorder = !mouseEnter ? 'course-detail-reference-course-container-border-standard'
        : `course-detail-reference-course-container-border-${getColor(index)}`;

    return (
        <div
            onClick={() => window.location.assign('/q-academy/course?id=' + course.id)}
            onMouseEnter={() => {
                setMouseEnter(true);
            }}
            onMouseLeave={() => {
                setMouseEnter(false);
            }}
            className={`course-detail-reference-course-container ${containerBorder}`}>
            <div className="course-detail-reference-course-header">
                <span
                    className={`course-detail-reference-course-name ${headerTextColor}`}
                >
                    {course.title}
                </span>
                {/* <img
                    className="course-detail-reference-course-option-menu"
                    src={require('../../../assets/icon/ic_option_menu.png')}
                    alt="option"
                /> */}
            </div>
            <div>
                {/* <img
                    className="course-detail-reference-course-icon"
                    src={require('../../../assets/icon/ic_calendar.png')}
                    alt="calendar icon"
                /> */}
                <span
                    className="course-detail-reference-course-detail-text"
                >
                    {course.courseLength}
                </span>
                <img
                    className="course-detail-reference-course-icon course-detail-info-separate"
                    src={require('../../../assets/icon/ic_age_range.png')}
                    alt="calendar icon"
                />
                <span
                    className="course-detail-reference-course-detail-text"
                >
                    {`${course.minTargetAge} - ${course.maxTargetAge} tuổi`}
                </span>
            </div>
            <div className="course-detail-reference-course-method-container">
                <span className="course-detail-lecturer-text-span-label text-bold">{'Hình thức: '}</span>
                <span className="course-detail-lecturer-text-span">{course.courseType}</span>
            </div>
        </div>
    );
}
