import * as React from 'react';
import { useState } from 'react';
import { Utils } from '../../../../../utils';
import { NavLink } from 'react-router-dom';
import moment from 'moment';

export default function LecturerInformation(props) {
    const [mouseEnter, setMouseEnter] = useState(false);
    let teacher  = props.lecturer;

    console.log("teacher::", teacher);

    //use hover instead of mouse event
    let containerClassName = `course-detail-lecturer-information-container`
    let practiceAt = moment(teacher.practiceAt);
    let current = moment();
    let yearDiff = (current.diff(practiceAt, 'year') + 1) || 0;

    return (
        <a
            href={`/q-expert?id=${teacher.id}`}
            // onMouseEnter={() => setMouseEnter(true)}
            // onMouseLeave={() => setMouseEnter(false)}
            className={containerClassName}>
            <img
                alt="Lecturer img"
                src={Utils.imageUrl(teacher.imgUrl)}
                className="course-detail-lecturer-image"
            />
            <div>
                <p className="course-detail-lecturer-text course-detail-lecturer-name">
                    {teacher.name}
                </p>
                <p
                    className="course-detail-lecturer-text-span text-italic course-detail-lecturer-workplace">
                    {teacher.university}
                </p>
                <div>
                    <span className="course-detail-lecturer-text-span text-bold">{'Chuyên khoa: '}</span>
                    <span className="course-detail-lecturer-text-span">{teacher.specialist}</span>
                </div>
                <div>
                    <span className="course-detail-lecturer-text-span text-bold">{'Kinh nghiệm giảng dạy: '}</span>
                    <span className="course-detail-lecturer-text-span">{`${yearDiff} năm`}</span>
                </div>
            </div>
        </a>
    );
}
