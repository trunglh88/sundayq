import React, { useState } from 'react';
import './couse-detail-advise-registration.css';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';
import SweetAlert from 'react-bootstrap-sweetalert';
export default function AdviseRegistration(props) {
    const { data } = props;
    const [alert, setAlert] = useState(null);
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [note, setNote] = useState('');

    let submitRegistrationForm = () => {
        let requestData = {
            name,
            email,
            phone,
            note
        };

        ApiHelper.post(Constants.REGISTER_ADVICE(data.id), requestData)
            .then(({ data }) => {
                setAlert(
                    <SweetAlert
                        success
                        title="Thành công"
                        confirmBtnCssClass="advise-registration-submit-button"
                        onConfirm={() => setAlert(null)}
                    >
                        Bạn đã ký nhận tư vấn khóa học thành công
                    </SweetAlert>
                )
                setName('');
                setPhone('');
                setEmail('');
                setNote('');
            })
            .catch((error) => {
                console.log("error::", error);
                setAlert(
                    <SweetAlert
                        error
                        title="Không thành công"
                        confirmBtnCssClass="advise-registration-submit-button"
                        onConfirm={() => setAlert(null)}
                    >
                        Quý khách vui lòng cung cấp lại thông tin để nhận được tư vấn
                    </SweetAlert>
                )
            });
    }

    let submitButtonEnable = (name && phone);

    return (
        <div className="advise-registration-container">
            {alert}
            <div className="advise-registration-body-container">
                <div className="advise-registration-form-container">
                    <span className="course-detail-right-view-title">{'Đăng ký nhận tư vấn'}</span>
                    <p className="advise-registration-subtitle">
                        {'Nhân viên tư vấn của chúng tôi sẽ gọi lại trong vòng 3 giờ đồng hồ'}
                    </p>
                    <input
                        className="advise-registration-input advise-registration-parent-name"
                        placeholder={'Họ và tên bố/ mẹ'}
                        type={'text'}
                        onChange={(event) => {
                            setName(event.target.value);
                        }}
                        value={name}
                    />
                    <input
                        className="advise-registration-input"
                        placeholder={'Số điện thoại'}
                        type={'text'}
                        onChange={(event) => {
                            setPhone(event.target.value);
                        }}
                        value={phone}
                    />
                    <input
                        className="advise-registration-input"
                        placeholder={'E-mail (không bắt buộc)'}
                        type={'text'}
                        onChange={(event) => {
                            setEmail(event.target.value);
                        }}
                        value={email}
                    />
                    <textarea
                        className="advise-registration-input advise-registration-note"
                        placeholder={'Ghi chú khác (không bắt buộc)'}
                        onChange={(event) => {
                            setNote(event.target.value);
                        }}
                        value={note}
                    />
                    <div className="advise-registration-submit-button-container">
                        <div
                            onClick={submitRegistrationForm}
                            className={`advise-registration-submit-button${submitButtonEnable ? '' : ' advise-registration-submit-button-disabled'}`}>
                            <span className="advise-registration-submit-button-text">
                                {'Gửi'}
                            </span>
                        </div>
                    </div>
                </div>
                <img
                    className="advise-registration-image"
                    src={require('../../../assets/icon/bg_advise_registration.png')}
                    alt='advise registration'
                />
            </div>
        </div>
    );
}
