import Slider from 'react-slick';
import React from 'react';
import { NextArrow, PrevArrow } from '../../../component/Slider/Arrows';
import './course-detail-related.css';
import { useSelector } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { Utils } from '../../../utils';

export default function RelatedCourse(props) {

    const settings = {
        className: 'course-related-slider-container',
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        nextArrow: <NextArrow />,
        prevArrow: <PrevArrow />,
        responsive: [
            {
                breakpoint: 480,
                settings: {
                    centerMode: false,
                    slidesToShow: 1.5,
                    slidesToScroll: 1,
                },
            },
        ],
    };

    // let { courseId } = props;
    // let courses = useSelector(state => state.homeReducer.topCourse.data);
    // courses = courses.filter(course => course.id !== courseId);
    let { courses } = props;
    return (
        <div className="related-course-container">
            <span
                className="course-detail-right-view-title related-course-title"
            >
                Khóa học liên quan
            </span>
            <Slider
                {...settings}
            >
                {
                    courses.map((item, index) => (
                        <Course
                            item={item}
                        />
                    ))
                }
            </Slider>
        </div>
    );
}

export function Course(props) {
    let { item } = props;
    let { title, shortDescription, id, descriptionImgUrl } = item;
    return (
        <div className="course-detail-related-card-container"
            onClick={() => window.location.assign('/q-academy/course?id=' + id)}
        >
            <div
                className="course-detail-related-card"
            >
                <div className="course-detail-related-card-content-container">
                    <img
                        alt="img"
                        className="course-detail-related-image"
                        src={Utils.imageUrl(descriptionImgUrl)}
                    />

                    <div className="course-detail-related-card-content">
                        <span
                            className="q-academy-club-card-content-title"
                        >
                            {title}
                        </span>
                        <span
                            className="course-detail-related-card-description"
                        >
                            {shortDescription}
                        </span>
                        <div className="course-detail-related-card-button-container">
                            <NavLink
                                to={`/q-academy/course?id=${id}`}
                                className="course-detail-related-card-button">
                                <img
                                    alt="click me"
                                    className="course-detail-related-card-button-image"
                                    src={require('../../../assets/icon/arrow_course_navigate.svg')}
                                />
                            </NavLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
