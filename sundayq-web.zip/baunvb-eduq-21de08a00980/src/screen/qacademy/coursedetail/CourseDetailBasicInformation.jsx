import React from 'react';
import { Constants } from '../../../utils/index'
import LecturerList from './CourseDetailLecturerInformation';
export default function BasicInformation(props) {
    let { course } = props;
    let title = (course) ? course.title : "";
    let minAge = (course) ? course.minTargetAge : 0;
    let maxAge = (course) ? course.maxTargetAge : 0;
    let courseType = (course) ? course.courseType : "";

    return (
        <div className="course-detail-basic-information">
            <div className="course-detail-teacher-info-wrap">
                <LecturerList
                    data={course}
                />
            </div>
            <div className="course-detail-course-info-wrap">
                <div className="course-detail-title-and-content-group-container">
                    <span className="course-detail-basic-information-subtitle">{'Thông tin khóa học'}</span>

                    <BasicInformationTitleAndContent
                        title="Tên khóa học:"
                        content={title}
                    />
                    <BasicInformationTitleAndContent
                        title="Độ tuổi:"
                        content={`Từ ${minAge} đến ${maxAge} tuổi`}
                    />
                    <BasicInformationTitleAndContent
                        title="Loại hình:"
                        content={courseType}
                    />
                </div>
                <div style={{ width: "8px", height: "8px" }}></div>
                <div className="course-detail-basic-info-wrap">
                    <span className="course-detail-basic-information-subtitle">{'Thông tin đăng ký khóa học'}</span>

                    <BasicInformationIconAndContent
                        icon={require('../../../assets/icon/ic_website.png')}
                        content="http://sundayq.com"
                    />

                    <BasicInformationIconAndContent
                        icon={require('../../../assets/icon/ic_email.png')}
                        content={Constants.COMPANY_PROFILE.EMAIL}
                    />

                    <div className="course-detail-basic-information-icon-and-content-container">
                        <img alt="icon" src={require('../../../assets/icon/ic_facebook.png')} className="course-detail-basic-information-icon" />
                        <a href={Constants.COMPANY_PROFILE.FB} className="course-detail-basic-information-content">Sunday Questacon</a>
                    </div>

                    <BasicInformationIconAndContent
                        icon={require('../../../assets/icon/ic_location.png')}
                        content={Constants.COMPANY_PROFILE.ADDRESS}
                    />
                    <hr/>
                    <div>
                        <div className="course-detail-basic-information-call-button">
                            <img
                                className="course-detail-basic-information-call-button-icon"
                                alt="call-icon"
                                src={require('../../../assets/icon/ic_call.png')}
                            />
                            <a
                                href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_CS}`}
                                className="course-detail-basic-information-call-button-text"
                            >
                                Dịch vụ: <span style={{fontWeight: "normal"}}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</span>

                            </a>
                        </div>
                        <div className="course-detail-basic-information-call-button">
                            <img
                                className="course-detail-basic-information-call-button-icon"
                                alt="call-icon"
                                src={require('../../../assets/icon/ic_call.png')}
                            />
                            <a
                                href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_BIZ}`}
                                className="course-detail-basic-information-call-button-text"
                            >
                                Kinh doanh: <span style={{fontWeight: "normal"}}>{Constants.COMPANY_PROFILE.HOTLINE_BIZ}</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    );
}

export function BasicInformationTitleAndContent(props) {
    let { title, content } = props;
    return (
        <div className="course-detail-basic-information-title-and-content-container">
            <span className="course-detail-basic-information-title">{title}</span>
            <span className="course-detail-basic-information-content">{content}</span>
        </div>
    );
}

export function BasicInformationIconAndContent(props) {
    let { icon, content } = props;
    return (
        <div className="course-detail-basic-information-icon-and-content-container">
            <img alt="icon" src={icon} className="course-detail-basic-information-icon" />
            <span className="course-detail-basic-information-content">{content}</span>
        </div>
    );
}
