import * as React from 'react';
import LecturerInformation from './components/lecturercard';

export default function LecturerList(props) {
    let { data } = props;
    let lecturers = [];
    if (data && data.owners)
        lecturers = data.owners;

    return (
        <div className="course-detail-lecturer-list-container">
            <span style={{marginBottom: "17px"}} className="course-detail-lecturer-information-label">
                {'Thông tin chủ nhiệm'}
            </span>
            {lecturers.map((lecturer) => (
                <LecturerInformation
                    lecturer={lecturer.teacher}
                />
            ))}
        </div>
    );
}
