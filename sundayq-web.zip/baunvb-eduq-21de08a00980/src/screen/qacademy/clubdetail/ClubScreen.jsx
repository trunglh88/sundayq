import React from 'react'
import SectionInner from '../../../component/Container/SectionInner';
import './q-club-screen.css';
import { NavigationSubMenu } from '../coursedetail/CourseDetailScreen';
import { colors } from 'material-ui/styles';
import { SunQClubData } from '../../../assets/data/SunQClub';

// import { Member } from './ClubHtml'
const COLORS = ["#FFC60A", "#FFC60A", "#0FAB4B", "#D12700", "#7024C4", "#035AA6",];
const IMAGES = [
    require("../../../assets/icon/club1.svg"),
    require("../../../assets/icon/club2.svg"),
    require("../../../assets/icon/club3.svg"),
    require("../../../assets/icon/club4.svg"),
    require("../../../assets/icon/club5.svg"),
    require("../../../assets/icon/club6.svg"),
]

function ClubItem(props) {
    return (
        <div style={{ transform: props.isActive ? "scale(1.1)" : "scale(0.97)" }} className="q-club-screen-item"
            onClick={() => window.location.assign('/q-academy/club?id=' + props.id)}
        >
            {
                !props.isActive ? <div className="q-club-screen-item-dim"></div> : null
            }

            <div style={{backgroundImage: `url(${props.image})`}} className="q-club-screen-item-wrap-img">

            </div>
            <div className="q-club-screen-item-wrap-title">
                <span style={{ color: props.color }} className="q-club-screen-item-title">{props.title}</span>
            </div>
        </div>
    )
}
class ClubScreen extends React.Component {
    render() {
        let routes = ['Q-academy', 'Câu lạc bộ sundayq'];
        let { search } = this.props.location;
        console.log("xxx", search)
        // let clubId = search.replace('?id=', '');
        const params = new URLSearchParams(search);
        const clubId = params.get('id');
        const dialog = params.get('dialog')
        console.log("xxxx", dialog)
        let activeItemIndex = SunQClubData.findIndex(item => item.id == clubId);
        return (
            <div>
                {
                    dialog == 1 ? <div className="q-club-screen-policy-container">
                        <SectionInner extraClassName={['q-club-screen-mobile-full-width-dialog']}>
                            <div className="q-club-screen-policy-dialog">
                                <div className="q-club-screen-dialog-content">
                                    <img
                                        onClick={() => window.location.assign('/q-academy/club?id=' + clubId)}
                                        className="q-club-screen-dialog-content-ic-close" src={require('../../../assets/icon/icon_close.svg')} />
                                    <span className="q-club-screen-dialog-title">Chính sách & bảo mật</span>
                                    <div className="q-club-screen-scroll-content-wrap"
                                        dangerouslySetInnerHTML={{ __html: SunQClubData[0].content }}>
                                    </div>
                                </div>
                            </div>
                        </SectionInner>
                    </div> : null
                }
                <NavigationSubMenu routes={routes} />
                <SectionInner
                    extraClassName={['q-club-screen-mobile-full-width']}
                >
                    <div className="q-club-screen-content-section"

                    >
                        <div className="q-club-screen-content-title-wrap">
                            <span className="q-club-screen-content-title">{SunQClubData[activeItemIndex].title}</span>

                        </div>
                        <div className="q-club-screen-content"
                            dangerouslySetInnerHTML={{ __html: SunQClubData[activeItemIndex].content }}>

                        </div>

                    </div>

                </SectionInner>
                <SectionInner>
                    <div className="q-club-screen-wrap-footer-item">
                        {
                            SunQClubData.map((item, index) => {
                                return (
                                    <ClubItem
                                        title={item.title}
                                        color={COLORS[index]}
                                        image={IMAGES[index]}
                                        isActive={clubId == item.id}
                                        id={item.id}
                                    />
                                )
                            })
                        }
                    </div>
                </SectionInner>
            </div>

        )
    }
}

export default ClubScreen;
