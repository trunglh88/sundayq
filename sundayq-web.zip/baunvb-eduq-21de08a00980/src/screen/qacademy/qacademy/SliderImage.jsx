import React from 'react';
import 'react-responsive-carousel/lib/styles/carousel.min.css'; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import SectionInner from '../../../component/Container/SectionInner';
import './q-academy-slider.css';

const ImageSlide = [
    require("../../../assets/image/qacademy_panel_1.JPG"),
    require("../../../assets/image/qacademy_panel_2.JPG"),
    require("../../../assets/image/qacademy_panel_3.JPG"),
    require("../../../assets/image/qacademy_panel_4.JPG"),
    require("../../../assets/image/qacademy_panel_5.JPG"),
    require("../../../assets/image/qacademy_panel_6.JPG"),
  
  ]
export default class SliderImage extends React.Component {

    render() {
        return (
            <div className="q-academy-slider-main">
                <SectionInner extraClassName={['home-screen-wrap-slider', 'home-screen-full-width']}>
                    <Carousel
                        showThumbs={false}
                        showStatus={false}
                        autoPlay={true}
                        interval={3000}
                        infiniteLoop={true}
                    >
                        {
                            ImageSlide.map((item) => {
                                return (
                                    <div>
                                        <img src={item} />
                                        {/* <p className="legend"></p> */}
                                    </div>
                                )
                            })
                        }
                    </Carousel>
                </SectionInner>
            </div>

        );
    }
}
