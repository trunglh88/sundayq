import React, { useEffect, useState } from 'react';
import SectionInner from '../../../component/Container/SectionInner';
import { SunQPricingData } from '../../../assets/data/SunQPricing';
import './q-academy-course.css';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants, Utils } from '../../../utils';
import Pagination from '@material-ui/lab/Pagination';
const ITEM_PER_PAGE = 8;

export default function QAcademyCourse(props) {
    const [pageIndex, setPageIndex] = useState(1);

    let data = props.course;

    let listCourseShowed = data.slice((pageIndex - 1) * ITEM_PER_PAGE, pageIndex * ITEM_PER_PAGE);
    if(listCourseShowed.length < ITEM_PER_PAGE && pageIndex > 1) {
        let maxIndexPrevPage = (pageIndex - 1) * ITEM_PER_PAGE - 1;
        while(listCourseShowed.length < ITEM_PER_PAGE) {
            listCourseShowed.unshift(data[maxIndexPrevPage]);
            maxIndexPrevPage--;
        }

    }

    return (
        <SectionInner extraClassName={['q-academy-course-container', 'screen-full-width']}>
            <div className="q-academy-course-header-container">
                <div className="q-academy-course-header-title-container">
                    <span className="q-academy-course-header-title">Khóa học</span>
                    {/* <span className="q-academy-course-header-des">
                        People of all ages will engage with science in extraordinary ways with over 200 hands-on exhibits in eight interactive galleries, as well as foyer and outdoor Science Garden experiences.
                    </span> */}
                </div>
            </div>
            <div className="q-academy-course-body-container">
                {
                    listCourseShowed.map((item, key) => {
                        return (
                            <div className="qacademy-home-screen-item">
                                <a href={`/q-academy/course?id=${item.id}`} className="item-course-main box-hover">
                                    <div className="item-course-main-content">
                                        <span className="item-course-title">{item.title}</span>
                                        <img className="item-course-img" src={Utils.imageUrl(item.descriptionImgUrl)} />
                                        <span className="item-course-excerpt">
                                            {item.shortDescription}
                                        </span>
                                    </div>

                                    <div className="item-course-footer">
                                        <div className="item-course-footer-left">
                                            <img className="item-course-footer-icon" src={require("../../../assets/icon/ic_footer_tour_item.svg")} />
                                            <span className="item-course-footer-age">{item.minTargetAge} - {item.maxTargetAge} tuổi</span>
                                        </div>
                                        <div className="item-course-footer-right">
                                            <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
                                        </div>
                                    </div>
                                </a>
                            </div>
                        );
                    })
                }
            </div>
            <div className="qacademy-course-page-navigation">
                <Pagination
                    classes={{ ul: "lecturer-list-wrap-page-index" }}
                    onChange={(event, page) => setPageIndex(page)}
                    count={Math.ceil(data.length / ITEM_PER_PAGE)}
                    variant="outlined"
                    shape="rounded"
                />
            </div>
        </SectionInner>
    );
}
