import React from 'react';
import './q-academy-pricing.css';
import { Constants } from '../../../utils/index'
import SectionInner from '../../../component/Container/SectionInner';
import { SunQPricingData } from '../../../assets/data/SunQPricing';

export default class QAcademyPricing extends React.Component {
    render() {
        return (
            <div className="q-academy-pricing-main">
                <SectionInner>
                    <div className="q-academy-pricing-wrap-info">
                        <div className="q-academy-pricing-wrap-info-column q-academy-pricing-column-about-us">
                            <span className="q-academy-pricing-header-title">
                                Về chúng tôi
                            </span>
                            <span className="q-academy-pricing-info-title">Giờ mở cửa</span>
                            <span className="q-academy-pricing-info-detail">Từ 8h sáng đến 20h tối</span>
                            <hr />
                            <span className="q-academy-pricing-info-title">Chúng tôi ở</span>
                            <span className="q-academy-pricing-info-detail">{Constants.COMPANY_PROFILE.ADDRESS}</span>
                            <hr />
                            <div className="q-academy-pricing-break-line">
                                <span className="q-academy-pricing-info-title">Liên lạc</span>
                                <div className="q-academy-pricing-contact-item-container">
                                    <img
                                        className="q-academy-pricing-contact-item-icon"
                                        alt="Contact icon"
                                        src={require("../../../assets/icon/ic_contact_rounded.png")}
                                    />
                                    <span className="q-academy-pricing-info-detail-label">Dịch vụ: </span>
                                    <a
                                        href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_CS}`}
                                        className="q-academy-pricing-info-detail">{Constants.COMPANY_PROFILE.HOTLINE_CS}</a> <br />
                                </div>
                                <div className="q-academy-pricing-contact-item-container">
                                    <img
                                        className="q-academy-pricing-contact-item-icon"
                                        alt="Contact icon"
                                        src={require("../../../assets/icon/ic_contact_rounded.png")}
                                    />
                                    <span className="q-academy-pricing-info-detail-label">Kinh Doanh:</span>
                                    <a href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_BIZ}`} className="q-academy-pricing-info-detail">{Constants.COMPANY_PROFILE.HOTLINE_BIZ}</a> <br />
                                </div>
                                <div className="q-academy-pricing-contact-item-container">
                                    <img
                                        className="q-academy-pricing-contact-item-icon"
                                        alt="Facebook icon"
                                        src={require("../../../assets/icon/ic_facebook_rounded.png")}
                                    />
                                    <a href={Constants.COMPANY_PROFILE.FB} className="q-academy-pricing-info-detail">{Constants.COMPANY_PROFILE.FB}</a>
                                </div>
                            </div>
                        </div>
                        <div className="q-academy-pricing-wrap-info-column q-academy-pricing-column-price">
                            <span className="q-academy-pricing-header-title">Giá vé</span>
                            <div className="q-academy-pricing-item-price">
                                <span className="q-academy-pricing-info-detail q-academy-pricing-left">Người lớn</span>
                                <span
                                    className="q-academy-pricing-info-detail q-academy-pricing-right">80.000/buổi</span>
                            </div>
                            <hr />
                            <div className="q-academy-pricing-item-price">
                                <span className="q-academy-pricing-info-detail q-academy-pricing-left">Trẻ em</span>
                                <span
                                    className="q-academy-pricing-info-detail q-academy-pricing-right">120.000/buổi</span>
                            </div>
                            <hr />
                            <div className="q-academy-pricing-item-price">
                                <span className="q-academy-pricing-info-detail q-academy-pricing-left">Gia đình (2 người lớn, 2 trẻ em)</span>
                                <span
                                    className="q-academy-pricing-info-detail q-academy-pricing-right">200.000/buổi</span>
                            </div>
                            <hr />

                            <div className="q-academy-pricing-item-price">
                                <span className="q-academy-pricing-info-detail q-academy-pricing-left">Thành viên</span>
                                <span className="q-academy-pricing-info-detail q-academy-pricing-right">Giảm 20%</span>
                            </div>
                            <hr />
                            <div className="q-academy-pricing-item-price">
                                <span className="q-academy-pricing-info-detail q-academy-pricing-left">Giá khóa học và Workshop</span>
                                <span className="q-academy-pricing-info-detail q-academy-pricing-right">Xem chi tiết từng khóa học</span>
                            </div>
                            <hr />
                        </div>
                    </div>
                </SectionInner>
            </div>
        );
    }
}
