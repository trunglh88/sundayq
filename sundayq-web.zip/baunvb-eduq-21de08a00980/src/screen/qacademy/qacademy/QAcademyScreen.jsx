import React from 'react';
import QAcademyClub from './QAcademyClub';
import QAcademyPricing from './QAcademyPricing';
import SliderImage from './SliderImage';
import QAcademyCourse from './QAcademyCourse';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';
import { fetchTopCourse } from '../QAcademyAction';
import { connect } from 'react-redux';

  
class QAcademyScreen extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount(){
        this.props.fetchTopCourse();
    }

    render() {
        return (
            <div>
                <SliderImage />
                {/* <QAcademyPricing /> */}
                <QAcademyCourse
                    course={this.props.topCourse}
                />
                
                {/* <QAcademyClub /> */}
            </div>
        );
    }

}

// export default QAcademyScreen;

const mapStateToProps = state => {
    return {
        topCourse: state.homeReducer.topCourse.data,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        fetchTopCourse: () => {
            dispatch(fetchTopCourse());
        },
    };
};

QAcademyScreen = connect(mapStateToProps, mapDispatchToProps)(QAcademyScreen);
export default QAcademyScreen;
