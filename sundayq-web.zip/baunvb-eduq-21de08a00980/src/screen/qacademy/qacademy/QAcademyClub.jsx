import React from 'react';
import './q-academy-club.css';
import SectionInner from '../../../component/Container/SectionInner';
import { SunQClubData } from '../../../assets/data/SunQClub';
import Slider from 'react-slick';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants, Utils } from '../../../utils';
import { NavLink } from 'react-router-dom';

function SamplePrevArrow(props) {
    const { onClick } = props;
    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-left-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={require('../../../assets/icon/ic_prev_arrow.png')}
            />
        </div>
    );
}

function SampleNextArrow(props) {
    const { onClick } = props;
    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-right-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={require('../../../assets/icon/ic_next_arrow.png')}
            />
        </div>
    );
}

export default class QAcademyClub extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            centeredIndex: 0,
        };
    }

    render() {
        let { data } = this.state;
        const settings = {
            dots: true,
            autoplaySpeed: 2000,
            className: 'q-academy-club-slider-container',
            centerMode: true,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            nextArrow: <SampleNextArrow />,
            prevArrow: <SamplePrevArrow />,
            responsive: [
                {
                    breakpoint: 480,
                    settings: {
                        centerMode: false,
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    },
                },
            ],
        };
        let { centeredIndex } = this.state;

        return (
            <div>
                <div className="q-academy-club-header-container">
                    <div className="q-academy-club-header-title-container">
                        <span className="q-academy-club-header-title roboto-slab">Câu lạc bộ SUNDAYQ</span>
                    </div>
                </div>
                {/* slider */}
                <div className="q-academy-club-main">
                    <SectionInner extraClassName={['q-academy-club-container']}>

                        <div>
                            <Slider
                                {...settings}
                                beforeChange={(oldIndex, newIndex) => {
                                    this.setState({
                                        centeredIndex: newIndex,
                                    });
                                }}
                            >
                                {
                                    SunQClubData.map((item, index) => (
                                        <ClubCard
                                            centered={index === centeredIndex}
                                            index={index}
                                            item={item}
                                        />
                                    ))
                                }
                            </Slider>
                        </div>
                    </SectionInner>
                </div>
                {/* content coresponding active slide */}
                <SectionInner>
                    <p className="q-academy-club-detail-content">
                        {(centeredIndex === -1) ? '' : SunQClubData[centeredIndex].excerpt}
                    </p>
                </SectionInner>
            </div>
        );
    }
}

export function ClubCard(props) {
    let { centered } = props;
    let { title, excerpt, featured_image, id } = props.item;

    let classNameTailed = (centered) ? '-centered' : '';

    return (
        <div className="q-academy-club-card-container"
            onClick={() => window.location.assign('/q-academy/club?id=' + id)}
        >
            <div
                className={'q-academy-club-card'.concat(classNameTailed)}
            >
                <div className="box-hover q-academy-club-card-content-container">
                    <div
                        className={'q-academy-club-card-image'.concat(classNameTailed)}
                        style={{backgroundImage: `url(${featured_image})`}}
                    ></div>

                    <div className="q-academy-course-body-list-item-content-container">
                        <span
                            className={'q-academy-club-card-content-title'.concat(classNameTailed)}
                        >
                            {title}
                        </span>
                        <span
                            className={'q-academy-club-card-content-text'.concat(classNameTailed)}
                        >
                            {excerpt}
                        </span>
                        <div className="q-academy-club-card-detail-button-container">
                            <div className="q-academy-club-card-detail-button">
                            <svg width="20" height="15" viewBox="0 0 30 23" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M29.9 10.8416C29.8345 10.6844 29.7428 10.5271 29.6118 10.4092L19.9814 0.791941C19.4704 0.280942 18.6318 0.280942 18.1077 0.791941C17.5967 1.30294 17.5967 2.1415 18.1077 2.66561L25.4714 10.0292H1.32336C0.589615 10.0292 0 10.6189 0 11.3526C0 12.0863 0.589615 12.676 1.32336 12.676H25.4845L18.1208 20.0396C17.6098 20.5506 17.6098 21.3892 18.1208 21.9133C18.6318 22.4243 19.4704 22.4243 19.9945 21.9133L29.6249 12.2829C29.7428 12.165 29.8476 12.0208 29.9131 11.8505C30.0311 11.536 30.0311 11.1692 29.9 10.8416Z" />
</svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
