import { createActionSet } from '../../services/actions';

export const FETCH_TOP_COURSE = createActionSet('FETCH_TOP_COURSE');

export const fetchTopCourse = () => ({
    type: FETCH_TOP_COURSE.actionName,
});
