import { put, takeLatest } from 'redux-saga/effects';
import { FETCH_TOP_COURSE } from './QAcademyAction';
import { ApiHelper } from '../../services/apis/ApiHelper';
import { Constants } from '../../utils';

function* fetchTopCourse(action) {
    try {
        yield put({type: FETCH_TOP_COURSE.LOADING});
        let { data } = yield ApiHelper.get(Constants.GET_TOP_COURSE);
        yield put({type: FETCH_TOP_COURSE.SUCCESS, data});
    } catch (e) {
        yield put({type: FETCH_TOP_COURSE.ERROR, error: e});
    }
}

function* watchHomeData() {
    yield takeLatest(FETCH_TOP_COURSE.actionName, fetchTopCourse);
}

export default watchHomeData;
