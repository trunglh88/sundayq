import React, { useState, useEffect } from 'react'
import "./register.css"
import Input from "../../../component/Input/Input"
import { Utils, Constants } from "../../../utils"
import RegisterConfirm from "./RegisterConfirm"
import { ApiHelper } from '../../../services/apis/ApiHelper';
export default function RegisterForm(props) {
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [enable, setEnable] = useState(false);
  const [isComplete, setComplete] = useState(false);
  const [message, setMessage] = useState("Email da ton tai");
  const [messageEmail, setMsgEmail] = useState("");
  const [messageName, setMsgName] = useState("");
  const [messagePhone, setMsgPhone] = useState("");
  const [messagePassword, setMsgPassword] = useState("");

  useEffect(() => {
    setMessage("");
    formValidation();
  }, [name, phone, email, password])

  const onSubmit = (e) => {
    if (enable) {
      console.log("name: " + name, "\n" + "email: " + email + "\n" + "phone: " + phone + "\n" + "password: " + password);
      var requestData = {
        name: name,
        email: email,
        phone: phone,
        password: password
      }
      ApiHelper.post(Constants.REGISTER_QONLINE, requestData)
      .then((data) => {
          console.log("REGISTER DATA", data);
          if(data.code == 200) {
            setComplete(true);
          } else {
            setMessage(data.message)
          }

      })
      .catch((error) => {
          console.log("error::", error);
          setMessage(error.message)
      });
    } else {
      setMessage("Vui lòng điền thông tin để đăng ký thành viên!")
      e.preventDefault();
    }
  }

  const formValidation = () => {
    if (!Boolean(name) || !Boolean(phone) || password.length < 6 || !Utils.validateEmail(email)) {
      setEnable(false)
    } else {
      setEnable(true);
    }
  }

  
    
    return (
      <div className="register-container">
      {
        isComplete ? <RegisterConfirm/>:
      
        <div className="register-main">
          <span className="register-title">Đăng ký thành viên </span>
          <div className="divider"></div>
          <span className="label">Thông tin cá nhân</span>

          <Input
            value={name}
            required={true}
            type="text"
            message=""
            placeholder="Họ và tên"
            name="name"
            onChange={e => setName(e.target.value)}
          />
          <Input
            value={phone}
            required={true}
            type="text"
            message=""
            placeholder="Số điện thoại"
            name="phone"
            onChange={e => setPhone(e.target.value)}
          />
          <div className="divider"></div>
          <span className="label">Thông tin đăng nhập</span>
          <Input
            value={email}
            required={true}
            type="email"
            message=""
            placeholder="Email"
            name="email"
            onChange={e => setEmail(e.target.value)}
          />
          <Input
            value={password}
            required={true}
            type="password"
            placeholder="Mật khẩu"
            message=""
            name="phone"
            onChange={e => setPassword(e.target.value)}
          />

          <span className="register-err">
            {message}
          </span>
          {/* button */}
          <button
            className={enable ? "register-btn enable" : "register-btn"}
            onClick={e => onSubmit(e)}
          >
            Đăng ký
        </button>
          <span className="register-wrap-login">
            <span className="register-login-text">Bạn đã có tài khoản? Đăng nhập </span>
            <a href="/q-online/login" className="register-login-link">Tại Đây</a>
          </span>

        </div>
      }
      </div>
    )
  
}