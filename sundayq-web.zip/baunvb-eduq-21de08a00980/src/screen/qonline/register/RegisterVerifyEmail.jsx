import React, { useState, useEffect } from 'react'
import "./register.css"
import CircularProgress from '@material-ui/core/CircularProgress';
import { Utils, Constants } from "../../../utils"
import { ApiHelper } from '../../../services/apis/ApiHelper';

const STATUS = {
  LOADING: "LOADING",
  SUCCESS: "SUCCESS",
  ERROR: "ERROR"
}

export default function RegisterVerifyEmail(props) {
  const [status, setStatus] = useState(STATUS.LOADING);
  useEffect(() => {
    const href = window.location.href;
    const regex = `[\n\r].*Object Name:\s*([^\n\r]*)`
    const token = href.match(/\?token=(.*)/)[1];
    // const token = params.get('token');
    console.log("TOKEN", token)
    if (Boolean(token)) {
      ApiHelper.post(Constants.VERIFY_ACCOUNT, {token})
        .then(({ code }) => {
          if(code == 200) {
            setStatus(STATUS.SUCCESS);
          } else {
            setStatus(STATUS.ERROR)
          }
        })
        .catch((error) => {
          console.log("error::", error);
          setStatus(STATUS.ERROR)
        });
    } else {
      setStatus(STATUS.ERROR)
    }
  }, [])

  return (
    <div className="register-container">
      {
        status == STATUS.LOADING ?
          <div className="register-confirm-loading">
            <CircularProgress disableShrink />
          </div> :
          <div className="register-confirm-main">
            <div>
              <span className="register-confirm-title">{status == STATUS.SUCCESS ? "Xác thực Email thành công" : "Xác thực Email không thành công"}</span>
              <span className="register-confirm-step">{status == STATUS.SUCCESS ? "Bạn đã trở thành thành viên của SundayQ. Vui lòng đăng nhập để sử dụng dịch vụ" : "Email đăng ký chưa được xác thực. Vui lòng thử lại hoặc liên hệ bộ phận CSKH để được hỗ trợ"}!</span>

              <a href={status == STATUS.SUCCESS ? "/q-online/login" : "/q-online/register"} className="register-btn enable">{status == STATUS.SUCCESS ? "Đăng nhập ngay" : "Đăng ký"}</a>
            </div>
            <img src={require("../../../assets/image/qonline/2910/build_character_program_img_animal.svg")} />
          </div>
      }
    </div>
  )
}