import React, { useState, useEffect } from 'react'
import "./register.css"
export default function RegisterConfirm(props) {
  return (
    <div className="register-confirm-main">
      <div>
        <span className="register-confirm-title">Xác thực Email</span>
        <span className="register-confirm-step">Vui lòng xác thực email bằng cách</span>
        <div>
          <span className="register-confirm-text-normal">1.</span>
          <span className="register-confirm-text-bold">Truy cập Email</span>
          <span className="register-confirm-text-normal"> bạn đã dùng để đăng ký</span>
        </div>
        <div>
          <span className="register-confirm-text-normal">2.</span>
          <span className="register-confirm-text-bold">Mở tin nhắn</span>
          <span className="register-confirm-text-normal">có tiêu đề "SundayQ - Xác nhận đăng ký tài khoản QOnline"</span>
        </div>
        <div>
          <span className="register-confirm-text-normal">3.</span>
          <span className="register-confirm-text-bold">Bấm vào đường link</span>
          <span className="register-confirm-text-normal">trong email</span>
        </div>
        <a href="/" className="register-confirm-direct-to-home">
          Về trang chủ
        </a>
      </div>
      <img src={require("../../../assets/image/qonline/2910/build_character_program_img_animal.svg")} />
    </div>
  )
}