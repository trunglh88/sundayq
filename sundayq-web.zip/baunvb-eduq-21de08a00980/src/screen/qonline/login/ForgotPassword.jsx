import React, { useState, useEffect } from 'react'
import "./login.css"
import Input from "../../../component/Input/Input"
import { Utils, Constants } from "../../../utils"
import { ApiHelper } from '../../../services/apis/ApiHelper';

import SweetAlert from 'react-bootstrap-sweetalert';

export default function ForgotPassword(props) {
  const [email, setEmail] = useState("");
  const [enable, setEnable] = useState(false);
  const [alert, setAlert] = useState(null);

  useEffect(() => {
    formValidation();
  }, [email])

  const onSubmit = (e) => {
    if (enable) {
      console.log("email: " + email);
      ApiHelper.post(Constants.RESET_PASSWORD, {email: email})
        .then(({ data }) => {
          setAlert(
            <SweetAlert
              success
              title="Thành công"
              confirmBtnText="Tiếp tục đăng nhập"
              confirmBtnCssClass="login-btn enable"
              onConfirm={() => {
                setAlert(null);
                props.onClick()
              }}
            >
              Mật khẩu mới đã được gửi về tài khoản email của bạn!
              </SweetAlert>
          )
        })
        .catch((error) => {
          console.log("error::", error);
          setAlert(
            <SweetAlert
              error
              title="Không thành công"
              confirmBtnCssClass="login-btn enable"
              onConfirm={() => setAlert(null)}
            >
              Yêu cầu không thành công, xin vui lòng thử lại!
              </SweetAlert>
          )
        });

    } else {
      e.preventDefault();
    }
  }

  const formValidation = () => {
    if (!Utils.validateEmail(email)) {
      setEnable(false)
    } else {
      setEnable(true)
    }
  }
  return (
    <div className="login-main">
      {alert}
      <span className="login-title">Lấy lại mật khẩu</span>
      <span className="login-forgot-pass-note">Điền Email đăng nhập của bạn để lấy lại mật khẩu</span>
      <div className="divider"></div>

      <Input
        value={email}
        required={true}
        type="email"
        message=""
        placeholder="Email"
        name="email"
        onChange={e => setEmail(e.target.value)}
      />

      {/* button */}
      <button
        className={enable ? "login-btn enable" : "login-btn"}
        onClick={e => onSubmit(e)}
      >
        Gửi mật khẩu đến email này
        </button>

    </div>

  )

}