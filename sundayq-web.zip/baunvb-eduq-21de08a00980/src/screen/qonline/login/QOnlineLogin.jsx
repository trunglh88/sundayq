import React, { useState, useEffect } from 'react'
import "./login.css"
import Input from "../../../component/Input/Input"
import { Utils } from "../../../utils"
import LoginForm from "./LoginForm"
import ForgotPassword from "./ForgotPassword"

export default function QOnlineLogin(props) {
  const [isForgotPass, setForgotPass] = useState(false)

  return (
    <div className="login-container">
      {
        isForgotPass ?
        <ForgotPassword
          onClick={() => setForgotPass(false)}
        /> :
        <LoginForm
          onClick={() => setForgotPass(true)}
        />
      }
    </div>
  )

}