import React, { useState, useEffect } from 'react'
import "./login.css"
import Input from "../../../component/Input/Input"
import { Utils, Constants, Storage } from "../../../utils"
import { ApiHelper } from '../../../services/apis/ApiHelper';

export default function LoginForm(props) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [enable, setEnable] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    formValidation();
  }, [email, password])

  const onSubmit = (e) => {
    if (enable) {
      console.log("email: " + email + "\n" + "password: " + password);
      ApiHelper.post(Constants.LOGIN_QONLINE, {email, password})
      .then(({ data }) => {
          console.log("LOGIN DATA", data);
          Storage.setData(Storage.KEY.TOKEN, data.token);
          Storage.setData(Storage.KEY.AVATAR, data.avatar);
          Storage.setData(Storage.KEY.EMAIL, data.email);
          Storage.setData(Storage.KEY.USERNAME, data.name);
          Storage.setData(Storage.KEY.PHONE, data.phone);
          Storage.setData(Storage.KEY.USER_ID, data.id);

          window.location.href="/"
      })
      .catch((error) => {
          console.log("error::", error);
          setMessage(error.message)
      });
    } else {
      e.preventDefault();
    }
  }

  const formValidation = () => {
    if (password.length < 6 || !Utils.validateEmail(email)) {
      setEnable(false)
    } else {
      setEnable(true)
    }
  }
  return (
      <div className="login-main">
        <span className="login-title">Đăng nhập </span>
        <div className="divider"></div>

        <Input
          required={true}
          value={email}
          type="email"
          message=""
          placeholder="Email"
          name="email"
          onChange={e => setEmail(e.target.value)}
        />
        <Input
          required={true}
          value={password}
          type="password"
          placeholder="Mật khẩu"
          message=""
          name="password"
          onChange={e => setPassword(e.target.value)}
        />

        <span 
        onClick={e => props.onClick()}
        className="login-forgot-pass">Quên mật khẩu?</span>
        {/* button */}
        <span className="login-err">
          {message}
        </span>
        <button
          className={enable ? "login-btn enable" : "login-btn"}
          onClick={e => onSubmit(e)}
        >
          Đăng nhập
        </button>
        <span className="login-wrap-login">
          <span className="login-login-text">Chưa có tài khoản? Đăng ký </span>
          <a href="/q-online/register" className="login-login-link">Tại Đây</a>
        </span>

      </div>

  )

}