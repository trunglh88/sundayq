import React, { useEffect, useState } from 'react';
import SectionInner from "../../component/Container/SectionInner"
import './q-online-screen.css'
import VideoPlayer from "../../component/Media/VideoPlayer"
import { Utils, Constants } from "../../utils"
import { ApiHelper } from '../../services/apis/ApiHelper';
import CircularProgress from '@material-ui/core/CircularProgress';

const SERVICE_CODE = {
 FREEQ: 1,
 STEAMQ: 2,
 BIZQ: 3
}

function ItemService(props) {
    return (
        <div className="q-online-screen-wrap-item">
            <div>
                <span className="q-online-screen-title" style={{ color: props.colorText }}>{props.title}</span>
                <div className="q-online-screen-wrap-video">
                    <VideoPlayer url={Utils.videoUrl(props.videoUrl, 720)} />
                </div>
                <span className="des">{props.des}</span>
                <div style={{ backgroundColor: props.colorBtn }} className="q-online-screen-btn"
                    onClick={() => { window.location.href = props.href }}
                >
                    {props.btnText}
                </div>
            </div>
            <img src={props.image} />
        </div>
    )
}

function LargeItemNews(props) {
    console.log("LargeItemNews", props)
    var imgUrl = Utils.imageUrl(props.thumbnailUrl)
    return (
        <div className="qonline-screen-large-item-news-main"
            onClick={() => { }}
        >
            <img className="qonline-screen-large-item-news-img" src={imgUrl} />
            <div className="qonline-screen-large-item-news-content">
                <span className="qonline-screen-largeitem-news-title">{props.title}</span>
                <span className="qonline-screen-largeitem-news-des">{props.shortDescription}</span>
            </div>
        </div>
    )
}

function ItemNews(props) {
    console.log("ItemNews", props)
    var imgUrl = Utils.imageUrl(props.thumbnailUrl)
    return (
        <div className="qonline-screen-item-news-main"
            onClick={() => { }}
        >
            <img className="qonline-screen-item-news-img" src={imgUrl} />
            <div className="qonline-screen-item-news-content">
                <span className="qonline-screen-item-news-title">{props.title}</span>
                <span className="qonline-screen-item-news-des">{props.shortDescription}</span>
            </div>
        </div>
    )
}

function News(props) {
    return (
        <div className="q-online-screen-news-container">
            <div>
                <LargeItemNews
                    thumbnailUrl=""
                    shortDescription="Chính phủ ban hành Nghị định số 105/2020/NĐ-CP quy định một số ..."
                    title="04 chính sách giáo dục quan trọng có hiệu lực từ tháng 8/2020"

                />
            </div>
            <div>
                <ItemNews
                    thumbnailUrl=""
                    shortDescription="Chính phủ ban hành Nghị định số 105/2020/NĐ-CP quy định một số ..."
                    title="04 chính sách giáo dục quan trọng có hiệu lực từ tháng 8/2020"
                />
                <ItemNews
                    thumbnailUrl=""
                    shortDescription="Chính phủ ban hành Nghị định số 105/2020/NĐ-CP quy định một số ..."
                    title="04 chính sách giáo dục quan trọng có hiệu lực từ tháng 8/2020"
                />
                <ItemNews
                    thumbnailUrl=""
                    shortDescription="Chính phủ ban hành Nghị định số 105/2020/NĐ-CP quy định một số ..."
                    title="04 chính sách giáo dục quan trọng có hiệu lực từ tháng 8/2020"
                />
            </div>
        </div>
    )
}

export default function QOnlineHomeScreen(props) {
    const [services, setService] = useState([]);
    const [isLoading, setLoading] = useState(true);
    useEffect(() => {
        ApiHelper.get(Constants.GET_SERVICES_QONLINE)
            .then((data) => {
                if (data.code == 200) {
                    setService(data.data.services)
                    setTimeout(() => {
                        setLoading(false)
                    }, 1000)
                }

            })
            .catch((error) => {
                console.log("error::", error);
                setLoading(false)
            });
    }, [])
    if (isLoading) return (
        <div className="q-online-screen-wrap-loading">
            <CircularProgress disableShrink />
        </div>
    )
    //filter service
    var freeqService, steamqService, bizqService;
    if(services.filter(obj => {return obj.code === SERVICE_CODE.FREEQ}).length > 0) {
        freeqService = services.filter(obj => {return obj.code === SERVICE_CODE.FREEQ})[0]
    }
    if(services.filter(obj => {return obj.code === SERVICE_CODE.STEAMQ}).length > 0) {
        steamqService = services.filter(obj => {return obj.code === SERVICE_CODE.STEAMQ})[0]
    }
    if(services.filter(obj => {return obj.code === SERVICE_CODE.BIZQ}).length > 0) {
        bizqService = services.filter(obj => {return obj.code === SERVICE_CODE.BIZQ})[0]
    } 
    return (
        <SectionInner>
            <div className="q-online-screen-wrap-text-header">
                <span className="q-online-screen-wrap-text-qonline">Edu - q</span>
                <span className="q-online-screen-wrap-text-sub">Học Viện Trực Tuyến cho Nhà Trường, Gia đình và Chính các bé</span>
            </div>
            <div className="q-online-screen-header-divider"></div>
            <ItemService
                href={`/q-online/order?type=service&id=${freeqService?.id}&code=1`}
                title={freeqService.name}
                colorText="#C45840"
                colorBtn="#B04C36"
                videoUrl={freeqService.video.fileUrl}
                btnText={`Đăng ký ${freeqService.name}`}
                des={freeqService.shortDescription || freeqService.description}
                image={Utils.imageUrl(freeqService.thumbnailUrl)}
            />

            <ItemService
                href={`/q-online/order?type=service&id=${steamqService?.id}&code=2`}
                title={steamqService.name}
                colorText="#2E72AD"
                colorBtn="#286295"
                videoUrl={steamqService.video.fileUrl}
                btnText={`Đăng ký ${freeqService.name}`}
                des={steamqService.shortDescription || steamqService.description}
                image={Utils.imageUrl(steamqService.thumbnailUrl)}
                // image={require("../../assets/icon/qonline_img_item3.svg")}
            />

            <ItemService
                href={`/q-online/order?type=service&id=${bizqService?.id}&code=3`}
                title={bizqService.name}
                colorText="#0FAB4B"
                colorBtn="#0A7568"
                videoUrl={bizqService.video.fileUrl}
                btnText={`Đăng ký ${bizqService.name}`}
                des={bizqService.shortDescription || bizqService.description}
                image={Utils.imageUrl(bizqService.thumbnailUrl)}
                // image={require("../../assets/icon/qonline_img_item2.svg")}
            />
            <span className="q-online-screen-news-label">News</span>
            <div className="q-online-screen-news-divider"></div>

            <News />
        </SectionInner>
    )

}