import React from 'react'
import "./qonline-pay.css"
import "../../../component/Container/SectionInner"
import { Utils, Constants } from '../../../utils'
const ICON = {
    SUCCESS: require("../../../assets/icon/ic_pay_success.svg"),
    ERR: require("../../../assets/icon/ic_pay_err.svg")
}

export default function PaymentCallback(props) {
    var params = new URLSearchParams(window.location.search);
    const vnp_OrderInfo = params.get('vnp_OrderInfo');
    const vnp_TransactionNo = params.get('vnp_TransactionNo');
    const vnp_TransactionStatus = params.get('vnp_TransactionStatus');
    const vnp_Amount = params.get('vnp_Amount');
    let icon;
    if (vnp_TransactionStatus == '00') {
        icon = ICON.SUCCESS
    } else {
        icon = ICON.ERR
    }
    return (
        <div className="qonline-pay-screen">
            <div className="qonline-pay-wrap">
                <img
                    src={icon}
                />
                <span style={{ color: vnp_TransactionStatus == '00' ? "#0FAB4B" : "#D12700" }} className="qonline-pay-msg ">
                    {Constants.VNPAY_RESULT_CODE[vnp_TransactionStatus]}
                </span>
                <div>
                    {
                        Boolean(vnp_TransactionNo) &&
                        <span className="qonline-pay-row">
                            <span>
                                Mã giao dịch:
                            </span>
                            <span>
                                {vnp_TransactionNo}
                            </span>
                        </span>
                    }

                    {
                        Boolean(vnp_TransactionNo) &&
                        <span className="qonline-pay-row">
                            <span>
                                Số tiền:
                            </span>
                            <span>
                                {Utils.formatVnd(vnp_Amount)} VNĐ
                        </span>
                        </span>
                    }
                    {
                        Boolean(vnp_TransactionNo) &&
                        <span className="qonline-pay-row">
                            <span>
                                Nội dung giao dịch:
                            </span>
                            <span>
                                {vnp_OrderInfo}
                            </span>
                        </span>
                    }

                </div>
                <a href="/" className="qonline-pay-home-btn">
                    Về trang chủ EduQ
                </a>
            </div>
        </div>
    )
}