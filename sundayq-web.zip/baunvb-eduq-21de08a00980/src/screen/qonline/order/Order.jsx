import React, { useEffect, useRef, useState } from 'react'
import "./qonline-order.css"
import { Utils, Constants } from "../../../utils"
import { ApiHelper } from '../../../services/apis/ApiHelper';
import SweetAlert from 'react-bootstrap-sweetalert';

const IMG_SERVICE = {
    FREEQ: require("../../../assets/icon/qonline_img_item1.svg"),
    STEAM: require("../../../assets/icon/qonline_img_item3.svg"),
    JOYQ: require("../../../assets/icon/qonline_img_item2.svg"),
}

function Card(props) {
    return (
        <div className="qonline-card-container" style={props.style}>
            <div className="qonline-card-header">
                <img className="qonline-card-icon" src={props.icon} />
                <span className="qonline-card-title">{props.title}</span>
            </div>
            <div>
                {props.children}
            </div>
        </div>
    )
}

function BankingItem(props) {
    return (
        <div className="qonline-order-banking-info">
            <div style={{ backgroundColor: "#C4C4C4", width: "112px", height: "112px", marginRight: "32px" }}></div>
            <div>
                <span>{props.banking}</span><br />
                <span className="qonline-order-service-label">Chủ tải khoản:</span>
                <span className="qonline-order-service-detail">{props.user}</span><br />
                <span className="qonline-order-service-label">Số tải khoản:</span>
                <span className="qonline-order-service-detail">{props.number}</span><br />
            </div>
        </div>
    )
}

export default function Order(props) {
    const [alert, setAlert] = useState(null);
    const [merchandiseId, setMerchandiseId] = useState("");
    const [receiptUrl, setReceiptUrl] = useState("");
    const [service, setService] = useState(null);
    const [isShowDetail, showDetail] = useState(false);

    const input = useRef();

    var params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const type = params.get('type');
    const serviceCode = parseInt(params.get('code'));

    var imgService;
    switch (serviceCode) {
        case 1:
            imgService = IMG_SERVICE.FREEQ
            break
        case 2:
            imgService = IMG_SERVICE.STEAM
            break
        case 3:
            imgService = IMG_SERVICE.JOYQ
            break
        default:
            break
    }

    const onSelectReceiptUrl = (e) => {
        e.preventDefault();
        var reader = new FileReader();
        var file = e.target.files[0];
        reader.onloadend = () => {
            var formData = new FormData();
            formData.append("file", file);
            ApiHelper.post(Constants.REQUEST_UPLOAD_IMG, formData)
                .then((data) => {
                    console.log("REQUEST_UPLOAD_IMG", data);
                    setReceiptUrl(data.url)
                })
                .catch((error) => {
                    console.log("error::", error);
                });
        };
        reader.readAsDataURL(file);
    }

    useEffect(() => {
        //fetch service info here
        ApiHelper.get(Constants.GET_SERVICE_INFO(id))
            .then((data) => {
                console.log("GET_SERVICE_INFO", data);
                setService(data.data)
            })
            .catch((error) => {
                console.log("error::", error);
            });

        //request crate transaction ID

        ApiHelper.post(Constants.REQUEST_SERVICES_TRANS, { serviceId: id })
            .then((data) => {
                console.log("REQUEST_SERVICES_TRANS", data);
                setMerchandiseId(data.data.id);

            })
            .catch((error) => {
                console.log("error::", error);

            });

    }, [])

    const requestOnlinePayment = () => {
        showDetail(false)
        ApiHelper.post(Constants.REQUEST_PAY_ONLINE(type), { merchandiseId: merchandiseId })
            .then((data) => {
                console.log("REQUEST_PAY_ONLINE", data);
                if (data.code == 200) {
                    console.log("success")
                    window.location.href = data.data.data
                }
            })
            .catch((error) => {
                console.log("error::", error);
            });

    }

    const requestOfflinePayment = () => {
        if (!Boolean(receiptUrl)) {
            setAlert(
                <SweetAlert
                    warning
                    title="Thông báo"
                    confirmBtnCssClass="qonline-confirm-alert-btn"
                    onConfirm={() => setAlert(null)}
                >
                    Vui lòng chọn gửi kèm biên lai chuyển tiền
                    </SweetAlert>
            );
        } else {
            ApiHelper.post(Constants.REQUEST_PAY_OFFLINE(type), { merchandiseId: merchandiseId, thumbnailUrl: URL })
                .then((data) => {
                    console.log("REQUEST_PAY_OFFLINE", data);
                    if (data.code == 200) {
                        setAlert(
                            <SweetAlert
                                success
                                title="Đặt mua thành công"
                                confirmBtnCssClass="qonline-confirm-alert-btn"
                                onConfirm={() => setAlert(null)}
                            >
                                Yêu cầu đăng ký dịch vụ đã được thực hiện. Nhân viên của chúng tôi sẽ liên hệ để xác nhận sớm nhất!
                                </SweetAlert>
                        );
                    }
                })
                .catch((error) => {
                    console.log("error::", error);
                });
        }
    }

    var total = 0;
    var price = 0;
    var discount = 0;
    if (Boolean(service)) {
        if (Boolean(service.price)) {
            price = service.price;
        }
        if (Boolean(service.discount)) {
            discount = service.discount;
        }
    }

    total = price - discount;

    return (
        <div className="qonline-order-container">
            {alert}
            <div className="qonline-order-header">
                Thanh toán
            </div>
            <div className="qonline-order-main">
                <Card
                    icon={require("../../../assets/icon/ic_order_info.svg")}
                    title="Khóa học"
                    style={{
                        borderTop: "4px solid #C45840"
                    }}
                >
                    <div className="qonline-order-service">
                        <div className="qonline-order-service-info-wrap">
                            <img className="qonline-order-prev-img" src={imgService} />
                            <div>
                                <span className="qonline-order-service-name">{"FreeQ"}</span>
                                <span className="qonline-order-service-label">Hình thức:</span>
                                <span className="qonline-order-service-detail">Học trực tuyến</span><br />

                                <span className="qonline-order-service-label">Thanh toán:</span><br />
                                <span className="qonline-order-service-detail">- Chuyển khoản trực tiếp</span><br />
                                <span className="qonline-order-service-detail">- Thanh toán trực tuyến</span><br />

                                <span className="qonline-order-service-label">Thời hạn:</span>
                                <span className="qonline-order-service-detail">01 năm kể từ ngày thanh toán</span>
                            </div>
                        </div>
                        <div className="qonline-order-service-price-wrap">
                            <span className="qonline-order-price-row">
                                <span>Giá tiền:</span>
                                <span>{Utils.formatVnd(price)} VNĐ</span>
                            </span>
                            <span className="qonline-order-price-row">
                                <span>Giảm giá:</span>
                                <span>{`-${Utils.formatVnd(discount)}`} VNĐ</span>
                            </span>
                            <div className="qonline-order-service-price-divider"></div>
                            <span className="qonline-order-price-row-total">
                                <span>Tổng tiền:</span>
                                <span>{Utils.formatVnd(total)} VNĐ</span>
                            </span>

                        </div>
                    </div>
                </Card>
                <Card
                    icon={require("../../../assets/icon/ic_order_payment.svg")}
                    title="Thanh toán"
                    style={{
                        paddingBottom: "82px",
                        position: "relative"
                    }}
                >
                    <span className="qonline-payment-select-type">Chọn phương thức thanh toán:</span>
                    <div className="qonline-order-wrap-btn">
                        <div className="qonline-order-pay-btn"
                            onClick={() => showDetail(true)}
                        >
                            <img
                                src={require("../../../assets/image/qonline/bank_card.png")}
                            />
                            <span>Dùng tài khoản ngân hàng</span>
                        </div>

                        <div className="qonline-order-pay-btn"
                            onClick={() => requestOnlinePayment()}
                        >
                            <img
                                src={require("../../../assets/image/qonline/bank_vnpay.png")}
                            />
                            <span>
                                Thanh toán qua VNPay
                                <img src={require("../../../assets/image/qonline/icon_forward_url.svg")} />
                            </span>

                        </div>
                    </div>

                </Card>
                {/* banking */}
                {
                    isShowDetail ?
                        <div className="qonline-order-pay-by-bank">
                            <span>
                                <span className="qonline-order-step-label">Bước 1: <span>Chuyển khoản tổng số tiền cần thanh toán qua một trong số các tài khoản sau.</span></span>
                            </span>
                            <div>
                                <BankingItem
                                    banking="Ngân hàng kỹ thương Việt Nam (Techcombank)"
                                    user="Nguyen Van A"
                                    number="019309184014"
                                />
                                <BankingItem
                                    banking="Ngân hàng công thương Việt Nam (Techcombank)"
                                    user="Nguyen Van A"
                                    number="019309184014"
                                />
                            </div>
                            <div className="divider"></div>
                            <span>
                                <span className="qonline-order-step-label">Bước 2: <span>Chụp ảnh màn hình biên lai thanh toán, sau đó tải lên tại ô bên dưới.</span></span>
                            </span>
                            <div className="qonline-order-wrap-img-submit">
                                <div className="qonline-order-img-submit">
                                    {
                                        !Boolean(receiptUrl) ?
                                            <span>Chọn ảnh</span>
                                            :
                                            <img className="qonline-order-img-preview" src={Utils.imageUrl(receiptUrl)} />
                                    }
                                    <input ref={input} title="Chọn ảnh" className="qonline-order-input-select-img" type="file" accept="image/*"
                                        onChange={e => onSelectReceiptUrl(e)}

                                    ></input>
                                </div>
                                <div className="qonline-order-btn-select-img"
                                    onClick={() => input.current.click()}
                                >
                                    Tải biên lai thanh toán lên
                            </div>
                            </div>
                            <div className="divider"></div>
                            <span>
                                <span className="qonline-order-step-label">Bước 3: <span>Bấm “Đặt mua khóa học” để xác nhận thanh toán.</span></span>
                            </span>
                            <div className="qonline-order-btn-submit"
                                onClick={() => requestOfflinePayment()}
                            >
                                Đặt mua khóa học
                    </div>
                        </div>
                        : null
                }

            </div>
        </div>
    )
}