import React from "react"
import "./qonline-order.css"
import SectionInner from "../../../component/Container/SectionInner";
export default function OrderSuccess(props) {
  return (
    <div className="qonline-order-success-container">
      <SectionInner extraClassName={["online-order-success-wrap"]}>
        <div style={{flex: 1}}>
          <img src={require("../../../assets/icon/ic_pay_success.svg")} />
          <span style={{ color: "#0FAB4B" }} className="qonline-pay-msg ">Đặt mua thành công</span>
          <span className="qonline-buy-result-text">Đơn hàng của bạn đã được xác nhận, nhân viên của chúng tôi sẽ liên hệ để xác nhận trong thời gian sớm nhất!</span>
          <a href="/" className="qonline-pay-home-btn">
            Về trang chủ EduQ
          </a>
        </div>

        <div className="online-order-success-wrap-img">
          <img className="image" src={require("../../../assets/image/qonline/2910/build_character_program_img_animal.svg")} />
        </div>
      </SectionInner>
    </div>

  )
}