import React from 'react'
import ImageSection from "../component/ImageSection"
import QOnlineFooterHelper from "../component/QOnlineFooterHelper"
export default function Manifesto(props) {
  return (
    <div>
      <ImageSection
        backgroundColor="#A1C855"
        img={require("../../../../assets/image/qonline/2910/manifesto_sec1.svg")} />
      
      {/* <QOnlineFooterHelper backgroundColor="#A1C855"/> */}
    </div>
  )
}