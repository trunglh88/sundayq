import React from 'react'
import ImageSection from "../component/ImageSection"
import QOnlineFooterHelper from "../component/QOnlineFooterHelper"
import "./program-character.css"

function Section2(props) {
  return (
    <div className="program-character-sec">
      <div className="program-character-sec-wrap-title">
        <img src={require("../../../../assets/image/qonline/2910/build_character_program_title.svg")} />
      </div>
      <div className="program-character-sec-wrap-content">
        <img src={require("../../../../assets/image/qonline/2910/build_character_program_content.svg")} />
      </div>
      <img className="program-character-sec-img-animal-bg" src={require("../../../../assets/image/qonline/2910/build_character_program_img_animal.svg")} />
    </div>
  )
}

export default function ApplicationCharacter(props) {
  return (
    <div>
      <ImageSection
        backgroundColor="#79C0C4"
        img={require("../../../../assets/image/qonline/2910/build_character_program_sec1.svg")} />
      {/* <ImageSection
        backgroundColor="#F9996A"
        img={require("../../../assets/image/qonline/2910/build_character_program_sec1.svg")} /> */}
      <Section2 />
      <ImageSection
        backgroundColor="#F9996A"
        img={require("../../../../assets/image/qonline/2910/build_character_program_sec3.svg")} />
      <ImageSection
        backgroundColor="#A1C855"
        img={require("../../../../assets/image/qonline/2910/build_character_program_sec4.svg")} />
      <ImageSection
        backgroundColor="#F9B236"
        img={require("../../../../assets/image/qonline/2910/build_character_program_sec5.svg")} />
      <ImageSection
        backgroundColor="#79C0C4"
        img={require("../../../../assets/image/qonline/2910/build_character_program_sec6.svg")} />

      {/* <QOnlineFooterHelper backgroundColor="#79C0C4" /> */}

    </div>
  )
}