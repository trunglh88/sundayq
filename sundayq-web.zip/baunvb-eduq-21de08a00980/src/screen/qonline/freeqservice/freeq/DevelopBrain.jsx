import React from 'react'
import ImageSection from "../component/ImageSection"
import QOnlineFooterHelper from "../component/QOnlineFooterHelper"

export default function DevelopBrain(props) {
  return (
    <div>
      <ImageSection
        backgroundColor="#A1C855"
        img={require("../../../../assets/image/qonline/2910/develop_brain_sec1.svg")} />
      <ImageSection
        backgroundColor="#F9996A"
        img={require("../../../../assets/image/qonline/2910/develop_brain_sec2.svg")} />
      <ImageSection
        backgroundColor="#FAB236"
        img={require("../../../../assets/image/qonline/2910/develop_brain_sec3.svg")} />
      <ImageSection
        backgroundColor="#79C0C4"
        img={require("../../../../assets/image/qonline/2910/develop_brain_sec4.svg")} />
      {/* <QOnlineFooterHelper backgroundColor="#79C0C4"/> */}

    </div>
  )
}