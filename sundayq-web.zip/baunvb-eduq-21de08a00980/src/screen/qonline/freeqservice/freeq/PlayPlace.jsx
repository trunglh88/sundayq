import React from 'react'
import ImageSection from "../component/ImageSection"
import QOnlineFooterHelper from "../component/QOnlineFooterHelper"

export default function PlayPlace(props) {
  return (
    <div>
      <ImageSection
        backgroundColor="#C4C4C4"
        img={require("../../../../assets/image/qonline/2910/play_place_sec1.svg")} />
      <ImageSection
        backgroundColor="#F9996A"
        img={require("../../../../assets/image/qonline/2910/play_place_sec2.svg")} />
      <ImageSection
        backgroundColor="#FAB236"
        img={require("../../../../assets/image/qonline/2910/play_place_sec3.svg")} />
        
      {/* <QOnlineFooterHelper backgroundColor="#FAB236"/> */}

    </div>
  )
}