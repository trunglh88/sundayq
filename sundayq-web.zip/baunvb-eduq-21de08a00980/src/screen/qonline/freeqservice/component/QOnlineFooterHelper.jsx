import React from 'react'
import "./qonline-footer-helper.css"

export default function QOnlineFooterHelper(props) {
  return (
    <div style={{backgroundColor: props.backgroundColor}} className="freeq-play-place-footer-helper" />
  )
}