import React from 'react';
import './qonline-menu-filter.css'
import { optionalMemberExpression } from '@babel/types';

const options = [
  {
    text: "Tháng 1",
    value: 1
  },
  {
    text: "Tháng 2",
    value: 2
  },
  {
    text: "Tháng 3",
    value: 3
  },
  {
    text: "Tháng 4",
    value: 4
  },
  {
    text: "Tháng 5",
    value: 5
  },
  {
    text: "Tháng 6",
    value: 6
  },
  {
    text: "Tháng 7",
    value: 7
  },
  {
    text: "Tháng 8",
    value: 8
  },
  {
    text: "Tháng 9",
    value: 9
  },
  {
    text: "Tháng 10",
    value: 10
  },
  {
    text: "Tháng 11",
    value: 11
  },
  {
    text: "Tháng 12",
    value: 12
  },
]

export default class MenuFilter extends React.Component {
  constructor(props) {
    super(props)
  }

  handleSelect = (value) => {
    this.props.onClick(value)
  }

  render() {
    const { customOption } = this.props;
    const newOption = [...customOption, ...options]
    console.log("xxxx", newOption)
    return (
      <div className="q-online-menu-fillter-wrap">
        {
          newOption.map((month, index) => {
            return (
              <span
                onClick={() => this.handleSelect(month)}
              >{month.text}</span>
            )
          })
        }
      </div>
    )
  }
}

MenuFilter.defaultProps = {
  customOption: []
}