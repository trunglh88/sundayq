import React from 'react'
import LazyImage from '../../../../component/Lazyloading/LazyImage'
import "./image-section.css"
import ImagePlaceHolder from "../../../../assets/image/qonline/image_placeholder.png"
export default function ImageSection(props) {
  return (
    <div
      className="image-section-bg"
      style={{backgroundColor:`${props.backgroundColor}`}}
    >
      {/* <img alt="" src={props.img}/> */}
      <LazyImage
        placeHolder={ImagePlaceHolder}
        src={props.img}
        width={`100%`}
        height={`auto`}
        effect={"opacity"}
        alt=""
      />
    </div>
  )
}