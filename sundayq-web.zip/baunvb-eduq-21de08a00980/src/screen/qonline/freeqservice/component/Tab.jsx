import React from "react"

export default function Tab(props) {
    return (
        <a href={props.href} className={props.isActive ? "qonline-free-tab qonline-free-tab-active" : "qonline-free-tab"}>
            <img src={props.isActive ? props.imgActive : props.img} />
            <span>{props.title}</span>
            {
                props.isLast ? null : <div></div>
            }
        </a>
    )
    
}

Tab.defaultProps = {
    isLast: false  
}