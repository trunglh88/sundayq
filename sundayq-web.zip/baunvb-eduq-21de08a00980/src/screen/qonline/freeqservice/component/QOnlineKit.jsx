import "./qonline-kit.css";
import React, { useState } from 'react';
import { Utils } from "../../../../utils";
import { ApiHelper } from '../../../../services/apis/ApiHelper';
import { Constants } from '../../../../utils';
import SweetAlert from 'react-bootstrap-sweetalert';
import ServerUI from "../../../../component/Container/ServerUI"
export default function QOnlineKit(props) {
  console.log("QOnlineKit", props)
  const [imgIndex, setImg] = useState(0);
  const [phoneNumber, setPhone] = useState("");
  const [alert, setAlert] = useState(null);

  const listThumbnail = props.thumbnailUrls;

  const submit = () => {
    let requestData = {
      phone: phoneNumber
  };

  ApiHelper.post(Constants.REQUES_BUY_KIT(props.id), requestData)
      .then(({ data }) => {
          setAlert(
              <SweetAlert
                  success
                  title="Thành công"
                  confirmBtnCssClass="qonline-confirm-alert-btn"
                  onConfirm={() => setAlert(null)}
              >
                  Bạn đã ký nhận tư vấn khóa học thành công
              </SweetAlert>
          )
          setPhone('');
      })
      .catch((error) => {
          console.log("error::", error);
          setAlert(
              <SweetAlert
                  error
                  title="Không thành công"
                  confirmBtnCssClass="qonline-confirm-alert-btn"
                  onConfirm={() => setAlert(null)}
              >
                  Quý khách vui lòng cung cấp lại thông tin để nhận được tư vấn
              </SweetAlert>
          )
      });
  }

  return (
    <div className="qonline-kit-main">
                {alert}

      <div className="qonline-kit-img-area">
        <div className="qonline-kit-preview">
          <img src={Utils.imageUrl(listThumbnail[imgIndex])} />
        </div>

        <div className="qonline-kit-wrap-thumbnail">
          {
            listThumbnail.map((img, key) => {
              return <div className="qonline-kit-item-thumb"
                onClick={() => setImg(key)}
              >
                <div></div>
                <img key={key} src={Utils.imageUrl(img)} />
              </div>
            })
          }
        </div>
      </div>

      <div className="qonline-kit-content">
        <span className="qonline-kit-content-title">{props.title}</span>
        <span className="qonline-kit-content-price">{Utils.formatVnd(props.price)} VNĐ</span>
        <ServerUI
            extraClassName={[""]}
            content={props.description}>
        </ServerUI>
        <div className="qonline-kit-divider"/>
        <span className="qonline-kit-buy-label">Đặt mua sản phẩm</span>
        <span className="qonline-kit-buy-note">Nhân viên tư vấn của chúng tôi sẽ gọi lại trong vòng 3 giờ.</span>
        <input 
          className="qonline-kit-input"
          placeholder="Nhập số điện thoại"
          onChange={(e) => setPhone(e.target.value)}
        />
        <span className="qonline-kit-content-btn"
          onClick={() => submit()}
        >Đặt mua</span>
      </div>
    </div>
  )
}
