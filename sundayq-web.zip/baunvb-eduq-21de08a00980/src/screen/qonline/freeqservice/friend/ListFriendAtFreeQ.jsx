import React from 'react'
import ImageSection from "../component/ImageSection"
import QOnlineFooterHelper from "../component/QOnlineFooterHelper"

export default function ListFriendAtFreeQ(props) {
  return (
    <div>
      <div id="rabbit" />
      <ImageSection
        backgroundColor="#F9B236"
        img={require("../../../../assets/image/qonline/2910/friend_tho.svg")} />
      <div id="turtle" />
      <ImageSection
        backgroundColor="#F89868"
        img={require("../../../../assets/image/qonline/2910/friend_rua.svg")} />
      <div id="bear" />
      <ImageSection
        backgroundColor="#A0C655"
        img={require("../../../../assets/image/qonline/2910/friend_gau.svg")} />
      <div id="dog" />
      <ImageSection
        backgroundColor="#E8A635"
        img={require("../../../../assets/image/qonline/2910/friend_dog.svg")} />
      <div id="parakeet" />
      <ImageSection
        backgroundColor="#4DB28E"
        img={require("../../../../assets/image/qonline/2910/friend_vet.svg")} />

      <div id="cat" />
      <ImageSection
        backgroundColor="#79C0C2"
        img={require("../../../../assets/image/qonline/2910/friend_meo.svg")} />
      {/* <QOnlineFooterHelper backgroundColor="#79C0C2" /> */}

    </div>
  )
}