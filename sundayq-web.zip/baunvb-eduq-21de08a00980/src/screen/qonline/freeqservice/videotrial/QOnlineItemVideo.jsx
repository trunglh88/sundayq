import "./qonline-item-video.css";
import React from 'react';
import { Utils } from "../../../../utils"
export default function QOnlineItemVideo(props) {
  console.log("QOnlineItemVideo", props)
  var imgUrl = Utils.imageUrl(props.thumbnailUrl)
  return (
    <div className="qonline-item-video-main"
      onClick={props.onClick}
    >
      <div>
       {
         props.isPlaying && <img className="qonline-item-video-ic-playing" src={require("../../../../assets/image/qonline/2910/ic_play.svg")} />
       }
        <img className="qonline-item-video-img" src={imgUrl} />
      </div>

      <div className="qonline-item-video-content">
        <span className="qonline-item-video-title">{`Video ${props.index + 1}/${props.length}: ${props.title}`}</span>
        <span className="qonline-item-video-des">{props.shortDescription}</span>
      </div>
    </div>
  )
}
