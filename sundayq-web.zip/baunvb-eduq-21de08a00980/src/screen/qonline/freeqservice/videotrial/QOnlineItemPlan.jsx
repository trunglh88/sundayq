import "./qonline-plan-item.css";
import React from 'react';
import {Utils} from "../../../../utils"
export default function QOnlineItemPlan(props) {
  console.log("QOnlineItemPlan", props)
  var imgUrl = Utils.imageUrl(props.thumbnailUrl)
  return (
    <div className="qonline-plan-item-video-main"
      onClick={props.onClick}
    >
      <div className="qonline-plan-item-wrap-img">
        <span>{props.month}</span>
        <img className="qonline-plan-item-video-img" src={imgUrl} />
      </div>
      <div className="qonline-plan-item-video-content">
        <span className="qonline-plan-item-video-title">{`Tháng ${props.month}: ${props.title}`}</span>
        <span className="qonline-plan-item-video-des">{props.shortDescription}</span>
      </div>
    </div>
  )
}
