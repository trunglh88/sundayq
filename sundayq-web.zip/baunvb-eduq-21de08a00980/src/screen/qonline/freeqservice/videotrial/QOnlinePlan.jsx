import "./qonline-free.css";
import React from 'react'
import QOnlineItemVideo from "./QOnlineItemVideo"
import QOnlineKit from '../component/QOnlineKit';
import VideoPlayer from '../../../../component/Media/VideoPlayer'
import MenuFilter from "../component/MenuFilter"
import { ApiHelper } from '../../../../services/apis/ApiHelper';
import QOnlineItemPlan from "./QOnlineItemPlan"
import { Constants, Utils } from '../../../../utils';
import ServerUI from '../../../../component/Container/ServerUI';
import Tab from "../component/Tab";
import { FreeQLayoutContext } from '../../../../context/FreeQLayoutContext'
import ImagePlaceHolder from "../../../../assets/image/qonline/image_placeholder.png"
import LazyImage from "../../../../component/Lazyloading/LazyImage";

const TabConfig = [
  {
    type: 1,
    title: "BÀI GIẢNG MẪU CHO TRẺ 0 - 1 TUỔI",
    color: "#F57878",
    image: require("../../../../assets/image/qonline/qonline_free_bg_1.png"),
  },
  {
    type: 2,
    title: "BÀI GIẢNG MẪU CHO TRẺ 1 - 2 TUỔI",
    color: "#F57878",
    image: require("../../../../assets/image/qonline/qonline_free_bg_2.png"),
  },
  {
    type: 3,
    title: "BÀI GIẢNG MẪU CHO TRẺ 2 - 3 TUỔI",
    color: "#2E72AD",
    image: require("../../../../assets/image/qonline/qonline_free_bg_3.png"),
  }
]


function ListPlan(props) {
  return (
    <div className="qonline-free-wrap-list-video">
      {
        props.listPlan.map((plan, index) => {
          return <QOnlineItemPlan {...plan} length={props.listPlan.length} onClick={() => props.onClick(plan)} />
        })
      }
    </div>
  )
}
function QOnlineBanner(props) {
  return (
    <div className="qonline-free-banner">
      <span style={{ color: props.theme.color }} className="qonline-free-banner-title">Kế hoạch giáo dục</span>
      <LazyImage
        placeHolder={ImagePlaceHolder}
        src={require("../../../../assets/image/qonline/qonline_free_plan_bg.svg")}
        width={"280px"}
        height={`auto`}
        effect={"opacity"}
        alt=""
      />
    </div>
  )
}

function PlanContent(props) {
  const { currentPlan, isCollapse } = props;

  if (!currentPlan) return <div style={{ flex: "1" }} />
  return (
    <div className={!isCollapse ? "qonline-free-row-left-video" : "qonline-free-row-left-video qonline-free-frame-video-big"}>
      <div className={isCollapse ? "qonline-free-media qonline-free-media-big" : "qonline-free-media"}>
        <img
          src={Utils.imageUrl(currentPlan.thumbnailUrl)}
        />
      </div>

      <span className="qonline-free-title-video">{`Tháng ${currentPlan.month}: ${currentPlan.title}`}</span>
      <ServerUI
        extraClassName={["qonline-text-sv"]}
        content={currentPlan.description}
      />
    </div>
  )
}

class QOnlinePlan extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      listPlan: [],
      isCollapse: false,
      month: {
        text: "Chọn tháng",
        value: 0
      },
      currentPlan: null,
      openMenu: false
    }
  }

  componentDidMount() {
    var type = this.getType();
    this.fetchPlan(type)
  }


  fetchPlan = (type) => {
    ApiHelper.get(Constants.GET_FREE_PLAN(type))
      .then(({ data }) => {
        console.log('agePlans:', data);
        if (data.agePlans.length >= 1) {
          this.setState({
            listPlan: data.agePlans,
            currentPlan: data.agePlans[0],
          });
        } else {
          this.setState({
            listPlan: [],
            currentPlan: null,
          })
        }

      })
      .catch((error) => {

      });
  }

  getType = () => {
    var params = new URLSearchParams(window.location.search);
    var tabIndex = params.get('tab');
    if (tabIndex) return tabIndex
    return 1
  }

  handleCollapse = () => {
    this.setState((prevState) => ({
      isCollapse: !prevState.isCollapse
    }))
  }

  onSelectMenu = (month) => {
    this.setState({ month: month })
  }


  handleOpenMenu = () => {
    this.setState((prevState) => ({
      openMenu: !prevState.openMenu
    }))
  }

  render() {
    const { isCollapse, month, listPlan, currentPlan, openMenu } = this.state;
    const theme = this.context;
    const tab = TabConfig[this.getType() - 1];
    return (
      <div style={{ background: theme.background }}>
        <QOnlineBanner theme={theme} />
        <div className="qonline-free-tabs">
          <div className="qonline-free-wrap-tab">
            <Tab
              href="/q-online/plan?tab=1"
              isActive={this.getType() == 1}
              title="Trẻ 0 - 1 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_01.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_01_active.svg")}
            />
            <Tab
              href="/q-online/plan?tab=2"
              isActive={this.getType() == 2}
              title="Trẻ 1 - 2 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_12.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_12_active.svg")}
            />
            <Tab
              href="/q-online/plan?tab=3"
              isActive={this.getType() == 3}
              title="Trẻ 2 - 3 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_23.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_23_active.svg")}
              isLast={true}
            />
          </div>
        </div>
        <div className="qonline-free-body">
          <div className="qonline-free-row-video">
            <PlanContent isCollapse={isCollapse} currentPlan={currentPlan} />

            {/* FILTER */}
            <div className={!isCollapse ? "qonline-free-row-list-right" : "qonline-free-row-list-right qonline-free-right-close"}>

              <div className="qonline-free-wrap-search"
              >

                {
                  !isCollapse ?
                    <div className="qonline-free-filter-item-wrap"
                      onClick={(event) => this.handleOpenMenu(event)}
                    >
                      {
                        openMenu && <MenuFilter
                          onClick={(value) => this.onSelectMenu(value)}
                        />
                      }
                      <span>{month.text}</span>
                      <img src={require("../../../../assets/image/qonline/qonline_ic_dropdown.svg")} />
                    </div>
                    :
                    null
                }

              </div>
              <h1 className={!isCollapse ? "qonline-free-title-list-video" : "qonline-free-title-list-video qonline-free-title-list-video-rotate"}>DANH SÁCH BÀI GIẢNG</h1>
              {
                !isCollapse ? <ListPlan listPlan={month.value == 0 ? listPlan : listPlan.filter(item => item.month == month.value)} onClick={(plan) => this.setState({ currentPlan: plan })} /> : null
              }

              <div className="qonline-free-btn-hide"
                onClick={() => this.handleCollapse()}
              >
                {!isCollapse ? <span>Ẩn</span> : null}
                <img className={isCollapse ? "qonline-free-icon-show" : ""} src={require("../../../../assets/image/qonline/qonline-free-arrow-hide.svg")} />
              </div>
            </div>
          </div>
        </div>
        {/* blank footer */}
        <div style={{ position: "relative", width: "100%", height: "400px", background: theme.background }}>
          <div className="qonline-wrap-img-bg">
            <img src={tab.image} />
          </div>
        </div>
      </div>
    )

  }
}
QOnlinePlan.contextType = FreeQLayoutContext;

export default QOnlinePlan;