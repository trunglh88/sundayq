import "./qonline-free.css";
import React from 'react'
import QOnlineItemVideo from "./QOnlineItemVideo"
import QOnlineKit from '../component/QOnlineKit';
import VideoPlayer from '../../../../component/Media/VideoPlayer'
import MenuFilter from "../component/MenuFilter"
import { ApiHelper } from '../../../../services/apis/ApiHelper';

import { Constants, Utils } from '../../../../utils';
import ServerUI from '../../../../component/Container/ServerUI';
import Tab from "../component/Tab";
import { FreeQLayoutContext } from '../../../../context/FreeQLayoutContext'
import ImagePlaceHolder from "../../../../assets/image/qonline/image_placeholder.png"
import LazyImage from "../../../../component/Lazyloading/LazyImage";

const TabConfig = [
  {
    type: 1,
    title: "BÀI GIẢNG MẪU CHO TRẺ 0 - 1 TUỔI",
    color: "#F57878",
    image: require("../../../../assets/image/qonline/qonline_free_bg_1.png"),
  },
  {
    type: 2,
    title: "BÀI GIẢNG MẪU CHO TRẺ 1 - 2 TUỔI",
    color: "#F57878",
    image: require("../../../../assets/image/qonline/qonline_free_bg_2.png"),
  },
  {
    type: 3,
    title: "BÀI GIẢNG MẪU CHO TRẺ 2 - 3 TUỔI",
    color: "#2E72AD",
    image: require("../../../../assets/image/qonline/qonline_free_bg_3.png"),
  }
]


function ListVideo(props) {
  return (
    <div className="qonline-free-wrap-list-video">
      {
        props.listVideo.map((video, index) => {
          return <QOnlineItemVideo {...video} isPlaying={video.id == props.videoIsPlaying} index={index} length={props.listVideo.length} onClick={() => props.onClick({ index: index, ...video })} />
        })
      }
    </div>
  )
}

function QOnlineBanner(props) {
  return (
    <div className="qonline-free-banner">
      <span style={{color: props.theme.color}} className="qonline-free-banner-title">Bài giảng mẫu</span>
      <LazyImage
        placeHolder={ImagePlaceHolder}
        src={require("../../../../assets/image/qonline/qonline-free-banner.svg")}
        width={"280px"}
        height={`auto`}
        effect={"opacity"}
        alt=""
      />
    </div>
  )
}

class QOnlineFreeTrial extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      listVideo: [],
      isCollapse: false,
      month: { text: "Tháng 1", value: 1 },
      currentVideo: null,
      kit: null,
      openMenu: false
    }
  }

  componentDidMount() {
    var type = this.getType();
    this.fetchLesson(type, 1)
  }

  fetchLesson = (type, month) => {
    ApiHelper.get(Constants.GET_FREE_LESSON(type, month))
      .then(({ data }) => {
        console.log('Lesson:', data);
        if (data.lessons.length >= 1) {
          this.setState({
            listVideo: data.lessons[0].resources,
            currentVideo: { index: 0, ...data.lessons[0].resources[0] },
            kit: data.lessons[0].kit
          });
        } else {
          this.setState({
            listVideo: [],
            currentVideo: null,
            kit: null
          })
        }

      })
      .catch((error) => {

      });
  }

  getType = () => {
    var params = new URLSearchParams(window.location.search);
    var tabIndex = params.get('tab');
    if (tabIndex) return tabIndex
    return 1
  }

  handleCollapse = () => {
    this.setState((prevState) => ({
      isCollapse: !prevState.isCollapse
    }))
  }

  onSelectMenu = (month) => {
    this.setState({ month: month })
    var type = this.getType();
    this.fetchLesson(type, month.value)
  }

  // requestData = () => {
  //   //prepare data
  //   var type = this.getType();
  //   var { month } = this.state;
  //   console.log("Data", type, month);
  //   this.fetchLesson(type, month.value)
  // }
  handleOpenMenu = () => {
    this.setState((prevState) => ({
      openMenu: !prevState.openMenu
    }))
  }

  render() {
    const { isCollapse, month, listVideo, currentVideo, kit, openMenu } = this.state;
    let theme = this.context;
    const tab = TabConfig[this.getType() - 1];
    return (
      <div style={{background: theme.background}}>
        <QOnlineBanner theme={theme}/>
        <div className="qonline-free-tabs">
          <div className="qonline-free-wrap-tab">
            <Tab
              href="/q-online/sample?tab=1" 
              isActive={this.getType() == 1}
              title="Trẻ 0 - 1 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_01.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_01_active.svg")}
            />
            <Tab
              href="/q-online/sample?tab=2" 
              isActive={this.getType() == 2}
              title="Trẻ 1 - 2 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_12.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_12_active.svg")}
            />
            <Tab
              href="/q-online/sample?tab=3" 
              isActive={this.getType() == 3}
              title="Trẻ 2 - 3 tuổi"
              img={require("../../../../assets/image/qonline/qonline_ictab_23.svg")}
              imgActive={require("../../../../assets/image/qonline/qonline_ictab_23_active.svg")}
              isLast={true}
            />
            </div>
        </div>
        <div className="qonline-free-body">
          <div className="qonline-free-row-video">
            <div className={!isCollapse ? "qonline-free-row-left-video" : "qonline-free-row-left-video qonline-free-frame-video-big"}>
              <span className="qonline-free-title-tab">{tab.title}</span>
              <div className={isCollapse ? "qonline-free-media qonline-free-media-big" : "qonline-free-media"}>
                <VideoPlayer
                  url={currentVideo != null ? Utils.videoUrl(currentVideo.fileUrl, 720) : ""}
                  playing={true}
                />
              </div>

              <span className="qonline-free-title-video">{currentVideo != null ? `Video ${currentVideo.index + 1}/${listVideo.length}: ${currentVideo.title}` : ""}</span>
              {
                currentVideo != null ?
                  <ServerUI
                    content={currentVideo.description}
                  /> : null
              }
            </div>
            {/* FILTER */}
            <div className={!isCollapse ? "qonline-free-row-list-right" : "qonline-free-row-list-right qonline-free-right-close"}>

              <div className="qonline-free-wrap-search"
              >

                {
                  !isCollapse ?
                    <div className="qonline-free-filter-item-wrap"
                      onClick={(event) => this.handleOpenMenu(event)}
                    >
                      {
                        openMenu && <MenuFilter
                          onClick={(value) => this.onSelectMenu(value)}
                        />
                      }
                      <span>{month.text}</span>
                      <img src={require("../../../../assets/image/qonline/qonline_ic_dropdown.svg")} />
                    </div>
                    :
                    null
                }

                {/* <div className="qonline-free-btn-filter"
                onClick={() => this.requestData()}
              >
                <img src={require("../../../../assets/image/qonline/qonline_ic_filter.svg")} />
                {!isCollapse ? <span>Lọc</span> : null}

              </div> */}
              </div>
              <h1 className={!isCollapse ? "qonline-free-title-list-video" : "qonline-free-title-list-video qonline-free-title-list-video-rotate"}>DANH SÁCH VIDEO</h1>
              {
                !isCollapse ? <ListVideo videoIsPlaying={Boolean(currentVideo) ? currentVideo.id : ""} listVideo={listVideo} onClick={(video) => this.setState({ currentVideo: video })} /> : null
              }

              <div className="qonline-free-btn-hide"
                onClick={() => this.handleCollapse()}
              >
                {!isCollapse ? <span>Ẩn</span> : null}
                <img className={isCollapse ? "qonline-free-icon-show" : ""} src={require("../../../../assets/image/qonline/qonline-free-arrow-hide.svg")} />
              </div>
            </div>
          </div>
          {/* KIT */}
          <div className="qonline-wrap-kit">
            <div className="qonline-free-row-left-kit">
              {
                Boolean(kit) && <QOnlineKit {...kit} />
              }

            </div>

          </div>
        </div>
        {/* blank footer */}
        <div style={{ position: "relative", width: "100%", height: "400px", background: theme.background }}>
          <div className="qonline-wrap-img-bg">
            <img src={tab.image} />
          </div>
        </div>
      </div>
    )

  }
}

QOnlineFreeTrial.contextType = FreeQLayoutContext;
export default QOnlineFreeTrial;