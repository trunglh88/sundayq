// base home screen for user logined
import React from "react";

class RegisterScreen extends React.Component {
  constructor(props){
    super(props);
    this.state = {

    }
  }

  componentDidMount(){

  }

  render(){
    return (
      <span>RegisterScreen</span>
    )
  }

}

export default RegisterScreen;