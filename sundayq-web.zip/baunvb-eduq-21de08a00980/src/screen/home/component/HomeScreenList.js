import React from 'react'
import './first-list.css'
import SectionInner from "../../../component/Container/SectionInner";
import MemberAndShop from "../../../component/ListItem/MemberAndShop";
export default class HomeScreenList extends React.Component {

  render() {
    return (
      <div>
        <SectionInner extraClassName={['home-screen-block-margin-bottom']}>
          <div className="home-screen-list-first-flex">
            <a href="/q-visit/class" style={{ background: "#fff" }} className="home-screen-list-first-item">
              <span style={{ color: "#035AA6" }} className="home-screen-list-first-title">Học viện SundayQ</span>
              <div>
                <img src={require("../../../assets/image/home-src-list1-item1.svg")} />
              </div>
              <span style={{ color: "#000" }} className="home-screen-list-first-des">Đăng kí ngay các khóa học để được tận hưởng môi trường học tập khoa học chất lượng hàng đầu.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </a>

            <a href="/q-online" style={{ background: "#fff" }} className="home-screen-list-first-item">
              <span style={{ color: "#035AA6" }} className="home-screen-list-first-title">SundayQ tại nhà</span>
              <div>
                <img src={require("../../../assets/image/home-scr-list1-item2.svg")} />
              </div>
              <span style={{ color: "#000" }} className="home-screen-list-first-des">Thỏa sức khám phá khoa học mọi lúc mọi nơi ngay tại chính ngôi nhà thân yêu.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </a>

            <a href="/q-visit/tour" style={{ background: "#371B63" }} className="home-screen-list-first-item">
              <span style={{ color: "#FFFFFF" }} className="home-screen-list-first-title">Trải nghiệm và triển lãm</span>
              <div style={{ background: "#371B63" }}>
                <img src={require("../../../assets/image/home-src-list1-item3.svg")} />
              </div>
              <span style={{ color: "#fff" }} className="home-screen-list-first-des">Khám phá những triển lãm khoa học độc đáo, những trải nghiệm vui chơi thú vị chỉ có tại SundayQ.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </a>

            <a href="/q-visit/event"style={{ background: "#371B63" }} className="home-screen-list-first-item">
              <span style={{ color: "#FFFFFF" }} className="home-screen-list-first-title">Q-Tour</span>
              <div style={{ background: "#371B63" }}>
                <img src={require("../../../assets/image/home-src-list1-item4.svg")} />
              </div>
              <span style={{ color: "#fff" }} className="home-screen-list-first-des">Tham gia các tour trải nghiệm thực tế là cách để trẻ tự do khám phá thế giới và khơi dậy niềm đam mê.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </a>
          </div>
        </SectionInner>
        <SectionInner extraClassName={['home-screen-full-width']}>
          <MemberAndShop/>
        </SectionInner>
      </div>
    )
  }
}