import React from 'react'
import './home-screen.css';
import TopHeader from "../../component/Header/TopHeader";
import HomeHeader from "../../component/Header/HomeHeader";
import { QAcademyRouter } from "../../router/QAcademyRouter"
import TopFooter from "../../component/Footer/TopFooter"
import Footer from "../../component/Footer/Footer"
import BottomFooter from "../../component/Footer/BottomFooter";
import SectionInner from "../../component/Container/SectionInner";
import { Constants } from '../../utils';
import ListSocial from "../../component/Social/ListSocial";
import HomeScreenList from "./component/HomeScreenList";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import FooterSlogan from '../../component/Slogan/FooterSlogan'

const ImageSlide = [
  require("../../assets/image/qacademy_panel_1.JPG"),
  require("../../assets/image/qacademy_panel_2.JPG"),
  require("../../assets/image/qacademy_panel_3.JPG"),
  require("../../assets/image/qacademy_panel_4.JPG"),
  require("../../assets/image/qacademy_panel_5.JPG"),
  require("../../assets/image/qacademy_panel_6.JPG"),
]

const SlideOption = {

}

export default class HomeScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false
    }
  }

  componentDidMount() {
    console.log("HOME")
  }

  onIconMenuClick = (value) => {
    this.setState({
      isMenuOpen: value
    })
  }
  render() {
    return (
      <div>
        <TopHeader onIconMenuClick={this.onIconMenuClick} />

        <div className="home-screen-main-content">
          <HomeHeader extraClassName={['home-screen-transparent-header']} isOpen={this.state.isMenuOpen} router={QAcademyRouter} {...this.props} />
          <SectionInner extraClassName={['home-screen-wrap-slider', 'home-screen-full-width']}>
            <Carousel
              showThumbs={false}
              showStatus={false}
              autoPlay={true}
              interval={3000}
              infiniteLoop={true}
            >
              {
                ImageSlide.map((item) => {
                  return (
                    <div>
                      <img src={item} />
                      {/* <p className="legend"></p> */}
                    </div>
                  )
                })
              }
            </Carousel>
          </SectionInner>

          <SectionInner extraClassName={['home-screen-full-width']}>
            <div className="home-screen-content-info">
              <div className="home-screen-content-info-col">
                <div>
                  <div className="home-screen-content-label-item">
                    <img src={require("../../assets/icon/time_icon_home.svg")} />
                    <span className="home-screen-content-label-item-title">Giờ mở cửa</span>
                  </div>
                  <div className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text">Từ 8h sáng đến 20h tối</span>
                  </div>
                </div>

                <div>
                  <div className="home-screen-content-label-item">
                    <img src={require("../../assets/icon/ic_marker.svg")} />
                    <span className="home-screen-content-label-item-title">Chúng tôi ở</span>
                  </div>
                  <div className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text">{Constants.COMPANY_PROFILE.ADDRESS}</span>
                  </div>
                </div>

                <div>
                  <div className="home-screen-content-label-item">
                    <img src={require("../../assets/icon/ic_message.svg")} />
                    <span className="home-screen-content-label-item-title">Liên lạc</span>
                  </div>
                  <div className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text home-screen-content-align-center">
                      <img src={require("../../assets/icon/home_icon_phone.svg")} />
                      <span className="home-screen-content-label-item-row-text-bold">Dịch vụ: </span>
                      <a href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a>
                    </span>
                    <span className="home-screen-content-label-item-row-text home-screen-content-align-center">
                      <img src={require("../../assets/icon/home_icon_phone.svg")} />
                      <span className="home-screen-content-label-item-row-text-bold">Kinh doanh: </span>
                      <a href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_BIZ}`}>{Constants.COMPANY_PROFILE.HOTLINE_BIZ}</a>
                    </span>
                    <span className="home-screen-content-label-item-row-text home-screen-content-align-center">
                      <img src={require("../../assets/icon/home_icon_email.svg")} />
                      <a href={`mailto: ${Constants.COMPANY_PROFILE.EMAIL}`}>{Constants.COMPANY_PROFILE.EMAIL}</a>
                    </span>
                  </div>
                </div>

                <div>
                  <div className="home-screen-content-label-item">
                    <img src={require("../../assets/icon/ic_calendar.svg")} />
                    <span className="home-screen-content-label-item-title">Các sự kiện tại SundayQ</span>
                  </div>
                  <div className="home-screen-content-label-item-row-flex-center home-screen-content-label-item-row-last">
                    <a href="/q-visit/event" className="home-screen-content-label-item-row-text">Xem các sự kiện tại SundayQ</a>
                    <img className="home-screen-content-label-item-row-navigate" src={require("../../assets/icon/ic_navigate.svg")} />
                  </div>
                </div>
              </div>

              <div className="home-screen-content-info-col">
                <div>
                  <div className="home-screen-content-label-item home-screen-content-label-extra">
                    <img src={require("../../assets/icon/ic_ticket.svg")} />
                    <span className="home-screen-content-label-item-title">Giá vé</span>
                  </div>
                  <div style={{ justifyContent: "space-between", display: "flex" }} className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">Người lớn</span>
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">80.000/buổi</span>
                  </div>

                  <div style={{ justifyContent: "space-between", display: "flex" }} className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">Trẻ em</span>
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">120.000/buổi</span>
                  </div>

                  <div style={{ justifyContent: "space-between", display: "flex" }} className="home-screen-content-label-item-row">
                    <span style={{ marginRight: "8px" }} className="home-screen-content-label-item-row-text home-screen-mobile-small-size">Gia đình (2 người lớn, 2 trẻ em)</span>
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">200.000/buổi</span>
                  </div>

                  <div style={{ justifyContent: "space-between", display: "flex" }} className="home-screen-content-label-item-row">
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">Thành viên</span>
                    <span className="home-screen-content-label-item-row-text home-screen-mobile-small-size">Giảm 20%</span>
                  </div>

                  <span className="home-screen-link-to-course home-screen-mobile-small-size">Giá khóa học và Workshop: <a href="/q-academy">xem chi tiết</a> tại từng khóa học</span>

                </div>

                <div>
                  <div className="home-screen-content-label-item">
                    <img src={require("../../assets/icon/ic_social_follow.svg")} />
                    <span className="home-screen-content-label-item-title">Theo dõi</span>
                  </div>
                  <div style={{ border: "none" }} className="home-screen-content-label-item-row">
                    <ListSocial />
                  </div>
                </div>

              </div>

            </div>
          </SectionInner>

          <HomeScreenList />
          <FooterSlogan />

        </div>
        <TopFooter />
        <Footer />
        <BottomFooter />
      </div>
    )
  }
}