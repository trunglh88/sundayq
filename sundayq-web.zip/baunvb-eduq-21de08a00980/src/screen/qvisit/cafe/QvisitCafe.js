import React from 'react';
import './q-visit-cafe-screen.css';

const DESCRIPTION_1 = 'SundayQ Café nằm tại khu căng tin của trung tâm, mở cửa từ 9 giờ sáng đến 6 giờ chiều. Chúng tôi rất vui mừng được tiếp đón các bạn tại Q-café với một vài món ăn nhẹ, đồ tráng miệng, cà phê, nước giải khát,.. Nơi đây sẽ là lựa chọn thuận tiện và tuyệt vời cho cả gia đình!\n\n';
const DESCRIPTION_2 = 'Đến với SundayQ Café và tận hưởng những dịch vụ tốt nhất của chúng tôi!';

const DESCRIPTION_3_1 = 'SundayQ Café sẽ đưa ra các menu bữa trưa và các bữa ăn phụ cho từng lớp, từng lứa tuổi phù hợp với khẩu vị của các bạn học viên.';
const DESCRIPTION_3_2 = 'SundayQ Café đảm bảo sẽ cung cấp thực phẩm tươi ngon, bổ dưỡng, đồ uống đa dạng, hấp dẫn đến tất cả các khách hàng. Bên cạnh đó, SundayQ Café sẽ cố gắng không ngừng cải thiện thực đơn, đưa ra những menu mới để đáp ứng nhu cầu của khách hàng.';
const DESCRIPTION_3_3 = 'Vì vậy, nếu Quý vị có bất kỳ yêu cầu, thắc mắc hay nhận xét nào, xin vui lòng liên hệ với chúng tôi theo số điện thoại (0917072756).';
const DESCRIPTION_3_4 = 'Hoặc xin vui lòng truy cập vào website: ';

export default class QVisitCafe extends React.Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    bottomPart = () => {
        return (
            <div className="qvisit-cafe-bottom-container">
                <span className="qvisit-common-title">Phục vụ ăn cho học viên tại trung tâm:</span>
                <span className="qvisit-cafe-description-3">
                    <p>{DESCRIPTION_3_1}</p>
                    <p>{DESCRIPTION_3_2}</p>
                    <p>{DESCRIPTION_3_3}</p>
                    <p>
                        {DESCRIPTION_3_4}
                        <a>
                            {'http://sundayq.com.'}
                        </a>
                    </p>
                </span>
            </div>
        );
    };

    render() {
        return (
            <div>
                <div className="qvisit-cafe-top-view-container">

                    <span className="qvisit-cafe-top-view-text-area">
                    <img src={require("../../../assets/image/qvisit-cafe-img.png")} className="qvisit-cafe-top-view-image" />

                        <span className="qvisit-cafe-description-1">
                            {DESCRIPTION_1}
                        </span>
                        <span className="qvisit-cafe-description-2">
                            {DESCRIPTION_2}
                        </span>

                    </span>

                </div>
                {this.bottomPart()}
            </div>
        );
    }
}
