import React from 'react';
import './qvisit-sidebar.css'
import './common.css'
import { QVisitRouter } from '../../../router/QVisitRouter'
import IconButton from '@material-ui/core/IconButton';
import ArrowDropDown from '@material-ui/icons/ArrowDropDown';
import {connect} from 'react-redux';

const screenWidth = window.innerWidth;

class QVisitSidebar extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      isOpen: screenWidth <= 768 ? false : true
    }
  }

  onOpenMenu() {
    this.setState((prevState) => ({
      isOpen: !prevState.isOpen,
    }));
}

  isActive = (path) => {
    let pathName = window.location.href;
    return pathName.includes(path);
  }

  render() {
    // let pathName = window.location.href;
    let pathName = this.props.location.pathname
    let { isOpen } = this.state;
    let index = QVisitRouter.findIndex((item) => pathName.includes(item.path))
    return (
      <div className="qvisit-sidebar-main">
        <div className="qvisit-sidebar-header">
          <span>
            {
              pathName.includes("/q-visit/post") ? this.props.title : QVisitRouter[index].name
            }
          </span>
          <div className="qvisit-sidebar-wrap-dropdown">
            <IconButton
              onClick={() => this.onOpenMenu()}
            >
              <ArrowDropDown classes={{ root: "qvisit-sidebar-dropdown" }} />
            </IconButton>
          </div>

        </div>
        <div className={this.state.isOpen ? "qvisit-sidebar-wrap-menu qvisit-sidebar-wrap-menu-open" : "qvisit-sidebar-wrap-menu"} >
          <div style={{display: isOpen ? "block" : "none"}}>{
            QVisitRouter.map((item) => {
              if (!item.invisibleInTabBar) {
                let itemClass = "qvisit-sidebar-link";
                if (this.isActive(item.path)) itemClass += " qvisit-sidbar-link-active";
                return (
                  <a className={itemClass} href={item.path}>
                    {item.name}
                  </a>
                )
              }
            })
          }
          </div>
        </div>

      </div>
    )
  }

}

const mapDispatchStateToProps = state => {
  return {
      title: state.qVistiReducer.title
  };
};
export default connect(mapDispatchStateToProps, null) (QVisitSidebar)