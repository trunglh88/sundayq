import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';

export const fetchPostData = async (type, id) => {
    switch (type) {
        case 'tour':
            //fake content course
            var data = await ApiHelper.get(Constants.GET_EXHIBITION_INFORMATION(id));
            return data;
            break;
        case 'event':
            //fake content course
            var data = await ApiHelper.get(Constants.GET_EVENT_INFORMATION(id));
            return data;
            break;
        default:
            return null;
    }
}