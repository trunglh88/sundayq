import React from 'react';
import './qvisit-post.css';
import { Utils } from '../../../utils';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';
import {fetchPostData} from './PostDataHandler'
import ServerUI from '../../../component/Container/ServerUI'
import {connect} from 'react-redux'
import { fetchPostTitle } from '../QVisitAction';

class QVisitPostDetailScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: null
        }
        const params = new URLSearchParams(window.location.search);
        this.type = params.get('type');
        this.id = params.get('id')
    }

    async componentDidMount() {
        let data = await fetchPostData(this.type, this.id);
        console.log("Data post:", data.data)
        this.setState({
            data: data.data
        })
        this.props.fetchPostTitle(data.data.title);
    }

    render() {
        const { data } = this.state;
        return (
            data != null ?
                <div>
                    {/* post's title */}
                    <span id="qvisit-layout-title" className="qvisit-post-title">{data.title}</span>
                    <ServerUI content={data.description}>

                    </ServerUI>
                </div> : null
        )

    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchPostTitle: (title) => {
            dispatch(fetchPostTitle(title));
        },
    };
};

export default connect(null, mapDispatchToProps)(QVisitPostDetailScreen)