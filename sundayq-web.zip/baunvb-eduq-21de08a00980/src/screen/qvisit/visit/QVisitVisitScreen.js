import React from 'react'
import './qvisit-visit-screen.css'
import SectionInner from "../../../component/Container/SectionInner";
import Map from "../../../component/Map/Map";
export default class QVisitVisitScreen extends React.Component {

  render() {
    return (
      <div>
        <span className="qvisit-common-title">{'SundayQ – Ngày chủ nhật khoa học'.toUpperCase()}</span>
        <img className="qvisit-visit-home-img" src={require("../../../assets/image/visit_visit_img_header.png")} />
        <span className="qvisit-common-paragraph">
          Trung tâm vui chơi trải nghiệm Khoa học Công nghệ và Sáng tạo SundayQ - Ngày Chủ nhật Khoa học thúc đẩy sự hiểu biết và nhận thức sâu sắc hơn về khoa học và công nghệ trong cộng đồng. Đặc biệt, Trung tâm hướng tới việc khơi gợi và thắp sáng niềm đam mê về khoa học và sáng tạo cho các bạn nhỏ. SundayQ cam kết mang đến những trải nghiệm thú vị, có chất lượng cao tới người tham quan cũng như các học viên thân yêu.
        </span>
        <span className="qvisit-common-title">{'Giờ Tham Quan'.toUpperCase()}</span>
        <span className="qvisit-common-paragraph">
          Thời gian hoạt động tham quan vui chơi: bắt đầu 8 giờ sáng đến 20 giờ tối, từ thứ Hai đến Chủ Nhật Bên cạnh đó Trung tâm SundayQ thường xuyên tổ chức các sự kiện, các buổi triển lãm hội thảo, workshop để mọi người có thể đến tham quan và trực tiếp trải nghiệm, thực tập, thực hành.
        </span>

        <a className="qvisit-visit-home-link">Đặt mua</a>
        {/* gắn link qshop */}
        <a className="qvisit-visit-home-link">Xem thông tin nhắc nhở</a>

        <span className="qvisit-common-title">VÉ</span>

        <table className="qvisit-visit-home-table">
          <tr>
            <td>Người lớn</td>
            <td>80.000 VNĐ/buổi</td>
          </tr>
          <tr>
            <td>Trẻ em</td>
            <td>120.000 VNĐ/buổi</td>
          </tr>
          <tr>
            <td>Gia đình (2 người lớn, 2 trẻ em)</td>
            <td>200.000 VNĐ/buổi</td>
          </tr>
          <tr>
            <td>Khóa học & Workshop</td>
            <td>Tham khảo chi tiết tại từng khóa học</td>
          </tr>
          <tr>
            <td>Thành viên</td>
            <td>Giảm 20%</td>
          </tr>
        </table>

        <span className="qvisit-common-title">{'Bản đồ hướng dẫn'.toUpperCase()}</span>
        <div className="qvisit-visit-home-map">
          <Map
            id="myMap"
            width={"100%"}
            height={324}
            options={{
              center: { lat: 21.084418, lng: 105.812180 },
              zoom: 13,
              mapTypeControl: false
            }}
            onMapLoad={map => {
              var marker = new window.google.maps.Marker({
                draggable: false,
                animation: window.google.maps.Animation.DROP,
                position: { lat: 21.084418, lng: 105.812180 },
                map: map,
              });
            }}
          />
        </div>
        <span className="qvisit-common-paragraph">
          Sunshine Riverside nằm ở cuối đường Võ Chí Công, cách chân cầu Nhật Tân 500m và nằm gần khu đô thị Nam Thăng Long (Ciputra, Hà Nội).
        </span>
        <span className="qvisit-common-title">{'Phương tiện công cộng'.toUpperCase()}</span>

        <span className="qvisit-visit-home-subtitle">Xe bus</span>
        <span className="qvisit-common-paragraph">
          Các tuyến xe bus có điểm dừng gần Trung tâm SundayQ: <br />
        • Tuyến 07 (Dừng tại điểm bus đối diện KĐT Nam Thăng Long sau đó đi bộ thêm 1km) <br />
        • Tuyến 25 (Dừng tại điểm bus đối diện KĐT Nam Thăng Long sau đó đi bộ thêm 1km) <br />
        • Tuyến 55B (Dừng tại điểm bus 596 Lạc Long Quân sau đó đi bộ thêm 800m)
        </span>

        <span className="qvisit-visit-home-subtitle">Bãi đỗ xe</span>
        <span className="qvisit-common-paragraph">
          Quý vị có thể đỗ xe ngay tại dưới khu tầng hầm của Chung cư Sunshine Riverside. Chung cư gồm có 2 tầng hầm để xe thông minh với hệ thống thang máy hiện đại từ bãi đỗ xe đến Tầng 3 nơi Trung tâm.
        </span>
        <img className="qvisit-visit-home-img-3d-map" src={require("../../../assets/image/qvisit_3d_map.png")} />

      </div>
    )
  }
}
