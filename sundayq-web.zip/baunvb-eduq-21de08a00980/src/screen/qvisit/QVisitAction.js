import { createActionSet } from '../../services/actions';

export const FETCH_POST_TITLE = createActionSet('FETCH_POST_TITLE');

export const fetchPostTitle = (title) => ({
    type: FETCH_POST_TITLE.SUCCESS,
    data: title
});
