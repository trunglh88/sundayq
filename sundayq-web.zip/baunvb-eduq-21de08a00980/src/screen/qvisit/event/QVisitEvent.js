import React from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './qvisit-event-screen.css';
import moment from 'moment';
import * as Controller from './EventDataHandler';
import { Utils } from '../../../utils';

const FIXED_RESULT = [{
    createAt: '2020-08-21T14:25:18.895Z',
    descriptionImgUrl: 'resource/image/f67e429db8fea370c71ee392eb4d3857-1594739737575.jpg',
    finishAt: '2020-08-21T00:00:00.000Z',
    id: 'ada517e6a74ab4091200c6a1fa2bfb1d1598019918895',
    serviceId: 'q-visit',
    shortDescription: 'Bộ Ngoại giao và Bộ Quốc phòng Anh đã gửi cho phía Mỹ',
    startAt: '2020-08-21T00:00:00.000Z',
    title: 'Sự kiện thứ nhất',
    updateAt: '2020-08-27T13:09:09.255Z',
    viewIndex: 0,
}, {
    createAt: '2020-08-26T07:50:46.973Z',
    descriptionImgUrl: 'resource/image/ea6fdec7b268e79171b6a0320778cd7e-1598534078607.jpg',
    finishAt: '2020-08-26T00:00:00.000Z',
    id: 'edf96258bba113a6e531f6832bbe5fe41598428246973',
    serviceId: 'q-visit',
    shortDescription: 'Giới chuyên viên quân sự quốc tế đã đi sâu phân tích',
    startAt: '2020-08-26T00:00:00.000Z',
    title: 'Sự kiện thứ năm',
    updateAt: '2020-08-27T13:15:44.477Z',
    viewIndex: 999999999,
}];

export default class QVisitEvent extends React.Component {

    constructor(props) {
        super(props);
        const currentDate = moment().startOf('day').toDate();

        this.initialState = {
            keyword: '',
            queryStartDate: currentDate,
            queryEndDate: currentDate,
            loading: false,
            results: null,
        };

        // this.state = { ...this.initialState, ...{ results: FIXED_RESULT } };
        this.state = { ...this.initialState }
    }

    datePickerSection = () => {
        const { queryStartDate, queryEndDate } = this.state;
        const { loading } = this.state;

        const { results } = this.state;
        const newQueryButtonVisible = (results !== null);

        return (
            <div className="qvisit-event-date-picker-section">
                <div className='qvisit-event-date-picker-container'>
                    <DateSelect
                        date={queryStartDate}
                        title={'Ngày bắt đầu'}
                        onChangeDate={(date) => {
                            const { queryEndDate } = this.state;
                            const diffInDate = moment(queryEndDate).diff(date, 'days');
                            if (diffInDate < 0) {
                                this.setState({
                                    queryStartDate: date,
                                    queryEndDate: null,
                                });
                            } else {
                                this.setState({
                                    queryStartDate: date,
                                });
                            }
                        }}
                    />
                    <DateSelect
                        minDate={queryStartDate}
                        date={queryEndDate}
                        containerClass='qvisit-event-end-date-picker'
                        title={'Ngày kết thúc'}
                        onChangeDate={(date) => {
                            const { queryStartDate } = this.state;
                            const diffInDate = moment(date).diff(queryStartDate, 'days');
                            if (diffInDate < 0) {
                                this.setState({
                                    queryStartDate: null,
                                    queryEndDate: date,
                                });
                            } else {
                                this.setState({
                                    queryEndDate: date,
                                });
                            }
                        }}
                    />
                </div>
                {this.searchKeyWordInputField()}
                <div className="qvisit-event-search-buttons-area-container">
                    <div
                        onClick={(loading || newQueryButtonVisible) ? () => {
                        } : () => this.requestEventList()}
                        className={`qvisit-event-search-submit-button ${(loading || newQueryButtonVisible) ? 'qvisit-event-submit-button-disable' : ' box-hover'}`}>
                        {loading ? <div className="loader" /> : 'Áp dụng'}
                    </div>
                    {
                        newQueryButtonVisible &&
                        <div
                            onClick={() => this.resetForm()}
                            className={`qvisit-event-search-submit-button box-hover ${(loading) ? 'qvisit-event-submit-button-disable' : ''}`}>
                            Tìm sự kiện khác
                        </div>
                    }

                </div>
            </div>
        );
    };

    resetForm() {
        this.setState(this.initialState);
    }

    getEventListSuccess(data) {
        this.setState({
            loading: false,
            results: data,
        });
    }

    getEventListError(msg) {
        this.setState({
            errorMsg: msg,
        });
    }

    requestEventList() {
        const { queryStartDate, queryEndDate } = this.state;
        const { keyword } = this.state;
        this.setState({
            loading: true,
        }, () => {
            Controller.requestEventList(queryStartDate, queryEndDate, keyword,
                (data) => this.getEventListSuccess(data),
                (msg) => this.getEventListError(msg),
            );
        });
    }


    searchKeyWordInputField = () => {
        const { keyword } = this.state;
        return (
            <input
                className="qvisit-event-search-keyword"
                placeholder={'Tìm kiếm theo từ khóa'}
                type={'text'}
                onChange={(event) => {
                    this.setState({
                        keyword: event.target.value,
                    });
                }}
                value={keyword}
            />
        );
    };

    searchResultSection() {
        const { results } = this.state;

        const numberOfResults = results ? results.length : 0;
        const displayResultNumber =
            (numberOfResults >= 100) ? numberOfResults : ('00' + numberOfResults).slice(-2);


        return results === null ? <div /> : (
            <div className="search-result-section-outer-container">
                <div className="search-result-section-container">
                    <div
                        className="qvisit-common-title qvisit-event-search-result-title"
                    >
                        {`TÌM ĐƯỢC ${displayResultNumber} KẾT QUẢ`}
                    </div>
                    <div>
                        {
                            results.map(({ title, shortDescription, descriptionImgUrl, id }, index) => (
                                <div className="search-result-item-container">
                                    <img
                                        className="search-result-item-image"
                                        src={Utils.imageUrl(descriptionImgUrl)}
                                        alt="result"
                                    />
                                    <a
                                        href={`/q-visit/post?type=event&id=${id}`}
                                        className="search-result-item-right-view">
                                        <div className="search-result-item-right-view-title">
                                            {title}
                                        </div>
                                        <div className="search-result-item-right-view-description">
                                            {shortDescription}
                                        </div>
                                    </a>
                                </div>
                            ))
                        }
                    </div>
                </div>

            </div>
        );
    }

    render() {
        return (
            <div className="qvisit-event-container">
                {this.datePickerSection()}
                {this.searchResultSection()}
            </div>
        );
    }

}

export function DateSelect(props) {
    const { title } = props;
    const { containerClass } = props;
    const { date, onChangeDate } = props;
    const { minDate } = props;

    const CustomInput = ({ value, onClick }) => {
        const date = value ? moment(value, 'MM/DD/YYYY') : null;

        return (
            <div
                onClick={onClick}
                className="qvisit-date-picker-custom-input box-hover">
                {date ? date.format('DD/MM/YYYY') : 'DD/MM/YYYY'}
            </div>
        );
    };

    return (
        <div className={containerClass}>
            <div className="qvisit-date-picker-title">{title}</div>
            <DatePicker
                placeholderText="MM/DD/YYYY"
                customInput={<CustomInput />}
                selected={date}
                onChange={onChangeDate}
            />
        </div>
    );
}
