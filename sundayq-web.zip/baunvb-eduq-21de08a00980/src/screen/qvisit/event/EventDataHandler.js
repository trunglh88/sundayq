import moment from 'moment';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';

export function requestEventList(start, end, title, successCallback, errorCallback) {
    const startQuery = moment(start).startOf('day').format('YYYY-MM-DDTHH:mm:ss[Z]');
    const endQuery = moment(end).endOf('day').format('YYYY-MM-DDTHH:mm:ss[Z]');

    console.log(startQuery);
    console.log(endQuery);

    ApiHelper.get(Constants.GET_LIST_EVENT(startQuery, endQuery, title || ""))
        .then(({ data }) => {
            console.log("data::", data);
            successCallback(data);
        })
        .catch(error => {
            errorCallback('Có lỗi xảy ra')
        });

}
