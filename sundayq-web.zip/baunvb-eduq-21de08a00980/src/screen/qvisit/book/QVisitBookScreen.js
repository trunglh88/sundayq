import React from 'react'
import './qvisit-book-screen.css'
import { Constants } from "../../../utils"
export default class QVisitBookScreen extends React.Component {
    render() {
        return (
            <div>
                <span className="qvisit-common-title">{'Đặt chỗ theo nhóm'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    Trung tâm vui chơi trải nghiệm Khoa học Công nghệ Sáng tạo SundayQ - Ngày Chủ nhật Khoa học có các chương trình ưu đãi dành cho các Trường học, các Nhóm xã hội và đặc biệt các Nhóm bạn nhỏ. Trung tâm SundayQ có thể tổ chức các sự kiện ngày Hội Khoa Học Công nghệ và Sáng tạo tại các trường và địa phương mong muốn.
                </span>
                <span className="qvisit-common-title">{'Cơ hội đặt chỗ theo nhóm'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    - Phiên có sẵn từ 9h sáng – 3h30 chiều hàng ngày <br />
                    - Có sẵn cho tất cả các cấp, năm học, độ tuổi <br />
                    - Được khuyến mại thêm 30 phút cho chương trình
                </span>
                <span className="qvisit-common-title">{'Đặt chỗ'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    Từ 8 giờ sáng bạn có thể đặt chỗ cho các chuyến tham quan tại website: <a href={Constants.COMPANY_PROFILE.WEB_SITE}>{Constants.COMPANY_PROFILE.WEB_SITE}</a> <br /> <br />
                    Bước đầu tiên bạn sẽ đăng ký làm giáo viên trường học, hướng dẫn viên tour du lịch hoặc nhóm xã hội. <br /> <br />
                    Sau đó bạn vui lòng đặt chỗ qua website của học viện trước chuyến tham quan 2 tuần. Để được giải đáp thêm,
                    vui lòng liên hệ với chúng tôi tại website: <a href={Constants.COMPANY_PROFILE.WEB_SITE}>{Constants.COMPANY_PROFILE.WEB_SITE}</a> hoặc theo số <a href={`tel:${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a>. <br /><br />
                    Nếu bạn gặp vấn đề khi đăng nhập, vui lòng xem phần Tài khoản trên bàn trợ giúp trực tuyến của chúng tôi. <br /><br />
                    Để biết thêm thông tin về cách thực hiện, cập nhật,
                    hủy đặt chỗ hoặc nếu không thể đăng nhập,
                    vui lòng liên hệ tại website: {Constants.COMPANY_PROFILE.WEB_SITE} hoặc theo số {Constants.COMPANY_PROFILE.HOTLINE_CS}.
                    Ngoài ra bạn có thể tham khảo phần Tài khoản trên bàn trợ giúp của chúng tôi.
                </span>
                <span className="qvisit-common-title">THÔNG TIN KHÁCH THAM GIA</span>
                <span className="qvisit-common-paragraph">
                    - SundayQ có rất nhiều triển lãm thực hành trong các <a href="/q-visit/tour">triển lãm và trải nghiệm</a> tương tác cũng như phòng giải trí ngoài trời và Khoa học ngoài trời. <br/>- Các Cửa hàng SundayQ cung cấp một loạt các đồ chơi khoa học tương tác và các món quà lưu niệm với giá cả phải chăng. Mở cửa hàng ngày từ 9 giờ sáng đến 6 giờ chiều. Một loạt các sản phẩm giáo dục cũng có sẵn <a href="/q-shop">online</a>. <br/>- Chúng tôi rất vui mừng khi được chào đón khách tham quan tại SundayQ Café, khách tham quan có các lựa chọn cho bữa trưa, đồ giải khát và đồ ăn nhẹ. Mọi thắc mắc liên quan đến việc đặt bữa trưa theo nhóm vui lòng liên hệ với SundayQ Café trên website <a href={Constants.COMPANY_PROFILE.WEB_SITE}>{Constants.COMPANY_PROFILE.WEB_SITE}</a> hoặc theo số <a href={`tel:${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a>.
                </span>
                <span className="qvisit-common-title">{'Thông tin địa điểm an toàn và bảo hiểm'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    Trách nhiệm bảo đảm an toàn cho học viên thuộc về các giáo viên hoặc người có trách nhiệm của mỗi nhóm liên kết.
                    Mỗi phòng trưng bày đều phải có mặt ít nhất một giáo viên hoặc một người có trách nhiệm ở đó để hướng dẫn các bạn nhỏ thực hiện các hoạt động và đảm bảo an toàn cho các bạn. <br /> <br />
                    Bảo hiểm trách nhiệm và bảo vệ sự an toàn của khách tham gia qua các sáng kiến về Sức khỏe & An toàn tại Nơi làm việc là một phần cốt lõi trong hoạt động của Trung tâm SundayQ. <br /><br />
                    Nếu bạn gặp khó khăn khi truy cập vào một trong các tài liệu trên, xin vui lòng liên hệ với Văn phòng Chương trình trải nghiệm trường học qua các chi tiết bên dưới.<br/>
                </span>

                {/* insert table */}
                {/* <table className="qvisit-book-table">
                    <tr>
                        <td></td>
                        <td>Giá (Mỗi người)</td>
                        <td>Giám sát viên miễn phí vào theo tỉ lệ *</td>
                    </tr>
                    <tr>
                        <td>Trường mầm non</td>
                        <td></td>
                        <td>1:4</td>
                    </tr>
                    <tr>
                        <td>Tiểu học</td>
                        <td></td>
                        <td>1:10</td>
                    </tr>
                    <tr>
                        <td>Trung học cơ cở/ cấp 3</td>
                        <td></td>
                        <td>1:15</td>
                    </tr>
                    <tr>
                        <td>Đại học</td>
                        <td></td>
                        <td>1:15</td>
                    </tr>
                    <tr>
                        <td>Người lớn</td>
                        <td></td>
                        <td>Không có</td>
                    </tr>
                    <tr>
                        <td>Trẻ em</td>
                        <td></td>
                        <td>Không có</td>
                    </tr>
                    <tr>
                        <td>Dưới 4 tuổi</td>
                        <td>Miễn phí **</td>
                        <td>Không có</td>
                    </tr>
                    <tr>
                        <td>Thành viên câu lạc bộ SundayQ</td>
                        <td>Giảm 20%</td>
                        <td>Không có</td>
                    </tr>
                </table> */}

                <span className="qvisit-common-paragraph">
                    Hóa đơn sẽ được xuất sau chuyến thăm. <br />
                Quý khách có thể thanh toán với các hình thức khác nhau như: bằng thẻ, hoặc tiền mặt.<br /><br />
                *Nếu có thêm người giám sát, vé của giám sát viên bổ sung sẽ có giá tương đương với các thành viên trong nhóm người đó quản lí. <br />
                **Khi đi kèm với người lớn trả tiền.
                </span>

                <span className="qvisit-common-title">{'Tiếp nhận'.toUpperCase()}</span>
                <span style={{display: 'block', marginBottom: '67px'}} className="qvisit-common-paragraph">
                    Nếu có bất kì yêu cầu nào thêm xin vui lòng liên hệ với Trung tâm SundayQ theo địa chỉ liên hệ dưới đây. <br />
                    Người liên hệ: Mrs.Xoan <br />
                    Email: <a href={`mailto:${Constants.COMPANY_PROFILE.EMAIL}`}>{Constants.COMPANY_PROFILE.EMAIL}</a> {<br />}
                    Hotline: <a href={`tel:${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a> <br />
                    Website: <a href={`${Constants.COMPANY_PROFILE.WEB_SITE}`}>{Constants.COMPANY_PROFILE.WEB_SITE}</a>
                </span>
            </div>
        )
    }
}
