import React from 'react';
import './qvisit-contactus-screen.css';
import * as Controller from './ContactUsDataHandler';
import SweetAlert from 'react-bootstrap-sweetalert';
import { Constants } from '../../../utils';

const FEEDBACK_DESCRIPTION = 'SundayQ – Ngày chủ nhật khoa học luôn đón nhận phản hồi từ khách hàng. Hãy cho chúng tôi biết những thắc mắc, ý kiến của các bạn bằng cách điền vào trang web Phản hồi của chúng tôi.';
const FEEDBACK_DESCRIPTION_2 = 'Xin vui lòng điền vào mẫu liên hệ dưới đây nếu bạn cần trợ giúp hoặc đóng góp ý kiến.';
const FEEDBACK_DESCRIPTION_3 = 'Mở cửa hàng ngày từ 9 giờ sáng – 6 giờ chiều bao gồm các ngày lễ.';


export default class QVisitContactUs extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            phone: '',
            name: '',
            email: '',
            message: '',
            showAlert: false,
            successAlert: false,
            alertMessage: '',
            feedbackLoading: false,
        };
    }

    informationItem = (label, value) => {
        return (
            <div className='qvisit-contactus-information-container qvisit-common-paragraph'>
                <span className='qvisit-contactus-information-label'>{label}</span>
                <span>{': '}</span>
                <span className='qvisit-contactus-information-value'>{value}</span>
            </div>
        );
    };

    informationSection = () => {
        return (
            <div className='qvisit-contactus-information-section-container'>
                <span className="qvisit-common-title">{'SundayQ - Ngày chủ nhật khoa học'.toUpperCase()}</span>
                {this.informationItem('Email', Constants.COMPANY_PROFILE.EMAIL)}
                {this.informationItem('Số điện thoại', Constants.COMPANY_PROFILE.HOTLINE_CS)}
                {this.informationItem('Địa chỉ', Constants.COMPANY_PROFILE.ADDRESS)}
            </div>
        );
    };

    feedbackSection = () => {
        return (
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span className=" qvisit-contactus-feedback-container qvisit-common-title ">GỬI Ý KIẾN PHẢN HỒI</span>
                <span className='qvisit-common-paragraph'>
                    {FEEDBACK_DESCRIPTION}
                </span>
                <br />
                <span className='qvisit-common-paragraph qvisit-contactus-feedback-description-bold'>
                    {FEEDBACK_DESCRIPTION_2}
                </span>
                <span className='qvisit-common-paragraph'>
                    {FEEDBACK_DESCRIPTION_3}
                </span>
                {this.mainForm()}
            </div>
        );
    };

    mainForm = () => {
        const { name, phone, email, message } = this.state;

        return (
            <div>
                <div className='qvisit-booking-ticket-form-container'>
                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Họ và tên'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                name: event.target.value,
                            });
                        }}
                        value={name}
                    />

                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Email'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                email: event.target.value,
                            });
                        }}
                        value={email}
                    />

                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Số điện thoaị'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                phone: event.target.value,
                            });
                        }}
                        value={phone}
                    />

                    <textarea
                        className="advise-registration-input advise-registration-note qvisit-ticket-single-form qvisit-ticket-textarea"
                        placeholder={'Ý kiến đóng góp'}
                        onChange={(event) => {
                            this.setState({
                                message: event.target.value,
                            });
                        }}
                        value={message}
                    />
                    {this.feedbackButton()}
                </div>
            </div>
        );
    };

    feedbackButton() {
        const { feedbackLoading } = this.state;

        return (
            <div
                className="advise-registration-submit-button-container qvisit-ticket-form-submit-button-container">
                <div
                    onClick={() => {
                        this.setState({
                            feedbackLoading: true,
                        }, () => {
                            this.submitFeedback();
                        });
                    }}
                    className={`qvisit-ticket-form-submit-button ${feedbackLoading 
                        ? "qvisit-ticket-form-submit-button-disable" : ""}`}
                >
                    <span
                        className="advise-registration-submit-button-text qvisit-ticket-form-submit-button-text">
                        {feedbackLoading ? <div className="loader" /> : 'Gửi'}
                    </span>
                </div>
            </div>
        );
    }


    requestBookingTicketSuccess() {
        this.setState({
            showAlert: true,
            successAlert: true,
            alertMessage: 'Phản hồi ý kiến thành công',
            phone: '',
            name: '',
            email: '',
            message: '',
            feedbackLoading: false,
        });
    };

    requestBookingTicketFailed(msg) {
        this.setState({
            showAlert: false,
            successAlert: false,
            alertMessage: msg,
            feedbackLoading: false,
        });
    };

    submitFeedback() {
        const { phone, name, email, message } = this.state;
        const data = {
            phone,
            name,
            email,
            message,
        };
        const verified = Controller.verifySendFeedbackForm(phone, name, email, message);
        if (verified) {
            this.setState({
                showAlert: true,
                successAlert: false,
                alertMessage: verified,
                feedbackLoading: false,
            });
        } else {
            Controller.requestFeedback(data, () => this.requestBookingTicketSuccess(),
                (message) => this.requestBookingTicketFailed(message));
        }

    }

    alertDialog = () => {
        const { showAlert, successAlert, alertMessage } = this.state;
        const title = successAlert ? 'Thành công' : 'Có lỗi xảy ra';

        return (
            showAlert && <SweetAlert
                success={successAlert}
                error={!successAlert}
                title={title}
                confirmBtnCssClass="qonline-confirm-alert-btn"
                onConfirm={() => this.setState({
                    showAlert: false,
                })}
            >
                {alertMessage}
            </SweetAlert>
        );
    };

    render() {
        return (
            <div className='qvisit-contactus-container'>
                {this.alertDialog()}
                {this.informationSection()}
                {this.feedbackSection()}
            </div>
        );
    }
}
