import { Constants, Utils } from '../../../utils';
import { ApiHelper } from '../../../services/apis/ApiHelper';

export function verifySendFeedbackForm(phone, name, email, feedback) {
    if (Utils.isNullOrUndefined(name)) {
        return 'Tên không được để trống';
    }

    if (Utils.isNullOrUndefined(email)) {
        return 'Email không được để trống';
    }

    if (Utils.isNullOrUndefined(phone)) {
        return 'Số điện thoại không được để trống';
    }

    const phoneNumberRegex = /\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/;
    if (!phoneNumberRegex.test(phone)) {
        return 'Số điện thoại không hợp lệ';
    }

    if (Utils.isNullOrUndefined(feedback)) {
        return 'Không được để trống ý kiến góp ý';
    }

    return null;
}


export function requestFeedback(data, successCallback, errorCallback) {
    console.log(successCallback, errorCallback);
    ApiHelper.post(Constants.POST_QVISIT_FEEDBACK, data).then(
        (response) => {
            console.log("response::", response);
            successCallback();
        }
    ).catch(
        (error) => {
            console.log("error::", error)
            errorCallback('Có lỗi xảy ra')
        }
    )
}
