import React from 'react';
import './qvisit-class-screen.css';

const DESCRIPTION_1 = 'Học viện SundayQ đưa ra những khóa học giúp các bạn học viên phát triển một cách đúng đắn, khơi dậy tài năng và niềm đam mê khám phá học hỏi, và mang đến cho các bạn học viên những cơ hội bứt phá vượt trội trong tương lai.';
const DESCRIPTION_2 = 'Tham khảo ngay tại đây để biết thêm chi tiết về các khóa học của Học viện SundayQ';

export default class QVisitClass extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="qvisit-class-container">
                <img
                    alt="q-visit-class-top-image"
                    src={require('../../../assets/icon/bg_club_2.jpg')}
                    className="q-visit-class-top-image"
                />
                <div className="qvisit-class-description">
                    <p>
                        {DESCRIPTION_1}
                    </p>
                    <p>
                        {"Tham khảo ngay "}
                        <a href="/q-academy">
                            {"tại đây"}
                        </a>
                        {" để biết thêm chi tiết về các khóa học của "}
                        <a href="/q-qacademy">
                            {"Học viện SundayQ."}
                        </a>
                    </p>
                </div>
            </div>
        );
    }
}
