import { Constants, Utils } from '../../../utils';
import { ApiHelper } from '../../../services/apis/ApiHelper';

export function verifyBookingTicketForm(phone, name, email, additionalInformation) {
    if (Utils.isNullOrUndefined(name)) {
        return 'Tên không được để trống';
    }

    if (Utils.isNullOrUndefined(email)) {
        return 'Email không được để trống';
    }

    if (Utils.isNullOrUndefined(phone)) {
        return 'Số điện thoại không được để trống';
    }

    const phoneNumberRegex = /\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/;
    if (!phoneNumberRegex.test(phone)) {
        return 'Số điện thoại không hợp lệ';
    }

    if (Utils.isNullOrUndefined(additionalInformation)) {
        return 'Không được để trống yêu cầu đặt mua';
    }

    return null;
}

export function requestBookingTicket(data, successCallback, errorCallback) {
    console.log(successCallback, errorCallback);
    ApiHelper.post(Constants.POST_BOOKING_TICKET, data).then(
        (response) => {
            successCallback();
        }
    ).catch(
        (error) => {
            errorCallback('Có lỗi xảy ra')
        }
    )
}
