import React from 'react';
import './qvisit-ticket-screen.css';
import SweetAlert from 'react-bootstrap-sweetalert';
import * as Controller from './QVisitTicketDataHandler';
import { Constants } from '../../../utils';

const BOOKING_TICKET_ONLINE_DESCRIPTION = 'Bạn có thể mua vé trực tuyến qua trang web của Trung tâm SundayQ. Vé sẽ được gửi ngay lập tức qua email cho bạn. Đăng ký bằng cách để lại email của bạn tại quầy lễ tân Trung tâm SundayQ. Hoặc Quý vị có thể đăng kí mua vé theo mẫu dưới đây';

export default class QVisitTicketScreen extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            phone: '',
            name: '',
            email: '',
            additionalInformation: '',
            // alert: null,
            showAlert: false,
            successAlert: false,
            alertMessage: '',
        };
    }

    priceTable = () => {
        return (
            <table className="qvisit-visit-home-table">
                <tr>
                    <td>Người lớn</td>
                    <td>80.000 VNĐ/buổi</td>
                </tr>
                <tr>
                    <td>Trẻ em</td>
                    <td>120.000 VNĐ/buổi</td>
                </tr>
                <tr>
                    <td>Gia đình (2 người lớn, 2 trẻ em)</td>
                    <td>200.000 VNĐ/buổi</td>
                </tr>
                <tr>
                    <td>Khóa học & Workshop</td>
                    <td>Tham khảo chi tiết tại từng khóa học</td>
                </tr>
                <tr>
                    <td>Thành viên</td>
                    <td>Giảm 20%</td>
                </tr>
            </table>
        );
    };

    requestBookingTicketSuccess() {
        this.setState({
            showAlert: true,
            successAlert: true,
            alertMessage: 'Đăng ký mua vé thành công',
            phone: '',
            name: '',
            email: '',
            additionalInformation: '',
        });
    };

    requestBookingTicketFailed(msg) {
        this.setState({
            showAlert: false,
            successAlert: false,
            alertMessage: msg,
        });
    };

    submitBookingTicket() {
        const { phone, name, email, additionalInformation } = this.state;
        const data = {
            phone,
            name,
            email,
        };

        if (additionalInformation) {
            data["message"] = additionalInformation;
        }

        const verifyResult = Controller.verifyBookingTicketForm(phone, name, email, additionalInformation);

        if (verifyResult) {
            this.setState({
                showAlert: true,
                successAlert: false,
                alertMessage: verifyResult,
            });
        } else {
            Controller.requestBookingTicket(data, () => this.requestBookingTicketSuccess(),
                (message) => this.requestBookingTicketFailed(message));
        }
    }

    bookingTicketOnline = () => {
        const { name, phone, email, additionalInformation } = this.state;

        return (
            <div className='qvisit-booking-ticket-online-container'>
                <span className="qvisit-common-title">{'Mua vé online'.toUpperCase()}</span>
                <span className={'qvisit-common-paragraph'}>
                    {BOOKING_TICKET_ONLINE_DESCRIPTION}
                </span>
                <div className='qvisit-booking-ticket-form-container'>
                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Họ và tên'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                name: event.target.value,
                            });
                        }}
                        value={name}
                    />

                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Email'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                email: event.target.value,
                            });
                        }}
                        value={email}
                    />

                    <input
                        className="advise-registration-input qvisit-ticket-single-form"
                        placeholder={'Số điện thoaị'}
                        type={'text'}
                        onChange={(event) => {
                            this.setState({
                                phone: event.target.value,
                            });
                        }}
                        value={phone}
                    />

                    <textarea
                        className="advise-registration-input advise-registration-note qvisit-ticket-single-form qvisit-ticket-textarea"
                        placeholder={'Yêu cầu đặt mua'}
                        onChange={(event) => {
                            this.setState({
                                additionalInformation: event.target.value,
                            });
                        }}
                        value={additionalInformation}
                    />

                    <div
                        className="advise-registration-submit-button-container qvisit-ticket-form-submit-button-container">
                        <div
                            onClick={() => this.submitBookingTicket()}
                            className={`qvisit-ticket-form-submit-button`}>
                            <span
                                className="advise-registration-submit-button-text qvisit-ticket-form-submit-button-text">
                                {'Gửi yêu cầu'}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    topImage = () => {
        return (
            <div className='qvisit-ticket-top-image-container'>
                <div className='qvisit-ticket-top-image' />
            </div>
        );
    };

    alertDialog = () => {
        const { showAlert, successAlert, alertMessage } = this.state;
        const title = successAlert ? 'Thành công' : 'Có lỗi xảy ra';

        return (
            showAlert && <SweetAlert
                success={successAlert}
                error={!successAlert}
                title={title}
                confirmBtnCssClass="qonline-confirm-alert-btn"
                onConfirm={() => this.setState({
                    showAlert: false,
                })}
            >
                {alertMessage}
            </SweetAlert>
        );
    };

    render() {
        return (
            <div className='qvisit-ticket-container'>
                {this.alertDialog()}
                {this.topImage()}
                <span className="qvisit-common-paragraph qvisit-ticket-title-line-break">
                    {'Bạn có thể mua vé vào SundayQ trực tiếp tại trung tâm hoặc mua online.\n'}{'Hãy nhanh tay mua vé để có những trải nghiệm hấp dẫn tại Trung tâm vui chơi trải nghiệm Khoa học Sáng tạo SundayQ - Ngày Chủ nhật Khoa học ngay nào!'}
                </span>
                <span className="qvisit-common-title qvisit-price-table-top-separator">{'Bảng giá'.toUpperCase()}</span>
                {this.priceTable()}
                {this.bookingTicketOnline()}
            </div>
        );
    }
}
