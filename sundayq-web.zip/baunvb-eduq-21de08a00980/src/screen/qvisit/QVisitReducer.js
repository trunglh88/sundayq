import { FETCH_POST_TITLE } from './QVisitAction';

export const initState = {
    title: ""
};

export const qVistiReducer = (state = initState, action) => {
    console.log("qVistiReducer", action.data);
    switch (action.type) {
        case FETCH_POST_TITLE.SUCCESS:
            return {
                ...state,
                title: action.data
            }
        default:
            return state;

    }

};
