import React from 'react';
import './qvisit-store-screen.css';
import { Constants } from '../../../utils';

export default class QVisitStoreScreen extends React.Component {

    render() {
        return (
            <div className="qvisit-store-screen-main">
                <img src={require('../../../assets/image/visit_visit_img_header.png')} />
                <div>
                    <img src={require('../../../assets/icon/bg_club_2.jpg')} />
                    <p>
                        Q-Shop sẽ cung cấp hàng loạt các mặt hàng với giá cả hợp lí bao gồm cả đồ chơi công nghệ, đồ
                        chơi thông minh, đồ dùng học tập, sách, quà tặng, quà lưu niệm, bộ kit để thực hành steam hoặc
                        sáng tạo thiết kế…Q-Shop được tạo ra nhằm mục đích cung cấp cho khách hàng những trải nghiệm
                        khoa học tương tác thông qua các sản phẩm sáng tạo được lựa chọn cẩn thận. Q-Shop đảm bảo cho dù
                        bạn muốn tìm kiếm một sản phẩm khoa học tuyệt vời khiến bạn say mê hay một món quà cho bất kì ai
                        hoặc món quà cho chính bạn, Q-Shop cũng đều có thể đáp ứng. <br /> <br />
                        Các sản phẩm được lấy cảm hứng từ các lĩnh vực khoa học, công nghệ và sáng tạo nghệ thuật có
                        trong các triển lãm tại trung tâm bao gồm: sinh học, hóa học, địa chất, vật lý, toán học, thiên
                        văn học và kỹ thuật, công nghệ, sáng tạo, nghệ thuật….. <br /> <br />
                        Q-Shop cũng sẽ cung cấp cho khách hàng những cuốn sách về khoa học và công nghệ phù hợp với mọi
                        lứa tuổi. <br /> <br />
                        Đội ngũ nhân viên thân thiện của chúng tôi luôn sẵn lòng cung cấp sản phẩm, hỗ trợ giải đáp mọi
                        thắc mắc của quý khách hàng. <br /> <br />
                        Q-Shop mở cửa từ 9 giờ sáng đến 6 giờ chiều hoặc Khách hàng cũng có thể mua sản phẩm thông qua
                        cửa hàng trực tuyến {<a href="/q-shop">Q-Shop</a>} của chúng tôi.<br /> <br />
                    </p>

                </div>
                <a href="/q-shop" className="qvisit-store-screen-direct-qshop">
                    GHÉ THĂM Q-SHOP
                </a>
                <div className="qvisit-store-screen-info">
                    <span>
                        <p>Website: </p>
                        <a href={Constants.COMPANY_PROFILE.WEB_SITE}>http://sundayq.com</a>
                    </span>
                    <span>
                        <p>Điện thoại: </p>
                        <a href={`tel: ${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a>
                    </span>
                    <span>
                        <p>Email: </p>
                        <a href={`mailto:${Constants.COMPANY_PROFILE.EMAIL}`}>{Constants.COMPANY_PROFILE.EMAIL}</a>
                    </span>
                </div>
            </div>
        );
    }
}
