import React from 'react'
import './qvisit-club-screen.css'
import { Constants } from "../../../utils"

export default class QVisitClubScreen extends React.Component {
    render() {
        return (
            <div>
                <span className="qvisit-common-paragraph">
                    Khoa học công nghệ là điều kiện tiên quyết để đất nước ta bắt nhịp,
                    hòa nhập với thời đại và dẫn đầu xu hướng toàn cầu hóa.
                    Chính vì thế, các thành viên khi tham gia SundayQ sẽ có cơ hội tiếp cận và trải nghiệm với khoa học công nghệ mới nhất,
                    được khơi dậy khả năng sáng tạo, sự tự tin và niềm đam mê với công nghệ. <br />
                    Hãy trở thành thành viên của SundayQ, bạn sẽ nhận được những lợi ích tuyệt vời!
                </span>
                <span className="qvisit-common-title">{'Những ưu đãi khi trở thành thành viên của SundayQ:'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    * Giảm giá 20% các vé vào tham quan Trung tâm SundayQ <br />
                    * Giảm giá khi mua sắm các mặt hàng của trung tâm <br />
                    * Được mời tham gia các sự kiện đặc biệt do trung tâm tổ chức <br />
                    * Giảm giá trong các khóa học tại trung tâm và các khóa học online
                </span>

                <span className="qvisit-common-title">{'Cách thức tham gia:'.toUpperCase()}</span>
                <span className="qvisit-common-paragraph">
                    * Trực tiếp: đăng kí trực tiếp với nhân viên chúng tôi tại trung tâm.
                    Bạn có thể ngay lập tức trở thành thành viên và nhận được những ưu đãi bất ngờ.<br />
                    * Qua email: gửi email cho chúng tôi qua địa chỉ: academy@sundayq.com. Chúng tôi sẽ tư vấn và gửi cho bạn mẫu đơn đăng kí. <br />
                    * Qua điện thoại: vui lòng liên hệ theo số hotline: 0917072756. Nhân viên của chúng tôi sẽ tư vấn và giải đáp toàn bộ thắc mắc của bạn. <br />
                    <a style={{color: "red", fontWeight: "bold"}}>* Lưu ý: (quyền riêng tư và bảo mật) </a><br />
                        - Bảng giá: tham gia SundayQ, các bạn có thể ghé thăm và tham quan các triển lãm của chúng tôi bất kì lúc nào trong thời gian mở cửa. Nếu trở thành khách hàng thân thiết của SundayQ, bạn hoàn toàn có thể nhận được những ưu đãi bất ngờ. Ngoài ra, chúng tôi còn có dịch vụ giảm giá dành cho những khách hàng có nhu cầu gia hạn thêm.
                </span>
                {/* table */}
                <table className="qvisit-club-table">
                    <tr>
                        <td>Người lớn</td>
                        <td>80.000 VNĐ/buổi</td>
                    </tr>
                    <tr>
                        <td>Trẻ em</td>
                        <td>120.000 VNĐ/buổi</td>
                    </tr>
                    <tr>
                        <td>Gia đình (2 người lớn, 2 trẻ em)</td>
                        <td>200.000 VNĐ/buổi</td>
                    </tr>
                    <tr>
                        <td>Khóa học & Workshop</td>
                        <td>Tham khảo chi tiết tại từng khóa học</td>
                    </tr>
                    <tr>
                        <td>Thành viên</td>
                        <td>Giảm 20%</td>
                    </tr>
                </table>
                <span style={{ display: 'block', marginBottom: '41px' }} className="qvisit-common-paragraph">
                    Trải nghiệm thử SundayQ: bạn có thể mua vé đến trải nghiệm tại trung tâm theo ngày hoặc theo từng đợt, từng khóa.
                    Nếu bạn cảm thấy hài lòng với dịch vụ tại trung tâm,
                    bạn có thể đến quầy lễ tân để đăng kí trở thành thành viên chính thức ngay khi kết thúc chuyến thăm. <br />
                    Thành viên quà tặng: nếu bạn muốn tặng quà cho thành viên khác, vui lòng mua thẻ quà tặng trên Q-Shop.
                    Cửa hàng có thể gửi thẻ đến địa chỉ mà bạn đã yêu cầu. Thẻ quà tặng có thể trao đổi giữa các thành viên của SundayQ. <br />
                    Tư cách thành viên sẽ không có hiệu lực cho đến khi thẻ quà tặng được trao đổi.  <br /><br />
                    • Điện thoại: <a style={{color: "#000"}} href={`tel:${Constants.COMPANY_PROFILE.HOTLINE_CS}`}>{Constants.COMPANY_PROFILE.HOTLINE_CS}</a> <br />
                    • Email: <a style={{color: "#000"}} href={`mailto:${Constants.COMPANY_PROFILE.EMAIL}`}>{Constants.COMPANY_PROFILE.EMAIL}</a><br />
                </span>
            </div>
        )
    }
}
