import React from 'react';
import './qvisit-tour-screen.css'
import ItemTour from "./ItemTour";
import Pagination from '@material-ui/lab/Pagination';
import { ApiHelper } from '../../../services/apis/ApiHelper';
import { Constants } from '../../../utils';
const PAGE_COUNT = 6;

// const tour = {
//   "createAt": "2020-08-26T07:49:43.784Z",
//   "updateAt": "2020-08-26T13:56:02.015Z",
//   "id": "053e5a92bb54afebdde40a424d5e0ddf1598428183784",
//   "viewIndex": 999999999,
//   "minTargetAge": 2,
//   "maxTargetAge": 5,
//   "title": "T7",
//   "shortDescription": "Qưert",
//   "descriptionImgUrl": "resource/image/4b0cda186918fddda77f2bd2bafb3d3a-1598449689393.jpg"
// };

// let ListTour = [];
// let i = 0;
// while(i < 20) {
//   ListTour.push({...tour, title: `Su kien va trien lam ${i}`})
//   i++;
// }


export default class QVisitTourScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pageIndex: 1,
      listExhibition: []
    }
  }

  onPageChange = (pageIndex) => {
    this.setState({ pageIndex: pageIndex });
  }

  componentDidMount() {
    ApiHelper.get(Constants.GET_EXHIBITION_LIST())
      .then(({ data }) => {
        console.log('GET_EXHIBITION_LIST::', data);
        this.setState({
          listExhibition: data,
        });
      })
      .catch((error) => {
        console.log('error::', error);
      });
  }

  render() {
    const { listExhibition, pageIndex } = this.state;
    let listExhibitionShowed = listExhibition.slice((pageIndex - 1) * PAGE_COUNT, pageIndex * PAGE_COUNT);
    return (
      <div className="qvisit-tour-screen-main">
        <span className="qvisit-tour-screen-des">
          Bạn đang ở bất kì lứa tuổi nào cũng có thể đến tham quan trải nghiệm trực tiếp trong một ngày hoặc tham gia vào các khóa học được tổ chức tại Trung tâm SundayQ.<br />
        Khách tham quan và học viên sẽ bắt gặp những điều thú vị và ngạc nhiên trong các triển lãm trưng bày các sản phẩm thực hành trong các phòng trưng bày, phòng trải nghiệm thực hành, cũng như Phòng thí nghiệm.
        </span>
        <div className="qvisit-tour-screen-list">
          {
            listExhibitionShowed.map((item, index) => {
              return (
                <div className="qvisit-tour-screen-item" key={index}>
                  <ItemTour data={item} />
                </div>
              )
            })
          }


        </div>
        <div className="qvisit-tour-page-navigation">
          <Pagination
            classes={{ ul: "lecturer-list-wrap-page-index" }}
            onChange={(event, page) => this.onPageChange(page)}
            count={Math.ceil(listExhibition.length / PAGE_COUNT)}
            variant="outlined"
            shape="rounded"
          />
        </div>
      </div>
    )
  }
}