import React from 'react';
import './item-tour.css';
import { Utils } from '../../../utils';

export default class ItemTour extends React.Component {
  render() {
    const { data } = this.props;
    let image = Utils.imageUrl(data.descriptionImgUrl);

    return (
      <a href={`/q-visit/post?type=tour&id=${data.id}`} className="item-tour-main box-hover">
        <div className="item-tour-main-content">
          <span className="item-tour-title">{data.title}</span>
          <img className="item-tour-img" src={image} />
          <span className="item-tour-excerpt">
            {data.shortDescription}
          </span>
        </div>

        <div className="item-tour-footer">
          <div className="item-tour-footer-left">
            <img className="item-tour-footer-icon" src={require("../../../assets/icon/ic_footer_tour_item.svg")} />
            <span className="item-tour-footer-age">{data.minTargetAge} - {data.maxTargetAge} tuổi</span>
          </div>
          <div className="item-tour-footer-right">
            <img src={require("../../../assets/icon/ic_navigate_item.svg")} />
          </div>
        </div>
      </a>
    )
  }
}