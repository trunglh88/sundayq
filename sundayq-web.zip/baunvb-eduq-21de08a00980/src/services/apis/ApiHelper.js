import axios from 'axios';
import { Constants, Storage, Utils } from '../../utils';
import ReactDOM from 'react-dom';
import React from 'react';
import SweetAlert from 'react-bootstrap-sweetalert';

function showErrAlert(message) {
    console.log("showErrAlert")
    document.getElementById("commonAlert").style.display = "block"

    var alert = (
        <SweetAlert
            warning
            title="Lưu ý"
            confirmBtnText="OK"
            confirmBtnCssClass="qonline-confirm-alert-btn"
            onConfirm={() => document.getElementById("commonAlert").remove()}
        >
            {message}
        </SweetAlert>
    )
    ReactDOM.render(
        alert,
        document.getElementById("commonAlert")
    );
}

function show401Alert() {
    console.log("show401Alert")
    document.getElementById("commonAlert").style.display = "block"

    var alert = (
        <SweetAlert
            warning
            title="Lưu ý"
            confirmBtnText="Đăng nhập"
            confirmBtnCssClass="qonline-confirm-alert-btn"
            onConfirm={() => window.location.href = "/q-online/login"}
        >
            Vui lòng đăng nhập để sử dụng dịch vụ!
        </SweetAlert>
    )
    ReactDOM.render(
        alert,
        document.getElementById("commonAlert")
    );
}

function show403Alert() {
    console.log("show403Alert")
    document.getElementById("commonAlert").style.display = "block"

    var alert = (
        <SweetAlert
            warning
            title="Lưu ý"
            confirmBtnText="Đăng ký dịch vụ"
            confirmBtnCssClass="qonline-confirm-alert-btn"
            onConfirm={() => window.location.href = "/"}
        >
           Vui lòng đăng ký để sử dụng dịch vụ!
        </SweetAlert>
    )
    ReactDOM.render(
        alert,
        document.getElementById("commonAlert")
    );
}

/**
 * parse response
 */
function parseBody(response) {
    //test show common alert
    // var element = <h1>Test</h1>
    // Utils.showCommonAlert(element, "commonAlert")
    console.log('CheckResponse: ', response);
    if (response.status === 200 || response.status === 201) {
        if (response.data) {
            return response.data;
        }
        return Promise.reject({ message: response });
    } else {
        return Promise.reject({ message: 'Vui lòng kiểm tra kết nối mạng' });
    }
}

const EXCEPTION_UNAUTHORIZED_API = [
    "login",
];

async function handleError(error) {
    console.log('Error', error.response);
    if (error.response && error.response.status === Constants.HTTPStatus.UNAUTHORIZED) {
        let exception = false;
        for (let exp of EXCEPTION_UNAUTHORIZED_API) {
            if (error.response.config.url.includes(exp)) {
                exception = true;
            }
        }
        if (!exception) {
            // setTimeout(() => {
            //     window.location.href = "/q-online/login"
            // }, 2000)
            show401Alert();
            await Utils.logout();
            return Promise.reject({ message: 'Phiên đăng nhập hết hạn' });
        }
    }
    if (error.response.status === 403) {
        show403Alert();
    }
    if (error.response) {
        if(error.response.data.message) {
            showErrAlert(error.response.data.message)
        } else if(error.response.data.error.message) {
            showErrAlert(error.response.data.error.message)

        } else {
            showErrAlert("Xảy ra lỗi, vui lòng thử lại")
        }
        return Promise.reject({ message: error.response.data.message });
    } else {
        return Promise.reject({message: "Vui lòng kiểm tra kết nối mạng"});
    }
}


/**
 * axios instance
 */
let instance = axios.create({
    baseURL: Constants.BASE_URL,
    timeout: 30000,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});

let externalApiHelperInstance = axios.create({
    baseURL: Constants.BASE_URL,
    timeout: 30000,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});


// request header
instance.interceptors.request.use((config) => {
    // Do something before request is sent
    let accessToken = Storage.getData(Storage.KEY.TOKEN);
    if (accessToken) {
        config.headers = {
            ...config.headers,
            'authorization': `Bearer ${accessToken}`,
        };
    }

    console.log('Starting Request', config);
    return config;
}, error => {
    return Promise.reject(error);
});

// response parse
instance.interceptors.response.use((response) => {
    return parseBody(response);
}, error => {
    console.warn('Error status', error.response);
    // return Promise.reject(error)
    return handleError(error);
});


// request header no auth
externalApiHelperInstance.interceptors.request.use(async (config) => {
    console.log('Starting Request', config);
    return config;
}, error => {
    return Promise.reject(error);
});

externalApiHelperInstance.interceptors.response.use((response) => {
    console.log('CheckResponse: ', response);
    return response;
}, error => {
    console.warn('Error status', error.response);
    // return Promise.reject(error)
    return handleError(error);
});

export const ApiHelper = instance;

export const ExternalApiHelper = externalApiHelperInstance;
