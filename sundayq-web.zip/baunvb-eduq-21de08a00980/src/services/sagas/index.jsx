import { all } from 'redux-saga/effects';
import watchHomeData from '../../screen/qacademy/QAcademySaga';

export default function* rootSaga() {
    yield all(
        [watchHomeData()],
    );
}
