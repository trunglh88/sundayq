import {combineReducers} from "redux";
import {homeReducer} from '../../screen/qacademy/QAcademyReducer';
import {qVistiReducer} from '../../screen/qvisit/QVisitReducer';

export const reducers = combineReducers({
    homeReducer,
    qVistiReducer
});

