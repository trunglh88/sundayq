import createSagaMiddleware from 'redux-saga';
import logger from 'redux-logger';
import { compose, createStore, applyMiddleware } from 'redux';
import { reducers } from '../services/reducers';
import rootSaga from '../services/sagas';
import { composeWithDevTools } from 'redux-devtools-extension';

export default function configurationStore(onCompletion) {
    const saga = createSagaMiddleware();
    const enhancer = composeWithDevTools(applyMiddleware(logger, saga));

    const store = createStore(reducers, enhancer);
    saga.run(rootSaga);
    return store;
}
