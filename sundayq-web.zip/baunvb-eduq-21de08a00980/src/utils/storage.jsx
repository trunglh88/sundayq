import {Utils} from "./index";
const { localStorage } = window;

export async function setData(key, value) {
    try {
        await localStorage.setItem(key, value);
    } catch (error) {
        console.log(error);
    }
}

export const getData =  key => {
    let value = "";

    try {
        value =  localStorage.getItem(key);
    } catch (error) {
        console.log(error);
    }

    return value;
};

export const setDataJson = async (key, value) => {
    try {
        if (!Utils.isNullOrUndefined(value)) {
            await localStorage.setItem(key, JSON.stringify(value));
        } else {
            await localStorage.setItem(key, '');
        }
    } catch (error) {
        console.log(error);
    }
};

export const getDataJson = async key => {
    try {
        const value = await localStorage.getItem(key);
        if (!Utils.isNullOrUndefined(value)) {
            return JSON.parse(value);
        }
    } catch (error) {
        console.log(error);
    }

    return null;
};

export const removeData = async key => {
    try {
        await localStorage.removeItem(key);
    } catch (error) {
        console.log(error);
    }
};

export const KEY = {
    TOKEN: "TOKEN",
    EMAIL: "EMAIL",
    USERNAME: "USERNAME",
    AVATAR: "AVATAR",
    PHONE: "PHONE",
    USER_ID: "UID"
}