export const BASE_URL = "http://103.153.68.12:3000/";
// export const BASE_URL = "http://localhost:3000/";

export const GET_TOP_COURSE = "course/top";
export const GET_COURSE_INFORMATION = (courseId) => `course/info/${courseId}`;
export const GET_TEACHER_INFORMATION = (teacherId) => `teacher/info/${teacherId}`;
export const GET_SUGGESTION_COURSE = (courseId) => `course/suggestion/${courseId}`;
export const REGISTER_ADVICE = (courseId) => `account/advice/register/${courseId}`;
export const POST_BOOKING_TICKET = 'ticket/q-visit';
export const POST_QVISIT_FEEDBACK = '/system/feedback/q-visit';
export const GET_LIST_EVENT = (start, end, title) => `/events?startAt=${start}&finishAt=${end}&service=q-visit&title=${title}`;


export const GET_TEACHER_LIST = () => `/teacher/infos`;

export const GET_EXHIBITION_LIST = () => '/exhibitions';
export const GET_EXHIBITION_INFORMATION = (id) => `/exhibition/${id}`;

export const GET_EVENT_INFORMATION = (id) => `/event/${id}`;

//qonline
export const GET_FREE_LESSON = (type, month) => `lesson/sample/age/${type}/${month}`
export const GET_FREE_PLAN = (type) => `age-plan/${type}`
export const REQUES_BUY_KIT = (kitId) => `order/${kitId}`

export const REGISTER_QONLINE = 'account/member/register'
export const LOGIN_QONLINE = 'account/member/login'
export const VERIFY_ACCOUNT = 'account/member/verify'
export const RESET_PASSWORD = "account/password/reset"
export const GET_SERVICES_QONLINE = "services"
export const REQUEST_SERVICES_TRANS = "service-member/requestService";
export const REQUEST_PAY_ONLINE = (type) => `transaction/create_payment_url/${type}`
export const REQUEST_PAY_OFFLINE = (type) => `transaction/transferMoney/${type}`
export const REQUEST_UPLOAD_IMG = "resource/image"
export const GET_SERVICE_INFO = (id) => `service/${id}`


export const HTTPStatus = {
    UNAUTHORIZED: 401,
};

export const KEY_ACCESS_TOKEN = "";

export const COMPANY_PROFILE = {
    ADDRESS: "Tầng 3, tòa R1, Chung cư Sunshine Riverside, Đường Võ Chí Công, Phường Phú Thượng, Quận Tây Hồ, Hà Nội.",
    EMAIL: "academy@sundayq.com",
    HOTLINE_CS: "0917 072 756",
    HOTLINE_BIZ: "0936 046 810",
    FB: "https://www.facebook.com/sunday.questacon",
    WEB_SITE: "http://sundayq.com"
}

export const VNPAY_RESULT_CODE = {
    "00": "Giao dịch thành công",
    "01": "Giao dịch đã tồn tại",
    "02": "Merchant không hợp lệ (kiểm tra lại vnp_TmnCode)",
    "03": "Dữ liệu gửi sang không đúng định dạng",
    "04": "Khởi tạo GD không thành công do Website đang bị tạm khóa",
    "05": "Giao dịch không thành công do: Quý khách nhập sai mật khẩu quá số lần quy định. Xin quý khách vui lòng thực hiện lại giao dịch",
    "13": "Giao dịch không thành công do Quý khách nhập sai mật khẩu xác thực giao dịch (OTP). Xin quý khách vui lòng thực hiện lại giao dịch",
    "07": "Giao dịch bị nghi ngờ là giao dịch gian lận",
    "09": "Giao dịch không thành công do: Thẻ/Tài khoản của khách hàng chưa đăng ký dịch vụ InternetBanking tại ngân hàng",
    "10": "Giao dịch không thành công do: Khách hàng xác thực thông tin thẻ/tài khoản không đúng quá 3 lần",
    "11": "Giao dịch không thành công do: Đã hết hạn chờ thanh toán. Xin quý khách vui lòng thực hiện lại giao dịch",
    "12": "Giao dịch không thành công do: Thẻ/Tài khoản của khách hàng bị khóa",
    "51": "Giao dịch không thành công do: Tài khoản của quý khách không đủ số dư để thực hiện giao dịch",
    "65": "Giao dịch không thành công do: Tài khoản của Quý khách đã vượt quá hạn mức giao dịch trong ngày",
    "08": "Giao dịch không thành công do: Hệ thống Ngân hàng đang bảo trì. Xin quý khách tạm thời không thực hiện giao dịch bằng thẻ/tài khoản của Ngân hàng này",
    "99": "Giao dịch thất bại"
}

export const chatKey = {
    admin: "Chuyên gia tư vấn",
    adminOnline: "Chuyên gia đang online",
    adminOffline: "Chuyên gia đang offline",
    chatPlaceholder: "Nhập câu hỏi",
    textSubmit: "Gửi",
    Seen:"Đã xem",
    errorPleaseTryAgain:"Có lỗi, vui lòng thử lại",
    thereIsANewMEssage:"Có tin nhắn mới",
}

export const firebaseConfig = {
    apiKey: "AIzaSyBa6uKjy-usshEanycZZBOBil4mOs_rEss",
    authDomain: "samplechat-a28cf.firebaseapp.com",
    databaseURL: "https://samplechat-a28cf.firebaseio.com",
    projectId: "samplechat-a28cf",
    storageBucket: "samplechat-a28cf.appspot.com",
    messagingSenderId: "265596094510",
    appId: "1:265596094510:web:72b5c60ddd13ef4ecc77bf"
}

export const FIREBASE_ADMIN = "adminchat";