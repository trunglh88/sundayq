import { Constants, Storage } from './index';
import moment from 'moment';
import ReactDOM from 'react-dom';

export function showCommonAlert(element, id) {
    document.getElementById(id).style.display = "block"
    ReactDOM.render(
        element,
      document.getElementById(id)
    );
}

export function isNullOrUndefined(param) {
    return param === null ||
        param === undefined ||
        param === '' ||
        param.length <= 0;
}

export const imageUrl = (path) => {
    return (path) ? `${Constants.BASE_URL}${path}` : 'https://thumbs.dreamstime.com/b/default-placeholder-businessman-half-length-portr-portrait-photo-avatar-man-gray-color-114321422.jpg';
}

export const formatVnd = (number) => {
    return Boolean(number) ? number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : 0;
}

export const videoUrl = (fileUrl, resolution) => {
    if(!Boolean(fileUrl)) return ""
    var path = `${fileUrl.match(/(.*)\./)[1]}_${resolution}.m3u8`;
    return `${Constants.BASE_URL}${path}`
}

export function renderIf(condition, content) {
    if (condition) {
        return content;
    }
    return null;
}

export const calcYearDistance = (practiceAt) => {
    practiceAt = moment(practiceAt);
    let current = moment();
    return (current.diff(practiceAt, 'year') + 1) || 0;
}

export const search = (input, ...data) => {
    let dataAsStr = "";
    dataAsStr = data.join("").toLowerCase();
    return dataAsStr.includes(input.toLowerCase());
}

export const validateEmail = (email) => {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

export const logout = async() => {
    await Storage.removeData(Storage.KEY.TOKEN);
    await Storage.removeData(Storage.KEY.USERNAME);
    await Storage.removeData(Storage.KEY.EMAIL);
    await Storage.removeData(Storage.KEY.PHONE);
    await Storage.removeData(Storage.KEY.AVATAR);

}

export const isLogin = () => {
    return Boolean(Storage.getData(Storage.KEY.TOKEN))
}