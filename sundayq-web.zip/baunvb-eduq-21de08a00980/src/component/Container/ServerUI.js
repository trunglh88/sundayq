import React from 'react';
import './server-ui.css';

class ServerUI extends React.Component {
    render() {
        const { extraClassName, content } = this.props;
        let className = 'content_from_server';
        extraClassName && extraClassName.forEach((item) => {
            className = className.concat(` ${item}`);
        });
        return (
            <div className={className} dangerouslySetInnerHTML={{__html: content}}>
            </div>
        );
    }
}

export default ServerUI;
