import React from 'react';
import './section-inner.css';

class SectionInner extends React.Component {
    render() {
        const { children, extraClassName } = this.props;
        let className = 'section-inner-wrap';
        extraClassName && extraClassName.forEach((item) => {
            className = className.concat(` ${item}`);
        });
        return (
            <div className={className}>
                {children}
            </div>
        );
    }
}

export default SectionInner;
