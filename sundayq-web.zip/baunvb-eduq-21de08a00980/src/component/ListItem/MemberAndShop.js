import React from 'react'
import './member-and-shop.css';
export default class MemberAndShop extends React.Component {
  render() {
    return (
      <div>
        <div className="member-and-shop-flex">
          <a href="/q-visit/member" className="member-and-shop-item">
            <div className="member-and-shop-item-img">
              <img src={require("../../assets/image/home-src-list2-item1.svg")} />
            </div>
            <div className="member-and-shop-item-right">
              <span className="member-and-shop-title">Trở thành thành viên</span>
              <span style={{ color: "#000" }} className="home-screen-list-first-des">Trở thành thành viên SundayQ ngay hôm nay để nhận được những lợi ích và ưu đãi không giới hạn.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </div>
          </a>

          <a href="/q-visit/store" className="member-and-shop-item">
            <div className="member-and-shop-item-img">
              <img src={require("../../assets/image/home-src-list2-item2.svg")} />
            </div>
            <div className="member-and-shop-item-right">
              <span className="member-and-shop-title">Q-Shop</span>
              <span style={{ color: "#000" }} className="home-screen-list-first-des">Tìm hiểu và đặt mua ngay những bộ dụng cụ khoa học, những sản phẩm bán chạy nhất tại Q-Shop.</span>
              <div className="home-screen-item-btn-navigate">
                <img src={require("../../assets/icon/ic_navigate_item.svg")} />
              </div>
            </div>
          </a>
        </div>
      </div>
    )
  }
}