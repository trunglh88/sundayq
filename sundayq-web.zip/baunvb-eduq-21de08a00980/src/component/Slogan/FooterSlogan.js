import React from 'react'
import './footer-slogan.css';
import SectionInner from "../Container/SectionInner"
export default class FooterSlogan extends React.Component {
  render() {
    return (
      <div className="footer-slogan-main">
        <SectionInner>
          <span className="footer-slogan-title">Đi Tìm Chân Lý</span>
          <span className="footer-slogan-des">“Điều quan trọng là người ta không ngừng học hỏi” <br /> <br /> 
            <span style={{fontSize: "16px"}}> Câu nói này của Albert Einstein được viết trên tấm thảm đỏ lớn tại cửa đi vào phòng hội thảo tại Viện bảo tàng Lịch sử Đức ở Berlin trong năm 2005 - năm được chọn làm “Năm Einstein” và “Năm vật lý” của thế giới. Nó thể hiện triết lý của Einstein đi tìm chân lý không mệt mỏi và cũng là kim chỉ nam suốt cuộc đời Ông.
</span>
          </span>
        </SectionInner>
      </div>
    )
  }
}