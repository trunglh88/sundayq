import React from 'react'
import './list-social.css'
import {Constants} from "../../utils"
export default class ListSocial extends React.Component {

  render() {
    return (
      <div>
        <a href="#"><img className="list-social-social-icon" src={require("../../assets/icon/instagram.svg")} /></a>
        <a href={Constants.COMPANY_PROFILE.FB}><img className="list-social-social-icon" src={require("../../assets/icon/facebook.svg")} /></a>
        <a href="#"><img className="list-social-social-icon" src={require("../../assets/icon/twitter.svg")} /></a>
        <a href="#"><img className="list-social-social-icon" src={require("../../assets/icon/youtube.svg")} /></a>
        <a href="#"><img className="list-social-social-icon" src={require("../../assets/icon/linkedin.svg")} /></a>
      </div>
    )
  }
}