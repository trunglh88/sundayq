import React, { useEffect, useState } from 'react'
import { Utils } from '../../utils';
import "./input.css"
export default function Input(props) {
  const [isShowPass, showPass] = useState(false);
  const [isFocus, setFocus] = useState(false);
  const [message, setMessage] = useState("");
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    check();
  }, [isFocus])

  const onBlur = () => {
    setFocus(false)
    //check input
  }

  const check = () => {
    console.log("check", props.value, props.type, isFocus)
    if (!isFocus && Boolean(props.value)) {
      switch (props.type) {
        case "email":
          if (Utils.validateEmail(props.value)) {
            setIsValid(true)
            setMessage("")
          } else {
            setIsValid(false)
            setMessage("Email không hợp lệ")
          }
          break

        case "password":
          if (Boolean(props.value) && props.value.length >= 6) {
            setIsValid(true)
            setMessage("")
          } else {
            setIsValid(false)
            setMessage("Mật khẩu không hợp lệ")
          }
          break

        case "text":
          if (Boolean(props.value)) {
            setIsValid(true)
            setMessage("")
          } else {
            setIsValid(false)
            setMessage("Thông tin không hợp lệ")
          }
          break

        default:
          break
      }
    }
  }

  var { placeholder, required, type } = props;

  if (required) placeholder += " *"

  if (isShowPass && type == "password") type = "text"

  return (
    <div className="input-main">
      <div className="input-wrap-input">
        <input
          value={props.value}
          required={props.required}
          type={type}
          className="input-input"
          placeholder={placeholder}
          name={props.name}
          onFocus={() => setFocus(true)}
          onBlur={() => onBlur()}
          onChange={e => props.onChange(e)}
        />

        {
          isValid ? <img
            className="input-icon"
            src={require("../../assets/icon/ic_input_valid.svg")}
          /> : Boolean(message) ? <img
            className="input-icon"
            src={require("../../assets/icon/ic_input_invalid.svg")}
          /> : null
        }
        {
          props.type == "password" ?
            <img
              className="input-icon-show-pass"
              onClick={(e) => showPass(prevState => !prevState)}
              src={isShowPass ? require("../../assets/icon/ic_hide_pass.svg") : require("../../assets/icon/ic_show_pass.svg")}
            /> : null
        }
      </div>
      {
        Boolean(message) && <span className="input-warning">
          {message}
        </span>
      }
    </div>

  )
}