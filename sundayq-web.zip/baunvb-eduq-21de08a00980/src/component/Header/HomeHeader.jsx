import React from 'react';
import './home-header.css';
import { NavLink } from 'react-router-dom';
import SectionInner from '../Container/SectionInner';

const screenWidth = window.innerWidth;

class HomeHeader extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    activePath = (path) => {
        const pathName = this.props.location.pathname;
        // return pathName.includes(path);
        console.log("path::", pathName, path, pathName.includes(path));
        // return pathName.includes(path) || path.includes(pathName);
        if (pathName === '/') {
            return false;
        } else {
            if (path === '/') return false;
            return this.props.location.pathname.indexOf(path) > -1 ? true : false;
        }
    };

    componentDidMount() {
    }


    render() {
        const { router, isOpen } = this.props;
        const { extraClassName } = this.props;
        let className = 'home-header-main';
        extraClassName && extraClassName.forEach((item) => {
            className = className.concat(` ${item}`);
        });
        // let routeList = router.filter((route, index) => (index !== router.length - 1));
        return (
            <div className={className}>
                <SectionInner
                    extraClassName={screenWidth <= 768 ? ['home-header-mobile-container'] : []}
                >
                    {screenWidth <= 768 && !isOpen ? null :
                        <div className="home-header-container">
                            {
                                router.map((item, index) => {
                                    var classItem = `home-header-nav-link ${item.isHideBorder ? "" : "home-header-nav-link-border-right"} ${(item.disable ? "home-header-nav-link-disable" : "")}`;
                                    if (this.activePath(item.path)) classItem += ' home-header-path-active ';
                                    return (!item.invisibleInTabBar) ?
                                        (
                                            <a
                                                onClick={e => {
                                                    if (item.disable)
                                                        e.preventDefault();
                                                }}
                                                className={classItem}
                                                href={item.path}
                                            >
                                                <div className="home-header-menu-item">
                                                    <span className="home-header-nav-link-main-text">{item.name}</span>
                                                    {
                                                       item.subTitle && <span className="home-header-nav-link-sub-text">{item.subTitle}</span>
                                                    }
                                                </div>
                                            </a>
                                        ) : <div />;
                                })
                            }
                        </div>
                    }
                </SectionInner>
            </div>


        );
    }

}

export default HomeHeader;
