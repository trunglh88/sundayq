import "./qonline-freeq-header.css"
import React from 'react';

const screenWidth = window.innerWidth;

function SubMenu(props) {
    const { open, menu } = props;
    if (!open) {
        return null
    } else {
        return (
            <div className="qonline-header-submenu-wrap">
                {
                    menu.map((item, key) => {
                        return (
                            <a href={item.path} key={key}>{item.name}</a>
                        )
                    })
                }
            </div>
        )
    }

}

class QOnlineFreeqHeader extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            openSubMenuIndex: -1
        };
    }

    activePath = (path) => {
        const pathName = this.props.location.pathname;
        console.log("path::", pathName, path, pathName.includes(path));
        if (pathName === '/') {
            return false;
        } else {
            if (path === '/') return false;
            return this.props.location.pathname.indexOf(path) > -1 ? true : false;
        }
    };

    componentDidMount() {
    }


    render() {
        const { router, isOpen } = this.props;
        const { openSubMenuIndex } = this.state;
        return (
            <div className='qonline-header-main'>
                {screenWidth <= 768 && !isOpen ? null :
                    <div className="qonline-header-container">
                        {
                            router.map((item, index) => {
                                var open = false;
                                if (item.name)
                                   return (
                                        <div
                                            className="qonline-header-link"
                                            key={index}
                                            onMouseOver={() => { this.setState({ openSubMenuIndex: index }) }}
                                            onMouseLeave={() => { this.setState({ openSubMenuIndex: -1 }) }}

                                        >
                                            <div className="qonline-header-menu-item">
                                                <a className="qonline-header-title"
                                                    href={item.path}
                                                    onClick={(e) => {
                                                        if (item.subMenu) {
                                                            e.preventDefault()
                                                        }
                                                    }}>{item.name}
                                                </a>
                                                {
                                                    item.subMenu ?
                                                        <img className="qonline-header-dropdown-icon" src={require("../../../assets/image/qonline/menu_dropdown_ic.svg")} /> : null
                                                }
                                                {
                                                    item.subMenu ?
                                                        <SubMenu open={openSubMenuIndex == index} menu={item.subMenu} /> : null
                                                }

                                            </div>
                                        </div>
                                    );
                            })
                        }
                    </div>
                }
            </div>
        );
    }
}

export default QOnlineFreeqHeader;
