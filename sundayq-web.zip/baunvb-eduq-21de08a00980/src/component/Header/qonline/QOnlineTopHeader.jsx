import React, { useEffect, useRef, useState } from 'react';
import './qonline-top-header.css';
import { NavLink } from 'react-router-dom';
import SectionInner from '../../Container/SectionInner';
import { Storage, Utils } from "../../../utils"
const QONLINE_HOME = "/";

const COMMON_EDUQ_ROUTER = ["/", "/q-online/buy-success", "/q-online/payment/callback", "/q-online/login", "/q-online/register"]
const EDUQ_AUTH = ["/q-online/login", "/q-online/register"]
const iconMenu = {
    close: require('../../../assets/icon/icon_mobile_menu_close.svg'),
    open: require('../../../assets/icon/icon_mobile_menu_open.svg'),
};

function HeaderRightEduQ(props) {
    const isLogin = Utils.isLogin()
    console.log("isLogin", isLogin)
    if(!isLogin) {
        return (
            <>
                <a href="/q-online/register" className="qonline-top-header-link">
                    <img src={require("../../../assets/icon/ic_contact.svg")} />
                    <span>Trở thành thành viên</span>
                </a>
                <a href="/q-online/login" className="qonline-top-header-btn-login">
                    Đăng nhập
                </a>
            </>
        )
    }
    return <HeaderRightFreeQ />
    
}

function HeaderRightFreeQ(props) {
    const [isShowMenu, showMenu] = useState(false);
    const ref = useRef(null);

    const handleClickOutside = (event) => {
        if (ref.current && !ref.current.contains(event.target)) {
            showMenu(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    });

    const logout = async () => {
        await Utils.logout();
        window.location.href = "/q-online/login";
    }

    return (
        <>
            <div className="qonline-top-header-profile">
                <div>
                    <span className="qonline-top-header-username">{Storage.getData(Storage.KEY.USERNAME)}</span>
                    <span className="qonline-top-header-email">{Storage.getData(Storage.KEY.EMAIL)}</span>
                </div>
                {
                    Storage.getData(Storage.KEY.AVATAR) == "undefined" ?
                        <img src={require("../../../assets/image/qonline/qonline_free_bg_3.png")} /> :
                        <img src={Utils.imageUrl(Storage.getData(Storage.KEY.AVATAR))} />

                }
                <div className="qonline-top-header-profile-menu"
                    ref={ref}
                >
                    <div className="qonline-top-header-profile-dropdown"
                        onClick={() => showMenu(prev => !prev)}
                    >
                        <img src={require("../../../assets/image/qonline/ic_dropdown_header_user.svg")} />
                    </div>
                    {
                        isShowMenu ?
                            <div className="qonline-top-header-dropdown-view">
                                <a href="#">
                                    <img src={require("../../../assets/image/qonline/ic_user_header.svg")} />
                                    <span>Quản lý tài khoản</span>
                                </a>
                                <div></div>
                                <a
                                    onClick={() => logout()}
                                >
                                    <img src={require("../../../assets/image/qonline/ic_logout_header.svg")} />
                                    <span className="orange">Đăng xuất</span>
                                </a>
                            </div> :
                            null
                    }
                </div>

            </div>
        </>
    )
}

class QOnlineTopHeader extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            open: false,
        };
        this.onOpenMenu = this.onOpenMenu.bind(this);
    }


    onOpenMenu() {
        this.setState((prevState) => ({
            open: !prevState.open
        }), () => this.props.onIconMenuClick(this.state.open));
    }

    setLogo = (pathName) => {
        //home
        if(COMMON_EDUQ_ROUTER.includes(pathName)) {
            return require('../../../assets/image/qonline/logo_eduq.svg')
        }
        //steamq
        if(pathName.includes("/steamq")) {
            return require('../../../assets/image/qonline/logo_steamq.svg')
        }
        //freeq
        return require('../../../assets/image/qonline/logo_freeq.svg')

    }

    render() {
        const { open } = this.state;
        const pathName = window.location.pathname
        const isEduq = COMMON_EDUQ_ROUTER.includes(pathName)
        const isAuth = EDUQ_AUTH.includes(pathName)
        var extraClass = "qonline-top-header-fullscreen-mobile ";
        if (!isEduq) extraClass += "qonline-top-header-fullscreen"
        return (
            <div style={{ background: isEduq ? "#FFF" : "#F9F9F9" }}>
                <SectionInner extraClassName={[extraClass]}>
                    <div className="qonline-top-header-main">
                        <div className="qonline-top-header-container">
                            <div className="qonline-top-header-left">
                                <img onClick={this.onOpenMenu} className="qonline-top-header-mobile-logo"
                                    src={open ? iconMenu.open : iconMenu.close} />
                                <a href={QONLINE_HOME}>
                                    <img className="qonline-top-header-logo"
                                        src={this.setLogo(pathName)} />
                                </a>
                            </div>

                            <div className="qonline-top-header-right">
                                {
                                    isEduq ? <HeaderRightEduQ /> : isAuth ? null : <HeaderRightFreeQ />
                                }
                            </div>

                        </div>
                    </div>
                </SectionInner>
            </div>

        );
    }
}

export default QOnlineTopHeader;
