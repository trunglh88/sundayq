import React from 'react';
import './top-header.css';
import SectionInner from '../Container/SectionInner';
import { NavLink } from 'react-router-dom';

const iconMenu = {
    close: require('../../assets/icon/icon_mobile_menu_close.svg'),
    open: require('../../assets/icon/icon_mobile_menu_open.svg'),
};

class TopHeader extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            open: false,
        };
        this.onOpenMenu = this.onOpenMenu.bind(this);
    }


    onOpenMenu() {
        this.setState((prevState) => ({
            open: !prevState.open,
        }), () => this.props.onIconMenuClick(this.state.open));
    }

    render() {
        const { open } = this.state;
        return (
            <div className="top-header-main">
                <SectionInner>
                    <div className="top-header-container">
                        <div className="top-header-left">
                            <img onClick={this.onOpenMenu} className="top-header-mobile-logo"
                                src={open ? iconMenu.open : iconMenu.close} />
                            <a href={'/'}>
                                <img className="top-header-logo"
                                    src={require('../../assets/icon/home_logo.svg')} />
                            </a>
                            
                            <span className="top-header-slogan">Thỏa sức sáng tạo <br/> Khơi niềm đam mê</span>
                            
                        </div>
                        <div className="top-header-right">
                            <div className="top-header-search">
                                <img className="top-header-search-icon"
                                    src={require('../../assets/icon/ic_search.svg')} />
                                <input className="top-header-search-input" placeholder="Tìm kiếm" />
                            </div>
                            <a href="/q-visit" className="top-header-link">
                                <img src={require("../../assets/icon/ic_ticket.svg")}/>
                                <span>Vé/Voucher</span>
                            </a>
                            <a href="/q-academy" className="top-header-link">
                                <img src={require("../../assets/icon/ic_contact.svg")}/>
                                <span>Trở thành thành viên</span>
                            </a>
                        </div>
                    </div>

                </SectionInner>
            </div>
        );
    }
}

export default TopHeader;
