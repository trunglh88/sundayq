import React from 'react'
import "./video-player.css"
import ReactPlayer from 'react-player'
import { Utils, Storage } from '../../utils';

const mediaStyle = {
  root: {
    outLine: "none",
    border: "none"
  }
}

export default class VideoPlayer extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div className="video-player-wrapper">
        <ReactPlayer
          className="video-player"
          url={this.props.url}
          controls={true}
          style={mediaStyle.root}
          playing={this.props.playing}
          width="100%"
          outLine="none"
          height="100%"
          config={{
            file: {
              hlsOptions: {
                forceHLS: true,
                debug: false,
                xhrSetup: function (xhr, url) {
                  xhr.setRequestHeader('authorization', `Bearer ${Storage.getData(Storage.KEY.TOKEN)}` )
                },
              },
            },
          }}
        />
      </div>
    )
  }
}
VideoPlayer.defaultProps = {
  playing: false
}