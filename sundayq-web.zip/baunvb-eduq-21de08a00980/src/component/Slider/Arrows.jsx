import React from 'react';

export function PrevArrow(props) {
    const { onClick } = props;
    let src = require('../../assets/icon/ic_prev_arrow_black.png')

    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-left-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={src}
            />
        </div>
    );
}

export function NextArrow(props) {
    const { onClick } = props;
    let src = require('../../assets/icon/ic_next_arrow_black.png')
    return (
        <div
            className="q-academy-club-slider-nav-button q-academy-club-slider-right-arrow"
            onClick={onClick}
        >
            <img
                className="q-academy-club-slider-button-icon"
                alt="Prev"
                src={src}
            />
        </div>
    );
}

export default {NextArrow,PrevArrow};
