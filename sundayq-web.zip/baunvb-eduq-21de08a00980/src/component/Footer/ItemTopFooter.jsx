//tips: css loaded from parent component
import { NavLink } from "react-router-dom";
import React from 'react'

const screenWidth = window.innerWidth;
const iconOpenClose = {
    expander: require('../../assets/icon/icon_expand.svg'),
    collapse: require('../../assets/icon/icon_collapse.svg'),
}

class ItemTopFooter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            mobile: screenWidth <= 786 ? true : false,
            open: false,
        }
        this.openMenu = this.openMenu.bind(this);
    }

    openMenu() {
        this.setState((prveState) => ({
            open: !prveState.open
        }))
    }

    render() {
        const { router } = this.props;
        const { mobile, open } = this.state;
        let classNameMain = "top-footer-wrap-column ";
        let classNameTitle = "top-footer-wrap-title "
        if (mobile) classNameMain = classNameMain + "top-footer-wrap-column-mobile"
        if (open) classNameTitle = classNameTitle + "top-footer-wrap-title-active"
        return (
            <div className={classNameMain}>
                <div onClick={this.openMenu} className={classNameTitle}>
                    <span className="top-footer-title">{router.title}</span>
                    {
                        mobile ? <img className="top-footer-item-menu-icon" src={open ? iconOpenClose.collapse : iconOpenClose.expander} />
                            : null
                    }
                </div>
                {/* if <= 768 and open => show, else => hide
                    if > 768 => show
                */}
                <div style={{ display: mobile ? open ? 'contents' : 'none' : 'contents' }}>
                    {
                        router.router.map((item, index) => {
                            return (
                                <NavLink
                                    key={index}
                                    className="top-footer-navlink"
                                    to={item.link}
                                >
                                    <span className="top-footer-link-text">{item.name}</span>
                                </NavLink>
                            )
                        })
                    }
                </div>

            </div>
        )
    }
}


export default ItemTopFooter