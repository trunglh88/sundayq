import React from 'react'
import './top-footer.css'
import SectionInner from "../Container/SectionInner"
import { TopFooterRouter } from "../../router/TopFooterRouter"
import ItemTopFooter from "./ItemTopFooter"
const screenWidth = window.innerWidth;

class TopFooter extends React.Component {
    render() {
        let extraClass = ['top-footer-section-inner'];
        if(screenWidth <= 768){
            extraClass.push('top-footer-full-screen-width')
        }
        return (
            <div className="top-footer-main">
                <SectionInner extraClassName = {extraClass}>
                    <div className="top-footer-wrap-flex">

                        {
                            TopFooterRouter.map((category, key) => {
                                return (
                                    <ItemTopFooter router={category} key={key} />
                                )
                            })
                        }

                        </div>
                </SectionInner>
            </div>
        )
    }
}

export default TopFooter