import React from 'react'
import './footer.css'
import SectionInner from "../Container/SectionInner"
import { NavLink } from "react-router-dom";
import Map from "../../component/Map/Map"
import ListSocial from "../Social/ListSocial"
import ChatBox from '../Chat/ChatBox';
import { Utils } from '../../utils';
class Footer extends React.Component {
    render() {
        return (
            <div className="footer-main">
            {
                // Utils.isLogin() ? <ChatBox/> : null
            }
                <div id="commonAlert"></div>
                <SectionInner extraClassName={['footer-section-inner']}>
                    <div style={{display: 'flex'}}>
                        <div style={{flex: "1"}}>
                            <div className="footer-wrap-footer-logo">
                                <img className="footer-logo" src={require("../../assets/icon/logo_full.svg")} />
                            </div>

                            <div className="footer-wrap-flex">
                                <div className="footer-wrap-column">
                                    <span className="footer-column-title">Về SundayQ</span>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Hội đồng quản trị</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Hội đồng chuyên môn</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Các đối tác chiến lược</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Giới thiệu về Trung tâm</span>
                                    </NavLink>
                                </div>
                                <div className="footer-wrap-column">
                                    <span className="footer-column-title">Cùng với chúng tôi</span>

                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Tính pháp lý</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Thông tin tự do minh bạch</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-link">Chương trình giáo dục</span>
                                    </NavLink>
                                </div>
                                <div className="footer-wrap-column footer-wrap-column-home">
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-title">Trang chủ</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-title">Thành viên SundayQ</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-title">Vé / Khóa / Voucher</span>
                                    </NavLink>
                                    <NavLink
                                        className="footer-navlink"
                                        to=""
                                    >
                                        <span className="footer-column-title">Liên hệ</span>
                                    </NavLink>
                                    <div className="footer-wrap-social-icon">
                                        <ListSocial />
                                    </div>
                                </div>


                            </div>
                        </div>

                        <div className="footer-wrap-column footer-map">
                            <Map
                                id="footerMap"
                                width={395}
                                height={266}
                                options={{
                                    center: { lat: 21.084418, lng: 105.812180 },
                                    zoom: 13,
                                    mapTypeControl: false
                                }}
                                onMapLoad={map => {
                                    var markerFooter = new window.google.maps.Marker({
                                        draggable: false,
                                        animation: window.google.maps.Animation.DROP,
                                        position: { lat: 21.084418, lng: 105.812180 },
                                        map: map,
                                    });
                                }}
                            />
                        </div>
                    </div>
                </SectionInner>
            </div>
        )
    }
}

export default Footer
