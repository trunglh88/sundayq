import React from 'react';
import './bottom-footer.css';
import SectionInner from '../Container/SectionInner';

export default class BottomFooter extends React.Component {
    render() {
        return (
            <div className="bottom-footer-main">
                <SectionInner
                    extraClassName={['bottom-footer-container']}
                >
                    <div className="bottom-footer-left">
                        <span
                            className="bottom-footer-text"
                        >
                            &copy; All rights reserved - SundayQ
                        </span>
                    </div>
                    <div className="bottom-footer-middle"></div>
                    <div className="bottom-footer-right">
                        <span
                            style={{ textDecoration: "underline" }}
                            className="bottom-footer-text"
                        >
                            {'Conditions of use'}
                        </span>

                        <span
                            style={{ textDecoration: "underline" }}
                            className="bottom-footer-text bottom-footer-left-margin"
                        >
                            {'Term of policy'}
                        </span>
                    </div>
                </SectionInner>
            </div>
        );
    }
}
