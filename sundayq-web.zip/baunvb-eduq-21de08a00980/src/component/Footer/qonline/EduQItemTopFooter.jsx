import { NavLink } from "react-router-dom";
import React, { useState } from 'react'

const screenWidth = window.innerWidth;
const iconOpenClose = {
    expander: require('../../../assets/icon/icon_expand.svg'),
    collapse: require('../../../assets/icon/icon_collapse.svg'),
}

function SubmenuLv2(props) {
    const [isOpenSubmenu, setOpenSubmenu] = useState(false);
    const { menu } = props;
    return (
        <div className="eduq-top-footer-lv2">
            <span className="eduq-top-footer-link-text"
                onClick={() => setOpenSubmenu(prev => !prev)}
            >
                {menu.name}
                <img  className={ isOpenSubmenu ? "rotate-dropdown-open eduq-top-footer-lv2-dropdown" : "eduq-top-footer-lv2-dropdown"} src={require("../../../assets/image/qonline/ic_dropdown_white.svg")}/>
            </span>
            {
                Boolean(menu.subRouter) ?
                    <div style={{ display: isOpenSubmenu ? "block" : "none" }} className="eduq-top-footer-submenu">
                        {

                            menu.subRouter.map((subItem, subIndex) => {
                                return (
                                    <a href={subItem.path}>{subItem.name}</a>
                                )
                            })
                        }
                    </div> : null
            }

        </div>
    )
}

class EduQItemTopFooter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            mobile: screenWidth <= 786 ? true : false,
            open: false,
            isOpenSubmenu: false
        }
        this.openMenu = this.openMenu.bind(this);
    }

    // open menu mobile
    openMenu() {
        this.setState((prveState) => ({
            open: !prveState.open
        }))
    }

    // open menu level2
    onOpenSubmenu = () => {
        this.setState((prevState) => ({
            isOpenSubmenu: !prevState.isOpenSubmenu
        }))
    }

    render() {
        const { router } = this.props;
        const { mobile, open, isOpenSubmenu } = this.state;
        let classNameMain = "eduq-top-footer-wrap-column ";
        let classNameTitle = "eduq-top-footer-wrap-title "
        if (mobile) classNameMain = classNameMain + "eduq-top-footer-wrap-column-mobile"
        if (open) classNameTitle = classNameTitle + "eduq-top-footer-wrap-title-active"
        return (
            <div className={classNameMain}>
                <div onClick={this.openMenu} className={classNameTitle}>
                    <span className="eduq-top-footer-title">{router.title}</span>
                    {
                        mobile ? <img className="eduq-top-footer-item-menu-icon" src={open ? iconOpenClose.collapse : iconOpenClose.expander} />
                            : null
                    }
                </div>
                {/* if <= 768 and open => show, else => hide
                    if > 768 => show
                */}
                <div style={{ display: mobile ? open ? 'contents' : 'none' : 'contents' }}>
                    {
                        router.router.map((item, index) => {

                            return (
                                <NavLink
                                    key={index}
                                    className="eduq-top-footer-navlink"
                                    to={item.path}
                                >
                                    <SubmenuLv2 menu={item} />
                                </NavLink>
                            )
                        })
                    }
                </div>

            </div>
        )
    }
}


export default EduQItemTopFooter