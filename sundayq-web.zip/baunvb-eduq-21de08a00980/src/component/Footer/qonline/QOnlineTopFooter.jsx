import React from 'react'
import './qonline-top-footer.css'
import SectionInner from "../../Container/SectionInner"
import { QOnlineTopFooterRouter } from "../../../router/QOnlineTopFooterRouter"
import ItemTopFooter from "./../ItemTopFooter"
const screenWidth = window.innerWidth;

class QOnlineTopFooter extends React.Component {
    render() {
        let extraClass = ['qonline-top-footer-section-inner'];
        if (screenWidth <= 768) {
            extraClass.push('qonline-top-footer-full-screen-width')
        }
        return (
            <div className="qonline-top-footer-main">
                <SectionInner extraClassName={extraClass}>
                    <div className="qonline-top-footer-wrap-flex">

                        {
                            QOnlineTopFooterRouter.map((category, key) => {
                                return (
                                    <ItemTopFooter router={category} key={key} />
                                )
                            })
                        }

                    </div>
                </SectionInner>
            </div>
        )
    }
}

export default QOnlineTopFooter