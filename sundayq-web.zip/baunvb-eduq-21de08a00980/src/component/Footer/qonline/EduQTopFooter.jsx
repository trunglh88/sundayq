import React from 'react'
import './eduq-top-footer.css'
import SectionInner from "../../Container/SectionInner"
import { QOnlineHomeTopFooterRouter } from "../../../router/QOnlineHomeTopFooterRouter"
import EduQItemTopFooter from "./EduQItemTopFooter"
import ChatBox from '../../Chat/ChatBox';
const screenWidth = window.innerWidth;

class QOnlineTopFooter extends React.Component {
    render() {
        let extraClass = [];
        if (screenWidth <= 768) {
            extraClass.push('eduq-top-footer-full-screen-width')
        }
        return (
            <div className="eduq-top-footer-main">
                <SectionInner extraClassName={extraClass}>
                    <div className="eduq-top-footer-wrap-flex">

                        {
                            QOnlineHomeTopFooterRouter.map((category, key) => {
                                return (
                                    <EduQItemTopFooter router={category} key={key} />
                                )
                            })
                        }

                    </div>
                </SectionInner>
            </div>
        )
    }
}

export default QOnlineTopFooter