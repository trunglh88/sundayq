import QOnlineFreeTrial from '../screen/qonline/freeqservice/videotrial/QOnlineFreeTrial';
import QOnlinePlan from '../screen/qonline/freeqservice/videotrial/QOnlinePlan';
import PlayPlace from "../screen/qonline/freeqservice/freeq/PlayPlace";
import DevelopBrain from "../screen/qonline/freeqservice/freeq/DevelopBrain";
import Manifesto from "../screen/qonline/freeqservice/homestudy/Manifesto";
import ListFriendAtFreeQ from "../screen/qonline/freeqservice/friend/ListFriendAtFreeQ";
import RegisterForm from '../screen/qonline/register/RegisterForm'
import QOnlineLogin from '../screen/qonline/login/QOnlineLogin'
import RegisterVerifyEmail from '../screen/qonline/register/RegisterVerifyEmail'
import ProgramCharacter from "../screen/qonline/freeqservice/buildcharacter/ProgramCharacter";
import Order from "../screen/qonline/order/Order";
import OrderSuccess from "../screen/qonline/order/OrderSuccess";
import PaymentCallback from "../screen/qonline/payment/PaymentCallback"
export const QOnlineFreeQRouter = [
    {
        // redirect: true,
        path: '/',
        name: 'FreeQ',
        // pathTo: "/q-online/sample",
        subMenu: [
            {
                name: "Khu vu chơi tự do tại FreeQ",
                path: "/q-online/play-place"
            },
            {
                name: "Câu chuyện phát triển não bộ của trẻ sơ sinh",
                path: "/q-online/develop-brain"
            },
            {
                name: "Điều kiện nuôi dạy trẻ theo tiêu chuẩn",
                path: "#"
            }
        ]
    },
    {
        component: PaymentCallback,
        path: "/q-online/payment/callback"
    },
    {
        component: OrderSuccess,
        path: "/q-online/buy-success"
    },
    {
        component: RegisterForm,
        path: "/q-online/register"
    },
    {
        component: RegisterVerifyEmail,
        path: "/q-online/register/verify"
    },
    {
        component: QOnlineLogin,
        path: "/q-online/login"
    },
    {
        component: QOnlineFreeTrial,
        path: "/q-online/sample"
    },
    {
        component: QOnlinePlan,
        path: "/q-online/plan"
    },
    {
        component: PlayPlace,
        path: "/q-online/play-place"
    },
    {
        component: DevelopBrain,
        path: "/q-online/develop-brain"
    },
    {
        component: Manifesto,
        path: "/q-online/house-study-manifesto"
    },
    {
        component: ProgramCharacter,
        path: "/q-online/program-character"
    },
    {
        component: ListFriendAtFreeQ,
        path: "/q-online/friends"
    },
    {
        component: Order,
        path: "/q-online/order"
    },
    {
        component: QOnlinePlan,
        name: 'Nuôi dạy trẻ tại gia đình',
        subMenu: [
            {
                name: "Tuyên ngôn",
                path: "/q-online/house-study-manifesto"
            },
            {
                name: "Tổng quan giáo dục",
                path: "#"
            }
            
        ]
    },
    {
        path: '/q-online/2',
        name: 'Nuôi dạy trẻ tại lớp',
        subMenu: [
            {
                name: "Bài giảng mẫu",
                path: "/q-online/sample"
            },
            {
                name: "Kế hoạch giáo dục",
                path: "/q-online/plan"
            }
        ]

    },
    {
        disable: true,
        name: 'Xây dựng nhân cách trẻ',
        subMenu: [
            {
                name: "Chương trình xây dựng nhân cách trẻ",
                path: "/q-online/program-character"
            },
            {
                name: "Câu chuyện xây dựng nhân cách trẻ",
                path: "#"
            },
            {
                name: "Stick Together - Chơi cùng nhau",
                path: "#"
            }
            
        ]

    },
    {
        name: 'Những người bạn tại FreeQ',
        subMenu: [
            {
                name: "Bạn thỏ năng động",
                path: "/q-online/friends#rabbit"
            },
            {
                name: "Bạn rùa chăm chỉ",
                path: "/q-online/friends#turtle"
            },
            {
                name: "Bạn gấu đáng yêu",
                path: "/q-online/friends#bear"
            },
            {
                name: "Bạn chó trách nhiệm",
                path: "/q-online/friends#dog"
            },
            {
                name: "Bạn vẹt thông thái",
                path: "/q-online/friends#parakeet"
            },
            {
                name: "Bạn mèo xinh đẹp",
                path: "/q-online/friends#cat"
            }
            
        ]

    },
    // {
    //     name: 'ĐĂNG NHẬP TÀI KHOẢN',
    //     path: "/q-online/login"

    // },

];
