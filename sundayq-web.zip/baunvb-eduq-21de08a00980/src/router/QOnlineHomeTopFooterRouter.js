export const QOnlineHomeTopFooterRouter = [
    {
        title: "FreeQ",
        router: [
            {
                name: "FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "Khu vu chơi tự do tại FreeQ",
                        path: "/q-online/play-place"
                    },
                    {
                        name: "Câu chuyện phát triển não bộ của trẻ sơ sinh",
                        path: "/q-online/develop-brain"
                    },
                    {
                        name: "Điều kiện nuôi dạy trẻ theo tiêu chuẩn",
                        path: "#"
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại gia đình",
                path: "#",
                subRouter: [
                    {
                        name: "Tuyên ngôn",
                        path: "/q-online/house-study-manifesto"
                    },
                    {
                        name: "Tổng quan giáo dục",
                        path: "#"
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại lớp",
                path: "#",
                subRouter: [
                    {
                        name: "Kế hoạch giáo dục",
                        path: "/q-online/plan"
                    },
                    {
                        name: "Bài giảng mẫu",
                        path: "/q-online/sample"
                    }
                ],
            },
            {
                name: "Xây dựng nhân cách trẻ",
                path: "#",
                subRouter: [
                    {
                        name: "Chương trình xây dựng nhân cách trẻ",
                        path: "/q-online/program-character"
                    },
                    {
                        name: "Câu chuyện xây dựng nhân cách trẻ",
                        path: "#"
                    },
                    {
                        name: "Stick Together - Chơi cùng nhau",
                        path: "#"
                    }
                ],
            },
            {
                name: "Những người bạn tại FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "Bạn thỏ năng động",
                        path: "/q-online/friends#rabbit"
                    },
                    {
                        name: "Bạn rùa chăm chỉ",
                        path: "/q-online/friends#turtle"
                    },
                    {
                        name: "Bạn gấu đáng yêu",
                        path: "/q-online/friends#bear"
                    },
                    {
                        name: "Bạn chó trách nhiệm",
                        path: "/q-online/friends#dog"
                    },
                    {
                        name: "Bạn vẹt thông thái",
                        path: "/q-online/friends#parakeet"
                    },
                    {
                        name: "Bạn mèo xinh đẹp",
                        path: "/q-online/friends#cat"
                    }
                ],
            },
            
        ]
    },
    {
        title: "SteamQ",
        router: [
            {
                name: "FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại gia đình",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại lớp",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Xây dựng nhân cách trẻ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Những người bạn tại FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
        ]
    },
    {
        title: "JoyQ",
        router: [
            {
                name: "FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại gia đình",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Nuôi dạy trẻ tại lớp",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Xây dựng nhân cách trẻ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
            {
                name: "Những người bạn tại FreeQ",
                path: "#",
                subRouter: [
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    },
                    {
                        name: "",
                        path: "#"                    
                    }
                ],
            },
        ]
    }

]
