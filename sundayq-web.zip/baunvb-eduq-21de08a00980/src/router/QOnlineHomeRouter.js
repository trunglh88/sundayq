import QOnlineHomeScreen from '../screen/qonline/QOnlineHomeScreen';
export const QOnlineHomeRouter = [
    {
        path: '/',
        component: QOnlineHomeScreen,
        name: 'Trang chủ',
        subTitle: '(Học viện trực tuyến)',

    },
    {
        path: '/q-online/sample',
        name: 'Freeq',
        subTitle: '(Cho trẻ 0 -2 tuổi)',
    },
    {
        path: '/qonline/joyq',
        component: QOnlineHomeScreen,
        name: 'joyq',
        subTitle: '(Cho trẻ 3 - 7 tuổi)',
        disable: true,
    },
    {
        path: '/steamq',
        component: QOnlineHomeScreen,
        name: 'steamq',
        subTitle: '(Cho trẻ 8 - 15 tuổi)',
    },

    {
        path: '/qonline/news',
        component: QOnlineHomeScreen,
        name: 'edu NEWS',
        subTitle: '(Tin tức giáo dục)',
        disable: true,
    },
];
