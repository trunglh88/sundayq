import QOnlineFreeTrial from '../screen/qonline/freeqservice/videotrial/QOnlineFreeTrial';
import QOnlinePlan from '../screen/qonline/freeqservice/videotrial/QOnlinePlan';
import PlayPlace from "../screen/qonline/freeqservice/freeq/PlayPlace";
import DevelopBrain from "../screen/qonline/freeqservice/freeq/DevelopBrain";
import Manifesto from "../screen/qonline/freeqservice/homestudy/Manifesto";
import ListFriendAtFreeQ from "../screen/qonline/freeqservice/friend/ListFriendAtFreeQ";
import RegisterForm from '../screen/qonline/register/RegisterForm'
import QOnlineLogin from '../screen/qonline/login/QOnlineLogin'
import RegisterVerifyEmail from '../screen/qonline/register/RegisterVerifyEmail'
import ProgramCharacter from "../screen/qonline/freeqservice/buildcharacter/ProgramCharacter";
import Order from "../screen/qonline/order/Order";
import OrderSuccess from "../screen/qonline/order/OrderSuccess";
import PaymentCallback from "../screen/qonline/payment/PaymentCallback"
export const SteamqRouter = [
    {
      name: "Science",
      path: "/steamq/tab1",
      component: OrderSuccess
    },
    {
      name: "Technology",
      path: "/steamq/tab2",
      component: ListFriendAtFreeQ
    },
    {
      name: "Engineering",
      path: "/steamq/tab2",
      component: ListFriendAtFreeQ
    },
    {
      name: "Art",
      path: "/steamq/tab2",
      component: ListFriendAtFreeQ
    },
    {
      name: "Math",
      path: "/steamq/tab2",
      component: ListFriendAtFreeQ
    }
];
