
import QVisitVisitScreen from '../screen/qvisit/visit/QVisitVisitScreen';
import QVisitTicketScreen from '../screen/qvisit/ticket/QVisitTicketScreen';
import QVisitContactUs from '../screen/qvisit/contactus/QVisitContactUs';
import QVisitEvent from '../screen/qvisit/event/QVisitEvent';
import QVisitTourScreen from '../screen/qvisit/tour/QVisitTourScreen';
import QVisitClubScreen from '../screen/qvisit/club/QVisitClubScreen';
import QVisitBookScreen from '../screen/qvisit/book/QVisitBookScreen';
import QVisitStoreScreen from '../screen/qvisit/store/QVisitStoreScreen';
import QVisitCafe from '../screen/qvisit/cafe/QvisitCafe';
import QVisitClass from '../screen/qvisit/academy/QVisitClass';
import QVisitPostDetailScreen from '../screen/qvisit/post/QVisitPostDetailScreen';

export const QVisitRouter = [
  {
    path: '/q-visit/visit',
    component: QVisitVisitScreen,
    name: 'Tham quan',
    title: 'THAM QUAN',
    shortLink: 'Trang chủ >> Q-Visit >> Tham quan'
  },
  {
    path: '/q-visit/ticket',
    component: QVisitTicketScreen,
    name: 'Vé / Khóa / Voucher',
    title: 'Vé',
    shortLink: 'Trang chủ >> Q-Visit >> Vé / Khóa / Voucher'
  },
  {
    path: '/q-visit/event',
    component: QVisitEvent,
    name: 'Các sự kiện đang và sắp diễn ra',
    title: 'SỰ KIỆN ĐANG VÀ SẮP DIỄN RA',
    shortLink: 'Trang chủ >> Q-Visit >> Sự kiện đang và sắp diễn ra'

  },
  {
    path: '/q-visit/tour',
    component: QVisitTourScreen,
    name: 'Trải nghiệm và triển lãm',
    title: 'TRẢI NGHIỆM VÀ TRIỂN LÃM',
    shortLink: 'Trang chủ >> Q-Visit >> Trải nghiệm và triển lãm'

  },
  {
    path: '/q-visit/coffe',
    component: QVisitCafe,
    name: 'SundayQ Café',
    title: 'SundayQ Café',
    shortLink: 'Trang chủ >> Q-Visit >> SundayQ Café'

  },
  {
    path: '/q-visit/store',
    component: QVisitStoreScreen,
    name: 'Cửa hàng SundayQ',
    title: 'CỬA HÀNG SUNDAYQ',
    shortLink: 'Trang chủ >> Q-Visit >> Cửa hàng SundayQ'

  },
  {
    path: '/q-visit/book',
    component: QVisitBookScreen,
    name: 'Đặt Chỗ',
    title: 'Đặt Chỗ',
    shortLink: 'Trang chủ >> Q-Visit >> Đặt Chỗ'

  },
  {
    path: '/q-visit/member',
    component: QVisitClubScreen,
    name: 'CLB SundayQ',
    title: 'Thành viên',
    shortLink: 'Trang chủ >> Q-Visit >> CLB SundayQ'

  },
  {
    path: '/q-visit/class',
    component: QVisitClass,
    name: 'Học viện SundayQ',
    title: 'Học viện SundayQ',
    shortLink: 'Trang chủ >> Q-Visit >> Học viện SundayQ'

  },
  {
    path: '/q-visit/contact',
    component: QVisitContactUs,
    name: 'Liên hệ với chúng tôi',
    title: 'Liên hệ với chúng tôi',
    shortLink: 'Trang chủ >> Q-Visit >> Liên hệ với chúng tôi'

  },
  {
    invisibleInTabBar: true,
    path: '/q-visit/post',
    component: QVisitPostDetailScreen
  },
  {
    invisibleInTabBar: true,
    path: '/q-visit',
    redirect: true,
    pathTo: '/q-visit/visit'
  },

]
