export const QOnlineTopFooterRouter = [
    {
        title: "FreeQ",
        router: [
            {
                name: "Khu vui chơi tự do tại FreeQ",
                link: "/q-online/play-place"
            },
            {
                name: "Câu chuyện phát triển não bộ của trẻ sơ sinh",
                link: "/q-online/develop-brain"
            },
            {
                name: "Điều kiện nuôi dạy trẻ theo tiêu chuẩn",
                link: "#"
            }
        
        ]
    },
    {
        title: "Nuôi dạy trẻ tại gia đình",
        router: [
            {
                name: "Tuyên ngôn",
                link: "/q-online/house-study-manifesto"
            },
            {
                name: "Tổng quan giáo dục",
                link: "#"
            }
            
        ]
    },
    {
        title: "Nuôi dạy trẻ tại lớp",
        router: [
            {
                name: "Kế hoạch giáo dục",
                link: "/q-online/plan"
            },
            {
                name: "Bài giảng mẫu",
                link: "/q-online/sample"
            }
        ]
    },
    {
        title: "Xây dựng nhân cách trẻ",
        router: [
            {
                name: "Chương trình xây dựng nhân cách trẻ",
                link: "/q-online/program-character"
            },
            {
                name: "Câu chuyện xây dựng nhân cách trẻ",
                link: "#"
            },
            {
                name: "Stick Together - Chơi cùng nhau",
                link: "#"
            }
        ]
    },
    {
        title: "Những người bạn tại FreeQ",
        router: [
            {
                name: "Bạn thỏ năng động",
                link: "/q-online/friends#rabbit"
            },
            {
                name: "Bạn rùa chăm chỉ",
                link: "/q-online/friends#turtle"
            },
            {
                name: "Bạn gấu đáng yêu",
                link: "/q-online/friends#bear"
            },
            {
                name: "Bạn chó trách nhiệm",
                link: "/q-online/friends#dog"
            },
            {
                name: "Bạn vẹt thông thái",
                link: "/q-online/friends#parakeet"
            },
            {
                name: "Bạn mèo xinh đẹp",
                link: "/q-online/friends#cat"
            }
        ]
    }
    
]
