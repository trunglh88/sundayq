export const TopFooterRouter = [
    {
        title: "Q-Visit",
        router: [
            {
                name: "Khám phá Trái đất và Vũ trụ",
                link: ""
            },
            {
                name: "Phòng thí nghiệm Dr.Right",
                link: ""
            },
            {
                name: "Khoa học hấp dẫn",
                link: ""
            },
            {
                name: "Khoa học máy tính",
                link: ""
            },
            {
                name: "Ngạc nhiên chưa",
                link: ""
            },
            {
                name: "Máy móc phát minh sáng chế",
                link: ""
            },
            {
                name: "Gặp gỡ Robot Q",
                link: ""
            },
            {
                name: "Nghệ thuật – Trang trí",
                link: ""
            },
            {
                name: "Sắc màu diệu kỳ",
                link: ""
            }
        ]
    },
    {
        title: "Q-Academy",
        router: [
            {
                name: "Q-Academy",
                link: ""
            },
            {
                name: "Nhà khoa học Dr.Right",
                link: ""
            },
            {
                name: "Bé yêu khoa học",
                link: ""
            },
            {
                name: "Hàng không vũ trụ",
                link: ""
            },
            {
                name: "Lập trình với robot",
                link: ""
            },
            {
                name: "Sáng tạo không giới hạn",
                link: ""
            },
            {
                name: "Nhà thiết kế",
                link: ""
            },
            {
                name: "Tập làm họa sỹ",
                link: ""
            },
            {
                name: "Tiếng anh dành cho trẻ em",
                link: ""
            }
        ]
    },
    {
        title: "Q-Online",
        router: [
            {
                name: "Sân chơi tự do FreeQ",
                link: ""
            },
            {
                name: "Mầm non JoyQ",
                link: ""
            },
            {
                name: "Các khóa STEAMQ",
                link: ""
            },
            {
                name: "Lập trình RobotQ",
                link: ""
            },
            {
                name: "Lập trình Toán Tin Q",
                link: ""
            },
            {
                name: "WorkshopQ",
                link: ""
            },
            {
                name: "Dự án Q",
                link: ""
            }
        ]
    },
    {
        title: "Q-Contest",
        router: [
            {
                name: "Science contest",
                link: ""
            },
            {
                name: "Tin học Trẻ không chuyên",
                link: ""
            },
            {
                name: "Cuộc thi khoa học kĩ thuật cấp quốc gia",
                link: ""
            },
            {
                name: "Cuộc thi ý tưởng phát minh và sáng chế Nhật Bản",
                link: ""
            },
            {
                name: "Kỳ thi Tay nghề quốc gia",
                link: ""
            },
            {
                name: "Project Runway",
                link: ""
            },
            {
                name: "INTARG",
                link: ""
            },
            {
                name: "Robocon",
                link: ""
            }
        ]
    },
    {
        title: "Q-Show",
        router: [
            {
                name: "Khoa học diệu kỳ",
                link: ""
            },
            {
                name: "Sáng tạo không giới hạn",
                link: ""
            },
            {
                name: "Công nghệ dẫn đầu",
                link: ""
            },
            {
                name: "Góc giải trí",
                link: ""
            }
        ]
    },
    // {
    //     title: "Q-Shop",
    //     router: [
    //         {
    //             name: "Thiết bị dạy học",
    //             link: ""
    //         },
    //         {
    //             name: "Vật tư học cụ",
    //             link: ""
    //         },
    //         {
    //             name: "Đồ chơi thông minh",
    //             link: ""
    //         },
    //         {
    //             name: "Đồ chơi phát triển sáng tạo",
    //             link: ""
    //         },
    //         {
    //             name: "SP khuyến mại",
    //             link: ""
    //         },
    //         {
    //             name: "Sp liên kết",
    //             link: ""
    //         }
    //     ]
    // },
    {
        title: "Q-Expert",
        router: [
            {
                name: "Khoa học",
                link: ""
            },
            {
                name: "Công Nghệ",
                link: ""
            },
            {
                name: "Sáng Tạo",
                link: ""
            },
            {
                name: "Kinh doanh",
                link: ""
            },
            {
                name: "Giáo dục Trẻ em",
                link: ""
            },
            {
                name: "Tâm lý Trẻ em",
                link: ""
            },
            {
                name: "Sức Khỏe Trẻ em",
                link: ""
            },
            {
                name: "Hướng nghiệp",
                link: ""
            }
        ]
    },
]
