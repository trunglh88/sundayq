import QAcademyScreen from '../screen/qacademy/qacademy/QAcademyScreen';
import QAcademyCourseScreen from '../screen/qacademy/coursedetail/CourseDetailScreen';
import QExpertScreen from '../screen/qacademy/qexpert/QExpertScreen';
import LecturerList from '../screen/qacademy/qexpert/LecturerList';
import ClubScreen from '../screen/qacademy/clubdetail/ClubScreen';
import QVisitLayout from '../layout/QVisitLayout';
export const QAcademyRouter = [
    {
        path: '/q-visit',
        component: QVisitLayout,
        name: 'Q-Visit',
        subTitle: '(Tham quan trải nghiệm)',

    },
    {
        path: '/q-academy',
        component: QAcademyScreen,
        name: 'Q-Academy',
        subTitle: '(Học viện SundayQ)',
    },
    {
        path: '/q-online/home',
        component: QAcademyScreen,
        name: 'Q-Online',
        subTitle: '(Học viện trực tuyến)',
        disable: false,
    },
    {
        path: '/q-contest',
        component: QAcademyScreen,
        name: 'Q-Contest',
        subTitle: '(Các cuộc thi)',
        disable: true,
    },
    {
        path: '/q-outreach',
        component: QAcademyScreen,
        name: 'Q-SHOW',
        subTitle: '(Video)',
        disable: true,
    },

    {
        path: '/q-shop',
        component: QAcademyScreen,
        name: 'Q-Shop',
        subTitle: '(Mua sắm)',
        disable: true,
    },
    {
        invisibleInTabBar: true,
        path: '/q-expert',
        component: QExpertScreen,
        disable: false,
    },
    {
        invisibleInTabBar: true,
        path: '/q-academy/course',
        component: QAcademyCourseScreen,
    },
    {
        invisibleInTabBar: true,
        path: '/q-academy/club',
        component: ClubScreen,
    },
    {
        name: 'Q-Expert',
        isHideBorder: true,
        subTitle: '(Chuyên gia)',
        path: '/q-expert/lecturers',
        component: LecturerList
    },
    // { redirect: true, path: '/', pathTo: '/q-academy' },

];
