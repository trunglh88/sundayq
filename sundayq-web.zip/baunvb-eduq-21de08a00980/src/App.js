import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import HomeScreen from './screen/home/HomeScreen'
import QAcademyLayout from './layout/QAcademyLayout';
import QOnlineFreeqLayout from './layout/QOnlineFreeqLayout';
import QVisitLayout from './layout/QVisitLayout';
import QOnlineHomeLayout from './layout/qonline/home/QOnlineHomeLayout'
import Auth from './layout/Auth';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Provider } from 'react-redux';

import configurationStore from './utils/redux-store';
import SteamqLayout from './layout/qonline/steamq/SteamqLayout';

const indexRoutes = [
    {
        path: "/steamq",
        component: SteamqLayout
    },
    {
        path: '/q-online',
        component: QOnlineFreeqLayout,
    },
    //thêm '/q-expert' để chỉ định component là  QAcademyLayout, nếu không sẽ nhận component HomeScreen
    //If add new layout, "/" router have to end of arr
    {
        path: '/',
        component: QOnlineHomeLayout,
    },


];

const hist = createBrowserHistory();

const App = () => {
    return (
        <Provider store={configurationStore()}>
            <Router history={hist}>
                <Switch>
                    {
                        indexRoutes.map((prop, key) => {
                            return <Route path={prop.path} component={prop.component} key={key} />;
                        })
                    }
                </Switch>
            </Router>
        </Provider>
    );
};

export default App;
