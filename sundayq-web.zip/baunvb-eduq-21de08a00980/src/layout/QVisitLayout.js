import React from "react";
import HomeHeader from "../component/Header/HomeHeader"
import { QAcademyRouter } from "../router/QAcademyRouter"
import TopHeader from "../component/Header/TopHeader";
import TopFooter from "../component/Footer/TopFooter"
import Footer from "../component/Footer/Footer"
import BottomFooter from "../component/Footer/BottomFooter";
import { QVisitRouter } from '../router/QVisitRouter'
import { Switch, Route, Redirect } from "react-router-dom";
import QVisitSidebar from '../screen/qvisit/common/QVisitSidebar'
import SectionInner from '../component/Container/SectionInner';
import FooterSlogan from "../component/Slogan/FooterSlogan"
import MemberAndShop from "../component/ListItem/MemberAndShop";
import "./qvisit-layout.css";
import {connect} from 'react-redux';
const switchRoutes = (
  <Switch>
    {QVisitRouter.map((prop, key) => {
      if (prop.redirect)
        return <Redirect from={prop.path} to={prop.pathTo} key={key} />;
      return <Route
        path={prop.path} component={prop.component} key={key} />;
    })}
  </Switch>
);

class QAcademyLayout extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false
    }
  }

  onIconMenuClick = (value) => {
    this.setState({
      isMenuOpen: value
    })
  }

  render() {

    let pathName = window.location.href;
    const index = QVisitRouter.findIndex(item => pathName.includes(item.path));

    let shortLink;
    if(QVisitRouter[index].shortLink == undefined) {
      shortLink = "Trang chủ >> Q-Visit >> " + this.props.title;
    } else {
      shortLink = QVisitRouter[index].shortLink
    }

    return (
      <div>
        <TopHeader onIconMenuClick={this.onIconMenuClick} />

        <div className="qvisit-layout-container">
          <HomeHeader extraClassName={['qvisit-layout-transparent-header']} isOpen={this.state.isMenuOpen} router={QAcademyRouter} {...this.props} />

          <SectionInner extraClassName={['home-screen-full-width']}>
            <div className="qvisit-layout-shortlink">
              <span>{shortLink}</span>
            </div>
            <div className="qvisit-layout-main">
              <div className="qvisit-layout-sidebar">
                <QVisitSidebar {...this.props} />
              </div>
              <div className="qvisit-layout-content">
                {
                  typeof QVisitRouter[index].title != 'undefined' && <span id="qvisit-layout-title" className="qvisit-sidebar-title">{QVisitRouter[index].title}</span>
                }
                {switchRoutes}
              </div>
            </div>
            <MemberAndShop />
          </SectionInner>

        </div>
        <FooterSlogan />
        <TopFooter />
        <Footer />
        <BottomFooter />
      </div>
    )
  }

}
const mapDispatchStateToProps = state => {
  return {
      title: state.qVistiReducer.title
  };
};
export default connect(mapDispatchStateToProps, null) (QAcademyLayout);
