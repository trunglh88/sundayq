import React from "react";
import HomeHeader from "../component/Header/HomeHeader"
import { QAcademyRouter } from "../router/QAcademyRouter"
import { Switch, Route, Redirect, useLocation } from "react-router-dom";
import TopHeader from "../component/Header/TopHeader";
import TopFooter from "../component/Footer/TopFooter"
import Footer from "../component/Footer/Footer"
import BottomFooter from "../component/Footer/BottomFooter";
import SectionInner from '../component/Container/SectionInner';
import MemberAndShop from "../component/ListItem/MemberAndShop";
import "./qacademy-layout.css"
import FooterSlogan from "../component/Slogan/FooterSlogan"
import QAcademyBg from "../assets/image/qacademy-bg.svg";

const switchRoutes = (
  <Switch>
    {QAcademyRouter.map((prop, key) => {
      if (prop.redirect)
        return <Redirect from={prop.path} to={prop.pathTo} key={key} />;
      return <Route
        exact path={prop.path} component={prop.component} key={key} />;
    })}
  </Switch>
);

class QAcademyLayout extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false
    }
  }

  onIconMenuClick = (value) => {
    this.setState({
      isMenuOpen: value
    })
  }


  setBackground = () => {
    const pathName = this.props.location.pathname;
    console.log("xxxxxxxx", pathName == "/q-academy")
    if (pathName == "/q-academy") {
      return {
        backgroundImage: `url(${QAcademyBg})`
      }
    }

    if (pathName.includes("/q-expert")) {
      return {
        backgroundImage: `url('')`,
      }
    }

    return null

  }

  render() {
    // special bg image q-academy
    return (
      <div>
        <TopHeader onIconMenuClick={this.onIconMenuClick} />
        <div style={this.setBackground()} className="qacademy-layout-main">
          <HomeHeader isOpen={this.state.isMenuOpen} router={QAcademyRouter} {...this.props} />

          <div>
            {switchRoutes}
          </div>
          <SectionInner extraClassName={['screen-full-width']}>
            <MemberAndShop />
          </SectionInner>
        </div>
        <FooterSlogan />

        <TopFooter />
        <Footer />
        <BottomFooter />
      </div>
    )
  }

}

export default QAcademyLayout;
