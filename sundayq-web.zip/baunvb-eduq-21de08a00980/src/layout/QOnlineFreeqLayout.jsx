import React from "react";
import QOnlineFreeqHeader from "../component/Header/qonline/QOnlineFreeqHeader"
import { QOnlineFreeQRouter } from "../router/QOnlineFreeQRouter"
import { Switch, Route, Redirect } from "react-router-dom";
import QOnlineTopHeader from "../component/Header/qonline/QOnlineTopHeader";
import QOnlineTopFooter from "../component/Footer/qonline/QOnlineTopFooter"
import Footer from "../component/Footer/Footer"
import BottomFooter from "../component/Footer/BottomFooter";
import { FreeQLayoutContext, themes } from '../context/FreeQLayoutContext'

const switchRoutes = (
  <Switch>
    {QOnlineFreeQRouter.map((prop, key) => {
      if (prop.redirect)
        return <Redirect exact from={prop.path} to={prop.pathTo} key={key} />;
      return <Route exact path={prop.path} component={prop.component} key={key} />;
    })}
  </Switch>
);

class QOnlineFreeqLayout extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false,
      theme: themes.sample,
      isShowHeader: true,
      isShowFooter: true,
    }
  }

  componentDidMount() {
    console.log("HOME");
    const pathName = this.props.location.pathname;
    if (pathName.includes("/q-online/plan")) {
      this.setState({ theme: themes.plan })
    }
    if (pathName.includes("/q-online/register") || pathName.includes("/q-online/login") || pathName.includes("/q-online/order") || pathName.includes("/q-online/buy-success")|| pathName.includes("/q-online/payment/callback")) {
      this.setState({isShowFooter: false, isShowHeader: false})
    }
  }

  onIconMenuClick = (value) => {
    this.setState({
      isMenuOpen: value
    })
  }


  render() {
    const {isShowFooter, isShowHeader} = this.state;
    return (
      <FreeQLayoutContext.Provider value={this.state.theme}>
        <div>
          <QOnlineTopHeader onIconMenuClick={this.onIconMenuClick} />
          
          {
            isShowHeader ? <QOnlineFreeqHeader isOpen={this.state.isMenuOpen} router={QOnlineFreeQRouter} {...this.props} /> : null
          }
          
          <div>
            {switchRoutes}
          </div>
          {
            isShowFooter ? <QOnlineTopFooter /> : null
          }
          <Footer />
          <BottomFooter />
        </div>
      </FreeQLayoutContext.Provider>

    )
  }

}

export default QOnlineFreeqLayout;
