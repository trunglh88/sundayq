import React from "react";
import QOnlineHomeHeader from "../../../component/Header/qonline/QOnlineHomeHeader"
import { QOnlineHomeRouter } from "../../../router/QOnlineHomeRouter"
import { Switch, Route, Redirect } from "react-router-dom";
import QOnlineTopHeader from "../../../component/Header/qonline/QOnlineTopHeader";
import Footer from "../../../component/Footer/Footer"
import EduQTopFooter from "../../../component/Footer/qonline/EduQTopFooter"
import BottomFooter from "../../../component/Footer/BottomFooter";
import "./qonline-home-layout.css"
const switchRoutes = (
  <Switch>
    {QOnlineHomeRouter.map((prop, key) => {
      if (prop.redirect)
        return <Redirect from={prop.path} to={prop.pathTo} key={key} />;
      return <Route
        exact path={prop.path} component={prop.component} key={key} />;
    })}
  </Switch>
);

class QOnlineHomeLayout extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false
    }
  }

  onIconMenuClick = (value) => {
    this.setState({
      isMenuOpen: value
    })
  }

  render() {
    return (
      <div>
        <QOnlineTopHeader onIconMenuClick={this.onIconMenuClick} />
        <div className="qonline-home-layout-main">
          <QOnlineHomeHeader isOpen={this.state.isMenuOpen} router={QOnlineHomeRouter} {...this.props} />

          <div>
            {switchRoutes}
          </div>
        </div>
        <EduQTopFooter />
        <Footer />
        <BottomFooter />
      </div>
    )
  }

}

export default QOnlineHomeLayout;
