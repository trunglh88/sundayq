import React from "react";


//define theme by url
export const themes = {
    sample: {
        background: "#fffbd4",
        color: "#C45840",
    },
    plan: {
        background: "#F9F9F9",
        color: "#CE4274"
    }
  };
  
  export const FreeQLayoutContext = React.createContext(
    themes.dark // default value
  );